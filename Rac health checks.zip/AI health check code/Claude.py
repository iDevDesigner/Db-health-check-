#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
==============================================================================
 Oracle RAC Health Check Script  –  V5
 Targets : Sun Solaris 10/11 SPARC  |  Oracle 19c RAC / Standalone
 Compat  : Python 2.7 / Python 3.x
 Author  : Reviewed & rebuilt by Claude from HealthCheck_V4 (QWEN origin)
==============================================================================
 WHAT IS CHECKED
   1.  OS Info            – hostname, uname, uptime, cpu, memory
   2.  RAC/Cluster        – olsnodes, CRS status, cluster name, nodes
   3.  DB Instances       – srvctl config/status database (ps fallback)
   4.  Listener & SCAN    – srvctl status listener/scan_listener + lsnrctl
   5.  ASM Disk Groups    – asmcmd lsdg (space %, state)
   6.  SCAN VIP           – srvctl config scan (RAC only)
   7.  CRS Resources      – crsctl status resource -t
   8.  GoldenGate         – MGR process + ggsci presence
   9.  Storage (df)       – filesystem utilisation (%)
  10.  Export Backup Age  – Data Pump .log/.dmp file age
  11.  Alert Log          – critical pattern scan (tail 2000 lines)
==============================================================================
"""

from __future__ import print_function

import os
import re
import sys
from collections import Counter
from datetime import datetime

import paramiko                       # pip install paramiko

# ─────────────────────────────────────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────
WARNING_THRESHOLD = 90    # filesystem / ASM % usage → WARNING
CRIT_THRESHOLD    = 95    # filesystem / ASM % usage → CRITICAL
SSH_TIMEOUT       = 30    # seconds
CMD_TIMEOUT       = 50    # seconds
ALERT_TAIL_LINES  = 2000  # lines to tail from alert log for pattern scan

# Credentials  – prefer environment variables; fall back to literals
#   export ORA_USERNAME=oracle  ORA_PASSWORD=... GRID_USERNAME=grid GRID_PASSWORD=...
ORA_USERNAME  = os.environ.get("ORA_USERNAME",  "oracle")
ORA_PASSWORD  = os.environ.get("ORA_PASSWORD",  "Ora#1234")
GRID_USERNAME = os.environ.get("GRID_USERNAME", "grid")
GRID_PASSWORD = os.environ.get("GRID_PASSWORD", "Grid#1234")

# ─── Server definitions ───────────────────────────────────────────────────────
#   expdp_list : list of filename-substring patterns to match Data Pump files
#   gg_check   : True → run GoldenGate check on this server
SERVERS = [
    {
        "name":      "prodsrv1",
        "host":      "10.xx.xx.xx",
        "expdp_list": ["expdp_pdb_EXPPDB", "EXPDP_COMPLETE"],
        "gg_check":  False,
    },
    {
        "name":      "prodsrv2",
        "host":      "10.xx.xx.xx",
        "expdp_list": ["expdp_pdb1", "expdp_pdb2"],
        "gg_check":  False,
    },
    {
        "name":      "prodsrv3",
        "host":      "10.xx.xx.xx",
        "expdp_list": ["EXPDP_SAS"],
        "gg_check":  False,
    },
    {
        "name":      "prodsrv4",
        "host":      "110.xx.xx.xx",
        "expdp_list": ["EXPDP_SAS"],
        "gg_check":  False,
    },
    {
        "name":      "prodsrv5",
        "host":      "10.xx.xx.xx",
        "expdp_list": [],
        "gg_check":  True,
    },
]

# ─── Alert-log critical / warning patterns ────────────────────────────────────
ALERT_CRIT_PATTERNS = [
    r"ORA-12008",
    r"ORA-00600",                 # Internal Oracle error
    r"ORA-07445",                 # OS exception
    r"ORA-04031",                 # Out of shared pool memory
    r"ORA-01578",                 # Block corruption
    r"ORA-00060",                 # Deadlock
    r"ORA-00257",                 # Archive stuck / full
    r"ORA-16038",                 # Archive stuck (alt code)
    r"ORA-15130",                 # ASM disk group dismounting
    r"ORA-15050",                 # ASM disk contains errors
    r"ORA-15051",                 # ASM file contains errors
    r"Deadlock",
    r"Checkpoint not complete",
    r"Block corruption",
    r"Fatal NI connect error",
    r"Instance shutdown",
    r"cannot allocate new log",
    r"FAL\[server\]",
    r"ARC\d+: Error",
    r"Thread\d+ cannot allocate new log",
    r"file #\d+ needs recovery",
    r"PMON failed to acquire",
    r"Corrupt block",
    r"media recovery",
    r"DIAG:kidglm",
    r"LGWR: terminating",
]

# ─────────────────────────────────────────────────────────────────────────────
#  STATUS CONSTANTS  (the only allowed values for result["status"])
# ─────────────────────────────────────────────────────────────────────────────
S_OK       = "OK"
S_WARNING  = "WARNING"
S_CRITICAL = "CRITICAL"
S_ERROR    = "ERROR"
S_NA       = "N/A"

# ─────────────────────────────────────────────────────────────────────────────
#  UNIFIED CHECK-RESULT FACTORY
#  Every check function returns a list of dicts produced by make_result().
#  This uniform shape makes report generation and the summary section trivial.
# ─────────────────────────────────────────────────────────────────────────────
def make_result(check_name, status, details, **extra):
    """
    Return a standardised check-result dict.

    Parameters
    ----------
    check_name : str   – human-readable check identifier (e.g. "DB_INSTANCES")
    status     : str   – one of S_OK / S_WARNING / S_CRITICAL / S_ERROR / S_NA
    details    : str   – single-line human-readable description
    **extra    : any   – optional typed fields (e.g. age_days=3, used_pct=97)
    """
    r = {
        "check_name": check_name,
        "status":     status,
        "details":    str(details),
    }
    r.update(extra)
    return r


# ─────────────────────────────────────────────────────────────────────────────
#  SSH HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def conn_server(server_info, username, password):
    """
    Open an SSH connection to server_info["host"].
    Returns (SSHClient, None) on success; (None, error_str) on failure.
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=server_info["host"],
            username=username,
            password=password,
            timeout=SSH_TIMEOUT,
            allow_agent=False,
            look_for_keys=False,
        )
        return client, None
    except paramiko.AuthenticationException as exc:
        return None, "Authentication error: {0}".format(exc)
    except paramiko.SSHException as exc:
        return None, "SSH error: {0}".format(exc)
    except Exception as exc:
        return None, "Connection error: {0}".format(exc)


def run_cmd(client, cmd):
    """
    Execute *cmd* over the established SSH session.
    Returns (stdout_str, stderr_str, exit_code).
    On any exception returns ("", error_message, 1).
    """
    try:
        # Source shell profiles; silently ignore missing files
        full_cmd = (
            ". ~/.profile 2>/dev/null || . ~/.bashrc 2>/dev/null || true; "
            + cmd
        )
        _, stdout, stderr = client.exec_command(full_cmd, timeout=CMD_TIMEOUT)
        out  = stdout.read().decode("utf-8", errors="replace").strip()
        err  = stderr.read().decode("utf-8", errors="replace").strip()
        code = stdout.channel.recv_exit_status()
        return out, err, code
    except Exception as exc:
        return "", "Command execution error: {0}".format(exc), 1


def _close(client):
    """Safely close an SSH client (ignores errors)."""
    if client:
        try:
            client.close()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 1 – OS INFORMATION
# ─────────────────────────────────────────────────────────────────────────────
def get_os_info(client, server_name):
    """
    Collect basic OS information.
    Returns a single-element list so callers can treat it uniformly.
    """
    chk  = "OS_INFO"
    info = {
        "hostname": server_name,
        "uname":    "UNKNOWN",
        "os_name":  "UNKNOWN",
        "uptime":   "UNKNOWN",
        "cpu":      [],
        "memory":   "UNKNOWN",
    }
    try:
        out, _, _ = run_cmd(client, "uname -a 2>/dev/null")
        if out:
            info["uname"] = out

        out, _, _ = run_cmd(client, "uname -s 2>/dev/null")
        if out:
            info["os_name"] = out.strip()

        out, _, _ = run_cmd(client, "hostname 2>/dev/null")
        if out:
            info["hostname"] = out.strip()

        out, _, _ = run_cmd(client, "uptime 2>/dev/null")
        if out:
            info["uptime"] = out.strip()

        # CPU info – Solaris SPARC
        out, _, _ = run_cmd(
            client,
            "psrinfo -v 2>/dev/null "
            "| /usr/xpg4/bin/grep -i 'sparc\\|processor\\|MHz' | head -5",
        )
        if out:
            info["cpu"] = [l.strip() for l in out.splitlines() if l.strip()]

        # Memory – prtconf on Solaris
        out, _, _ = run_cmd(
            client,
            "prtconf 2>/dev/null | /usr/xpg4/bin/grep -i 'memory size' | head -1",
        )
        if out:
            info["memory"] = out.strip()

    except Exception as exc:
        info["error"] = str(exc)

    # Build a compact detail string for the summary / report
    detail = (
        "Host={h} OS={o} Uptime={u} Mem={m}".format(
            h=info["hostname"],
            o=info["os_name"],
            u=info["uptime"][:60] if info["uptime"] else "?",
            m=info["memory"],
        )
    )
    return [make_result(chk, S_OK, detail, raw=info)]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 2 – RAC / CLUSTER INFO
# ─────────────────────────────────────────────────────────────────────────────
def get_rac_cluster_info(client, server_name):
    """
    Detect RAC membership, cluster name, and node list.
    Returns (result_list, is_rac_bool, nodes_list) so callers can consume
    the side-channel data without re-parsing.
    """
    chk  = "RAC_CLUSTER"
    data = {
        "is_rac":       False,
        "cluster_name": "N/A",
        "nodes":        [],
        "crs_lines":    [],
    }

    # --- Detect CRS / olsnodes -----------------------------------------------
    out, _, rc = run_cmd(
        client,
        "olsnodes -n 2>/dev/null "
        "|| echo 'CRS not found'; "
        "crsctl check cluster 2>/dev/null "
        "|| echo 'Not a RAC node'",
    )

    if rc != 0 or not out.strip() or all(
        x in out for x in ("CRS not found", "Not a RAC node")
    ):
        data["nodes"] = ["{0} (Standalone)".format(server_name)]
        result = make_result(chk, S_OK,
                             "Standalone server – no CRS/RAC detected",
                             **data)
        return [result], False, data["nodes"]

    # --- Parse cluster state --------------------------------------------------
    status = S_OK
    is_rac = any(
        kw in out
        for kw in ("CRS-4537", "CRS-4529", "CRS-4533",
                   "cluster ready services is online")
    ) or ("CRS-4537" in out.lower())

    if any(kw in out for kw in ("CRS-4535", "CRS-1008", "offline")):
        status = S_WARNING
    if any(kw in out.lower() for kw in ("could not contact", "crs-4639")):
        status = S_CRITICAL

    data["crs_lines"] = [l.strip() for l in out.splitlines() if l.strip()]

    # --- Node list -----------------------------------------------------------
    nodes_out, _, _ = run_cmd(client, "olsnodes -n 2>/dev/null")
    nodes = []
    for line in nodes_out.splitlines():
        parts = line.strip().split()
        if len(parts) >= 2:
            nodes.append(parts[0].split(".")[0])   # strip domain
        elif parts:
            nodes.append(parts[0])
    data["nodes"]  = nodes if nodes else [server_name]
    data["is_rac"] = is_rac or bool(nodes)

    # --- Cluster name --------------------------------------------------------
    if data["is_rac"]:
        cfg_out, _, _ = run_cmd(
            client,
            "olsnodes -c 2>/dev/null || echo 'CLUSTER_NAME=unknown'",
        )
        for line in cfg_out.splitlines():
            if "=" in line:
                data["cluster_name"] = line.split("=", 1)[-1].strip()
                break
            elif line.strip():
                data["cluster_name"] = line.strip()
                break

    detail = "is_rac={r} cluster={c} nodes={n}".format(
        r=data["is_rac"],
        c=data["cluster_name"],
        n=", ".join(data["nodes"]),
    )
    result = make_result(chk, status, detail, **data)
    return [result], data["is_rac"], data["nodes"]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 3 – DB INSTANCES
# ─────────────────────────────────────────────────────────────────────────────
def get_db_instances(client, server_name):
    """
    Enumerate Oracle database instances.
    Primary: srvctl config database → srvctl status database -d <db>
    Fallback: ps | grep ora_pmon
    """
    chk     = "DB_INSTANCES"
    results = []

    # ── Primary path: srvctl ─────────────────────────────────────────────────
    config_out, _, rc = run_cmd(client, "srvctl config database 2>/dev/null")

    if rc != 0 or not config_out.strip() or any(
        err in config_out for err in ("PRCR-1119", "PRCR-1115", "CRS-0184")
    ):
        # ── Fallback: ps ─────────────────────────────────────────────────────
        ps_out, _, _ = run_cmd(
            client,
            "ps -ef 2>/dev/null "
            "| /usr/xpg4/bin/grep ora_pmon "
            "| /usr/xpg4/bin/grep -v grep",
        )
        if not ps_out:
            return [make_result(chk, S_WARNING,
                                "No DB instances detected (srvctl failed; no PMON processes found)")]

        for line in ps_out.splitlines():
            m = re.search(r"ora_pmon_(\S+)", line)
            if m:
                sid = m.group(1)
                results.append(make_result(
                    chk, S_OK,
                    "DB={s} Instance={s} Node={n} State=running (ps fallback)".format(
                        s=sid, n=server_name),
                    db_name=sid, instance=sid, node=server_name, state="running",
                ))
        return results if results else [
            make_result(chk, S_WARNING, "No running PMON processes found")
        ]

    # ── Parse srvctl output ──────────────────────────────────────────────────
    db_names = [db.strip() for db in config_out.splitlines() if db.strip()]
    if not db_names:
        return [make_result(chk, S_WARNING, "srvctl config database returned no DB names")]

    for db in db_names:
        status_out, _, _ = run_cmd(
            client,
            "srvctl status database -d {db} 2>/dev/null".format(db=db),
        )

        # "Instance <inst> is running on node <node>"
        insts = re.findall(
            r"Instance\s+(\S+)\s+is\s+([\w\s]+?)\s+on\s+node\s+(\S+)",
            status_out,
        )
        if insts:
            for inst_name, state, node in insts:
                state = state.strip()
                status = S_OK if "running" in state.lower() else S_CRITICAL
                results.append(make_result(
                    chk, status,
                    "DB={db} Instance={i} Node={n} State={s}".format(
                        db=db, i=inst_name, n=node, s=state),
                    db_name=db, instance=inst_name, node=node, state=state,
                ))
        elif "running" in status_out.lower():
            results.append(make_result(
                chk, S_OK,
                "DB={db} Node={n} State=running".format(db=db, n=server_name),
                db_name=db, instance=db, node=server_name, state="running",
            ))
        elif "not running" in status_out.lower():
            results.append(make_result(
                chk, S_CRITICAL,
                "DB={db} Node={n} State=not running".format(db=db, n=server_name),
                db_name=db, instance=db, node=server_name, state="not running",
            ))
        else:
            results.append(make_result(
                chk, S_WARNING,
                "DB={db} – cannot determine instance state. Output: {o}".format(
                    db=db, o=status_out[:120]),
                db_name=db, instance=db, node=server_name, state="unknown",
            ))

    return results if results else [
        make_result(chk, S_WARNING, "No databases found via srvctl")
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 4 – LISTENER & SCAN STATUS
# ─────────────────────────────────────────────────────────────────────────────
def get_listener_status(client, is_rac):
    """
    Check listener status via srvctl (always) and lsnrctl (for detail).
    For RAC also checks SCAN listener.
    """
    chk     = "LISTENER"
    results = []

    # ── srvctl status listener ───────────────────────────────────────────────
    out, _, _ = run_cmd(client, "srvctl status listener 2>/dev/null")
    if out:
        lines  = [l.strip() for l in out.splitlines() if l.strip()]
        status = S_OK if any("is running" in l.lower() for l in lines) else S_CRITICAL
        results.append(make_result(
            chk, status,
            "SRVCTL_LISTENER: " + " | ".join(lines[:5]),
        ))
    else:
        results.append(make_result(chk, S_WARNING,
                                   "SRVCTL_LISTENER: no output from srvctl"))

    # ── srvctl status scan_listener (RAC only) ───────────────────────────────
    if is_rac:
        out, _, _ = run_cmd(client, "srvctl status scan_listener 2>/dev/null")
        if out:
            lines  = [l.strip() for l in out.splitlines() if l.strip()]
            status = S_OK if any("is running" in l.lower() for l in lines) else S_CRITICAL
            results.append(make_result(
                chk, status,
                "SRVCTL_SCAN: " + " | ".join(lines[:5]),
            ))
        else:
            results.append(make_result(chk, S_WARNING,
                                       "SRVCTL_SCAN: no output from srvctl"))

    # ── lsnrctl status (detailed) ────────────────────────────────────────────
    lsnrctl_out, _, _ = run_cmd(
        client,
        "lsnrctl status 2>/dev/null "
        "| /usr/xpg4/bin/grep -E 'Alias|Status|Uptime|Service'",
    )

    if lsnrctl_out and "cannot communicate" not in lsnrctl_out.lower():
        # Extract listener names from Alias lines
        lsnr_names = []
        for line in lsnrctl_out.splitlines():
            if "Alias" in line:
                parts = line.split()
                if len(parts) >= 2:
                    lsnr_names.append(parts[-1].strip())

        for lsnr in set(lsnr_names):
            sts_out, _, _ = run_cmd(
                client,
                "lsnrctl status {l} 2>/dev/null "
                "| /usr/xpg4/bin/grep -E "
                "'Alias|Status|Start Date|Uptime|Service|Instance'".format(l=lsnr),
            )
            l_info   = {"uptime": "UNKNOWN", "listener_status": "OFFLINE", "services": 0}
            l_status = S_CRITICAL

            if sts_out:
                for line in sts_out.splitlines():
                    line = line.strip()
                    if "Start Date" in line:
                        l_info["start_date"] = " ".join(line.split()[2:])
                    if "Uptime" in line:
                        l_info["uptime"]          = line.split()[1] if len(line.split()) > 1 else "?"
                        l_info["listener_status"] = "ONLINE"
                        l_status                  = S_OK
                    if "Service" in line:
                        l_info["services"] += 1

            results.append(make_result(
                chk, l_status,
                "LSNRCTL {l}: status={s} uptime={u} services={sv}".format(
                    l=lsnr,
                    s=l_info["listener_status"],
                    u=l_info["uptime"],
                    sv=l_info["services"],
                ),
            ))

    return results if results else [
        make_result(chk, S_WARNING, "No listener information could be obtained")
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 5 – ASM DISK GROUPS
# ─────────────────────────────────────────────────────────────────────────────
def get_asm_status(client):
    """
    Check ASM disk group state and space utilisation via 'asmcmd lsdg'.
    Solaris asmcmd lsdg column order (0-based):
      0=State  1=Type  2=Rebal  3=Sector  4=Block  5=AU  6=Total_MB  7=Free_MB
      8=Req_mir_free_MB  9=Usable_file_MB  10=Offline_disks  11=Voting_files
      12=Name (with trailing /)
    """
    chk = "ASM_DISKGROUPS"
    out, _, _ = run_cmd(
        client,
        "asmcmd lsdg 2>/dev/null || echo 'ASMCMD not found or not ASM node'",
    )

    if "ASMCMD not found" in out or not out.strip():
        return [make_result(chk, S_NA, "ASM not available on this node")]

    results = []
    for line in out.splitlines():
        line = line.strip()
        if not line or "State" in line:          # skip header
            continue
        parts = line.split()
        if len(parts) < 9:
            continue
        try:
            state    = parts[0]
            total_mb = float(parts[6])
            free_mb  = float(parts[7])
            name     = parts[-1].rstrip("/")
            used_pct = (
                round((total_mb - free_mb) / total_mb * 100, 1)
                if total_mb > 0 else 0.0
            )

            status = S_OK
            if used_pct >= CRIT_THRESHOLD:
                status = S_CRITICAL
            elif used_pct > WARNING_THRESHOLD:
                status = S_WARNING

            results.append(make_result(
                chk, status,
                "DG={n} State={st} Total={t:.0f}MB Free={f:.0f}MB Used={p}%".format(
                    n=name, st=state, t=total_mb, f=free_mb, p=used_pct),
                dg_name=name, state=state, total_mb=total_mb,
                free_mb=free_mb, used_pct=used_pct,
            ))
        except (ValueError, IndexError):
            continue

    return results if results else [
        make_result(chk, S_WARNING, "No ASM disk group data parsed from asmcmd lsdg output")
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 6 – SCAN VIP INFO
# ─────────────────────────────────────────────────────────────────────────────
def get_scan_info(client, is_rac):
    """Retrieve SCAN VIP configuration (RAC only)."""
    chk = "SCAN_VIP"
    if not is_rac:
        return [make_result(chk, S_NA, "Not a RAC cluster – SCAN not applicable")]

    out, _, _ = run_cmd(client, "srvctl config scan 2>/dev/null")
    lines = [l.strip() for l in out.splitlines() if l.strip()]
    if not lines:
        return [make_result(chk, S_WARNING, "SCAN VIP info not available")]

    return [make_result(chk, S_OK, " | ".join(lines))]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 7 – CRS RESOURCES
# ─────────────────────────────────────────────────────────────────────────────
def get_crsctl_resources(client):
    """
    Parse 'crsctl status resource -t'.
    Each resource instance becomes one check-result entry.
    """
    chk = "CRS_RESOURCES"
    out, _, rc = run_cmd(client, "crsctl status resource -t 2>/dev/null")
    if rc != 0 or not out.strip():
        return [make_result(chk, S_WARNING,
                            "crsctl status resource failed or returned no data")]

    # Resource name lines start with "ora."
    res_name_re  = re.compile(r"^(ora\.\S+)")
    # Detail lines: <idx>  <target>  <state>  <server>  [details]
    # e.g.:   1        ONLINE   ONLINE   node1    Started
    detail_re    = re.compile(r"^\s*(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s*(.*)")

    current_res = None
    results     = []

    for line in out.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("---") or stripped.startswith("Name"):
            continue

        nm = res_name_re.match(stripped)
        if nm:
            current_res = nm.group(1)
            continue

        if current_res:
            dm = detail_re.match(line)
            if dm:
                idx, target, state, server, detail_txt = dm.groups()
                # CRITICAL when either target or state is not ONLINE
                status = (
                    S_CRITICAL
                    if (target.upper() != "ONLINE" or state.upper() != "ONLINE")
                    else S_OK
                )
                results.append(make_result(
                    chk, status,
                    "{res} idx={i} target={t} state={s} server={srv} {d}".format(
                        res=current_res, i=idx, t=target,
                        s=state, srv=server, d=detail_txt.strip()),
                    resource=current_res, index=idx,
                    target=target, state=state, server=server,
                ))

    return results if results else [
        make_result(chk, S_WARNING, "No CRS resource entries could be parsed")
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 8 – GOLDENGATE
# ─────────────────────────────────────────────────────────────────────────────
def check_goldengate(client, gg_enabled):
    """Check GoldenGate MGR process and ggsci binary presence."""
    chk = "GOLDENGATE"
    if not gg_enabled:
        return [make_result(chk, S_NA,
                            "GoldenGate check not enabled for this server")]

    mgr_out, _, _ = run_cmd(
        client,
        "ps -ef 2>/dev/null "
        "| /usr/xpg4/bin/grep -iw mgr "
        "| /usr/xpg4/bin/grep -v grep | head -5",
    )

    if mgr_out and "mgr" in mgr_out.lower():
        # Verify ggsci is reachable
        ggsci_out, _, _ = run_cmd(
            client,
            "which ggsci 2>/dev/null "
            "|| find /u01 /ggate /opt -name ggsci 2>/dev/null | head -1",
        )
        if ggsci_out.strip() and "no ggsci" not in ggsci_out.lower():
            return [make_result(chk, S_OK,
                                "GoldenGate MGR process is running; ggsci={g}".format(
                                    g=ggsci_out.strip()))]
        return [make_result(chk, S_WARNING,
                            "GoldenGate MGR running but ggsci binary not found")]

    return [make_result(chk, S_CRITICAL,
                        "GoldenGate MGR process NOT found in process list")]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 9 – STORAGE (df)
# ─────────────────────────────────────────────────────────────────────────────
def get_storage_usage(client):
    """
    Parse 'df -h' output for filesystem utilisation.
    Handles both Solaris and Linux column formats.
    """
    chk = "STORAGE"
    out, err, _ = run_cmd(client, "df -h 2>/dev/null")
    if not out.strip():
        return [make_result(chk, S_WARNING,
                            "df command returned no output: {e}".format(e=err))]

    results = []
    for line in out.splitlines():
        line = line.strip()
        # Skip headers and empty lines
        if not line or line.lower().startswith("filesystem") or line.startswith("//"):
            continue
        parts = line.split()
        if len(parts) < 6:
            continue
        try:
            filesystem  = parts[0]
            size        = parts[1]
            used        = parts[2]
            available   = parts[3]
            pct_str     = parts[4].rstrip("%")
            mount_point = parts[5]
            pct         = int(pct_str)

            status = S_OK
            if pct >= CRIT_THRESHOLD:
                status = S_CRITICAL
            elif pct >= WARNING_THRESHOLD:
                status = S_WARNING

            results.append(make_result(
                chk, status,
                "Mount={mp} Size={sz} Used={u} Avail={a} Use%={p}%".format(
                    mp=mount_point, sz=size, u=used, a=available, p=pct),
                filesystem=filesystem, mount_point=mount_point,
                size=size, used=used, available=available, used_pct=pct,
            ))
        except (ValueError, IndexError):
            continue

    return results if results else [
        make_result(chk, S_WARNING, "No filesystem data could be parsed from df output")
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 10 – EXPORT BACKUP AGE
# ─────────────────────────────────────────────────────────────────────────────
def check_backup_age(client, patterns):
    """
    Find Data Pump .log / .dmp files and check their age.
    Age >= 2 days → CRITICAL; age >= 1 day → WARNING.
    """
    chk = "EXPORT_BACKUP"
    if not patterns:
        return [make_result(chk, S_NA,
                            "No export backup patterns configured for this server")]

    find_cmd = (
        "/usr/gnu/bin/find "
        "/oracle/exports/daily /orabkp/exports/daily "
        "-maxdepth 1 -type f "
        r"\( -name '*.log' -o -name '*.dmp' \) 2>/dev/null"
    )
    out, _, _ = run_cmd(client, find_cmd)
    if not out.strip():
        return [make_result(chk, S_CRITICAL,
                            "No .log or .dmp files found in export backup directories")]

    results = []
    for fpath in out.splitlines():
        fpath = fpath.strip()
        if not fpath:
            continue
        fname = os.path.basename(fpath)

        # Match against configured patterns (case-insensitive)
        if not any(p.lower() in fname.lower() for p in patterns):
            continue

        # Solaris date: try GNU stat first, then ls -ld with --time-style
        safe = fpath.replace("'", "\\'")
        date_cmd = (
            "/usr/gnu/bin/stat -c '%y' '{p}' 2>/dev/null "
            "|| ls -ld --time-style=full-iso '{p}' 2>/dev/null "
            "|| ls -lD '%Y-%m-%d' '{p}' 2>/dev/null".format(p=safe)
        )
        date_out, _, _ = run_cmd(client, date_cmd)

        date_matches = re.findall(r"\d{4}-\d{2}-\d{2}", date_out)
        if not date_matches:
            results.append(make_result(
                chk, S_WARNING,
                "File={f} – could not determine modification date".format(f=fname),
            ))
            continue

        try:
            mod_date = datetime.strptime(date_matches[0], "%Y-%m-%d")
            age      = (datetime.now() - mod_date).days
            status   = S_OK
            if age >= 2:
                status = S_CRITICAL
            elif age >= 1:
                status = S_WARNING

            results.append(make_result(
                chk, status,
                "File={f} ModDate={d} Age={a}d".format(
                    f=fname, d=date_matches[0], a=age),
                file=fname, mod_date=date_matches[0], age_days=age,
            ))
        except ValueError:
            results.append(make_result(
                chk, S_WARNING,
                "File={f} – date parse failed for '{d}'".format(
                    f=fname, d=date_matches[0]),
            ))

    return results if results else [
        make_result(
            chk, S_WARNING,
            "No files matched configured patterns: {p}".format(p=patterns),
        )
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  CHECK 11 – ALERT LOG
# ─────────────────────────────────────────────────────────────────────────────
def check_alert_log(client):
    """
    Tail the Oracle alert log and scan for critical error patterns.
    One check-result is produced per unique matched pattern.
    """
    chk = "ALERT_LOG"

    # Locate alert log
    log_out, _, _ = run_cmd(
        client,
        "find $ORACLE_BASE/diag -name 'alert_*.log' 2>/dev/null | head -1",
    )
    if not log_out.strip():
        # Fallback paths
        log_out, _, _ = run_cmd(
            client,
            "find /u01/app/oracle/diag /oracle/diag "
            "-name 'alert_*.log' 2>/dev/null | head -1",
        )
    if not log_out.strip():
        return [make_result(chk, S_WARNING, "Alert log not found on this server")]

    log_path = log_out.strip()
    content, _, _ = run_cmd(
        client,
        "tail -{n} {p} 2>/dev/null".format(n=ALERT_TAIL_LINES, p=log_path),
    )
    if not content:
        return [make_result(
            chk, S_WARNING,
            "Alert log found but empty or unreadable: {p}".format(p=log_path),
        )]

    # Build combined pattern (case-insensitive)
    combined_re = re.compile(
        "|".join(ALERT_CRIT_PATTERNS),
        re.IGNORECASE,
    )
    found_errors = Counter(combined_re.findall(content))

    if not found_errors:
        return [make_result(
            chk, S_OK,
            "No critical patterns in last {n} lines. Log: {p}".format(
                n=ALERT_TAIL_LINES, p=log_path),
        )]

    results = []
    # Patterns that always mean CRITICAL
    critical_keywords = ("ORA-", "Corrupt", "corruption", "shutdown", "terminating")
    for pattern, count in sorted(found_errors.items(), key=lambda kv: -kv[1]):
        status = (
            S_CRITICAL
            if any(kw.lower() in pattern.lower() for kw in critical_keywords)
            else S_WARNING
        )
        results.append(make_result(
            chk, status,
            "Pattern='{p}' Count={c} Log={l}".format(
                p=pattern, c=count, l=log_path),
            pattern=pattern, count=count, log_path=log_path,
        ))
    return results


# ─────────────────────────────────────────────────────────────────────────────
#  REPORT GENERATION
# ─────────────────────────────────────────────────────────────────────────────
_WIDTH = 120
_SEP   = "=" * _WIDTH
_DSEP  = "-" * _WIDTH


def _log(lines_list, text=""):
    """Append text to the in-memory line buffer AND print to stdout."""
    lines_list.append(str(text))
    print(str(text))


def _section(lines_list, title, check_results):
    """
    Print a labelled section containing a list of check-result dicts.
    """
    _log(lines_list)
    _log(lines_list, "  [{title}]".format(title=title.upper()))
    if not check_results:
        _log(lines_list, "    (no data)")
        return
    for r in check_results:
        if isinstance(r, dict):
            _log(lines_list, "    [{s:^8}] {d}".format(
                s=r.get("status", "?"),
                d=r.get("details", ""),
            ))
        else:
            _log(lines_list, "    {0}".format(r))


def generate_report_and_save(all_reports, error_log):
    """
    Write a full detailed text report and a critical/warning summary table.
    The file is saved as:  Oracle_HealthCheck_V5_<YYYYMMDD_HHMMSS>.txt
    """
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = "Oracle_HealthCheck_V5_{ts}.txt".format(ts=ts)
    lines    = []

    def log(text=""):
        _log(lines, text)

    # ──────────────────────────────────────────────────────────────────────────
    #  HEADER
    # ──────────────────────────────────────────────────────────────────────────
    log(_SEP)
    log("  ORACLE DATABASE HEALTH CHECK REPORT  –  V5")
    log("  Generated : {dt}".format(dt=datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    log(_SEP)

    # ──────────────────────────────────────────────────────────────────────────
    #  PER-SERVER DETAIL
    # ──────────────────────────────────────────────────────────────────────────
    for srv in all_reports:
        log()
        log(_SEP)
        log("  SERVER : {n}   HOST : {h}".format(n=srv["name"], h=srv["host"]))
        log(_SEP)

        # OS Info block
        os_res = srv.get("os_info", [])
        if os_res and isinstance(os_res[0], dict):
            raw = os_res[0].get("raw", {})
            log("  {:<30} {}".format("Host Name:",     raw.get("hostname", "N/A")))
            log("  {:<30} {}".format("OS (uname -a):", raw.get("uname",    "N/A")))
            log("  {:<30} {}".format("OS Name:",       raw.get("os_name",  "N/A")))
            log("  {:<30} {}".format("Uptime:",        raw.get("uptime",   "N/A")))
            log("  {:<30} {}".format("CPUs:",          ", ".join(raw.get("cpu", [])) or "N/A"))
            log("  {:<30} {}".format("Memory:",        raw.get("memory",   "N/A")))

        # RAC Info block
        rac_res = srv.get("rac_info", [])
        if rac_res and isinstance(rac_res[0], dict):
            rd = rac_res[0]
            log("  {:<30} {}".format("RAC/Cluster:", "Yes" if rd.get("is_rac") else "No"))
            log("  {:<30} {}".format("Cluster Name:", rd.get("cluster_name", "N/A")))
            log("  {:<30} {}".format("Nodes:", ", ".join(rd.get("nodes", []))))

        _section(lines, "DB Instances",          srv.get("instances",    []))
        _section(lines, "Listener & SCAN",        srv.get("listeners",    []))
        _section(lines, "ASM Disk Groups",        srv.get("asm_disks",    []))
        _section(lines, "SCAN VIP",               srv.get("scan_info",    []))
        _section(lines, "CRS Resources",          srv.get("resources",    []))
        _section(lines, "GoldenGate",             srv.get("gg_status",    []))
        _section(lines, "Storage Utilisation",    srv.get("storage",      []))
        _section(lines, "Export Backup Age",      srv.get("backup_check", []))
        _section(lines, "Critical Alert Log",     srv.get("alert_issues", []))

    # ──────────────────────────────────────────────────────────────────────────
    #  CONNECTION / PROCESSING ERRORS
    # ──────────────────────────────────────────────────────────────────────────
    if error_log:
        log()
        log(_SEP)
        log("  CONNECTION & PROCESSING ERRORS")
        log(_DSEP)
        for err in error_log:
            log("  * {e}".format(e=err))

    # ──────────────────────────────────────────────────────────────────────────
    #  EXECUTIVE SUMMARY  –  WARNING / CRITICAL only
    # ──────────────────────────────────────────────────────────────────────────
    log()
    log(_SEP)
    log("  EXECUTIVE SUMMARY  –  CRITICAL / WARNING ITEMS  (OK items omitted)")
    log(_SEP)
    col_srv  = 20
    col_chk  = 25
    col_st   = 12
    col_det  = _WIDTH - col_srv - col_chk - col_st - 4
    header   = "{srv:<{cs}} {chk:<{cc}} {st:<{cst}} {det}".format(
        srv="Server", chk="Check", st="Status", det="Details",
        cs=col_srv, cc=col_chk, cst=col_st,
    )
    log(header)
    log(_DSEP)

    has_issues = False
    # All section keys that carry check-result lists
    all_sections = (
        "instances", "listeners", "asm_disks", "scan_info", "resources",
        "gg_status", "storage", "backup_check", "alert_issues",
    )
    for srv in all_reports:
        sname = srv["name"]
        for section_key in all_sections:
            for res in srv.get(section_key, []):
                if not isinstance(res, dict):
                    continue
                st = res.get("status", S_OK)
                if st not in (S_WARNING, S_CRITICAL, S_ERROR):
                    continue
                has_issues = True
                det = res.get("details", "")
                if len(det) > col_det:
                    det = det[:col_det - 3] + "..."
                log("{srv:<{cs}} {chk:<{cc}} {st:<{cst}} {det}".format(
                    srv=sname, chk=res.get("check_name", "UNKNOWN"),
                    st=st, det=det,
                    cs=col_srv, cc=col_chk, cst=col_st,
                ))

    if not has_issues:
        log("  All checks passed – no WARNING or CRITICAL items found.")

    log()
    log(_SEP)
    log("  Health check complete.")
    log("  Report saved to : {f}".format(f=os.path.abspath(filename)))
    log(_SEP)

    # ── Write file ────────────────────────────────────────────────────────────
    try:
        with open(filename, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines))
    except TypeError:
        # Python 2 fallback (no encoding kwarg)
        with open(filename, "w") as fh:
            fh.write("\n".join(lines))

    return filename


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN EXECUTION
# ─────────────────────────────────────────────────────────────────────────────
def main():
    if not SERVERS:
        print("No servers configured. Edit the SERVERS list and retry.")
        return

    all_reports = []
    all_errors  = []

    print(_SEP)
    print("  Oracle RAC Health Check  –  V5")
    print("  Start : {dt}".format(dt=datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    print(_SEP)

    for server in SERVERS:
        sname       = server["name"]
        ora_client  = None
        grid_client = None
        gg_enabled  = server.get("gg_check", False)

        try:
            # ── Oracle user SSH ───────────────────────────────────────────────
            print("\nConnecting to {n} ({h}) as '{u}'...".format(
                n=sname, h=server["host"], u=ORA_USERNAME))
            ora_client, ora_err = conn_server(server, ORA_USERNAME, ORA_PASSWORD)
            if ora_err:
                msg = "{n}: Oracle SSH failed – {e}".format(n=sname, e=ora_err)
                all_errors.append(msg)
                print("  FAILED: {e}".format(e=ora_err))
                continue
            print("  Oracle user : OK")

            # ── Grid user SSH ─────────────────────────────────────────────────
            print("Connecting to {n} ({h}) as '{u}'...".format(
                n=sname, h=server["host"], u=GRID_USERNAME))
            grid_client, grid_err = conn_server(server, GRID_USERNAME, GRID_PASSWORD)
            if grid_err:
                msg = "{n}: Grid SSH failed – {e} (running in degraded mode)".format(
                    n=sname, e=grid_err)
                all_errors.append(msg)
                print("  FAILED: {e}  – continuing in degraded mode".format(e=grid_err))
                # Do not 'continue'; we fall back to ora_client for Grid checks

            print("  Grid user   : {s}".format(
                s="OK" if grid_client else "FAILED (degraded)"))

            # Convenience: use grid_client where available, else fall back
            gc = grid_client if grid_client else ora_client

            # ── Run all checks ────────────────────────────────────────────────
            report = {"name": sname, "host": server["host"]}

            report["os_info"]  = get_os_info(ora_client, sname)

            rac_results, is_rac, nodes = get_rac_cluster_info(gc, sname)
            report["rac_info"] = rac_results

            report["instances"]    = get_db_instances(ora_client, sname)
            report["listeners"]    = get_listener_status(gc, is_rac)
            report["asm_disks"]    = get_asm_status(gc)
            report["scan_info"]    = get_scan_info(gc, is_rac)
            report["resources"]    = get_crsctl_resources(gc)
            report["gg_status"]    = check_goldengate(ora_client, gg_enabled)
            report["storage"]      = get_storage_usage(ora_client)
            report["backup_check"] = check_backup_age(
                ora_client, server.get("expdp_list", []))
            report["alert_issues"] = check_alert_log(ora_client)

            all_reports.append(report)
            print("  All checks complete for {n}.".format(n=sname))

        except Exception as exc:
            msg = "{n}: Unexpected error – {e}".format(n=sname, e=exc)
            all_errors.append(msg)
            print("  ERROR: {e}".format(e=exc))

        finally:
            _close(ora_client)
            _close(grid_client)

    generate_report_and_save(all_reports, all_errors)


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("Fatal error: {e}".format(e=exc))
        sys.exit(1)
