#!/usr/bin/env python3
"""
Oracle Database Health Check Script - V4 Improved
Performs comprehensive health checks on Oracle database servers via SSH.
"""

import json
import re
import sys
import os
from datetime import datetime
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple, Any, Callable
from enum import Enum
import paramiko


# ============================================================================
# CONFIGURATION
# ============================================================================

class Status(Enum):
    OK = "OK"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    UNKNOWN = "UNKNOWN"
    NOT_CONFIGURED = "NOT_CONFIGURED"

    def __str__(self):
        return self.value


@dataclass
class CheckResult:
    """Standardized result format for every health check."""
    check_name: str
    status: Status
    details: List[Dict[str, Any]] = field(default_factory=list)
    message: str = ""
    raw_output: str = ""
    errors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_name": self.check_name,
            "status": str(self.status),
            "details": self.details,
            "message": self.message,
            "errors": self.errors,
            "metadata": self.metadata
        }


# Thresholds
WARNING_THRESHOLD = 90
CRIT_THRESHOLD = 95
SSH_TIMEOUT = 30
CMD_TIMEOUT = 60

# Credentials (Consider using environment variables or key vault in production)
ORA_USERNAME = os.environ.get("ORA_USERNAME", "oracle")
ORA_PASSWORD = os.environ.get("ORA_PASSWORD", "Ora#1234")
GRID_USERNAME = os.environ.get("GRID_USERNAME", "grid")
GRID_PASSWORD = os.environ.get("GRID_PASSWORD", "Grid#1234")

# Server Configuration
SERVERS = [
    {
        "name": "prodsrv1",
        "host": "10.xx.xx.xx",
        "expdp_list": ["expdp_pdb_EXPDP", "EXPDP_COMPLETE"],
        "gg_check": False
    },
    {
        "name": "prodsrv2",
        "host": "10.xx.xx.xx",
        "expdp_list": ["expdp_pdb1", "expdp_pdb2"],
        "gg_check": False
    },
    {
        "name": "prodsrv3",
        "host": "10.xx.xx.xx",
        "expdp_list": ["EXPDP_SAS"],
        "gg_check": False
    },
    {
        "name": "prodsrv4",
        "host": "10.xx.xx.xx",
        "expdp_list": ["EXPDP_SAS"],
        "gg_check": False
    },
    {
        "name": "prodsrv5",
        "host": "10.xx.xx.xx",
        "expdp_list": [],
        "gg_check": True
    },
]

# Critical/Warning Alert Log Patterns
ALERT_CRIT_PATTERNS = [
    r'ORA-12008',      # materialized view refresh error
    r'ORA-00600',      # internal oracle error
    r'ORA-07445',      # OS exception
    r'ORA-04031',      # out of shared pool memory
    r'ORA-01578',      # block corruption
    r'ORA-00060',      # deadlock
    r'ORA-00257',      # archive stuck / full
    r'ORA-16038',      # archive stuck (alt code)
    r'ORA-15130',      # ASM disk group dismounting
    r'ORA-15050',      # ASM disk contains errors
    r'ORA-15051',      # ASM file contains errors
    r'DeadLock',
    r'Checkpoint not complete',
    r'Block corruption',
    r'Fatal NI connect error',
    r'Instance shutdown',
    r'Error',
    r'cannot allocate new log',
    r'FAL\s*\[server\]',  # FAL server error
    r'ARC\d+:\s*Error',
    r'Thread\s*\d+\s*cannot allocate new log',
    r'file\s*#\d+\s*needs recovery',
    r'PMON failed to acquire',
    r'Corrupt block',
    r'media recovery',
    r'DIA\d+:\s*killed',  # Diagnosability process killed
    r'LGWR:\s*terminating',
]


# ============================================================================
# SSH CONNECTION HELPERS
# ============================================================================

class SSHConnectionManager:
    """Manages SSH connections with proper error handling and cleanup."""
    
    def __init__(self, server_info: Dict[str, str], username: str, password: str):
        self.server_info = server_info
        self.username = username
        self.password = password
        self.client: Optional[paramiko.SSHClient] = None
        self.connection_error: Optional[str] = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def connect(self) -> bool:
        """Establish SSH connection with comprehensive error handling."""
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        try:
            self.client.connect(
                hostname=self.server_info['host'],
                username=self.username,
                password=self.password,
                timeout=SSH_TIMEOUT,
                allow_agent=False,
                look_for_keys=False,
                banner_timeout=15,
                auth_timeout=15
            )
            return True
        except paramiko.AuthenticationException as e:
            self.connection_error = f"Authentication failed: {str(e)}"
        except paramiko.SSHException as e:
            self.connection_error = f"SSH protocol error: {str(e)}"
        except TimeoutError:
            self.connection_error = "Connection timed out"
        except ConnectionRefusedError:
            self.connection_error = "Connection refused - SSH service may not be running"
        except Exception as e:
            self.connection_error = f"Unexpected connection error: {str(e)}"
        
        return False

    def close(self):
        """Safely close SSH connection."""
        if self.client:
            try:
                self.client.close()
            except Exception:
                pass
            finally:
                self.client = None

    def is_connected(self) -> bool:
        """Check if connection is active."""
        return self.client is not None and self.client.get_transport() is not None


def run_command(client: paramiko.SSHClient, cmd: str, timeout: int = CMD_TIMEOUT) -> Tuple[Optional[str], Optional[str], int]:
    """
    Execute command via SSH with robust error handling.
    Returns: (stdout, stderr, exit_code)
    """
    if not client or not client.get_transport() or not client.get_transport().is_active():
        return None, "SSH client not connected", -1

    try:
        # Source environment profiles for Oracle/Grid commands
        full_cmd = f"source ~/.profile 2>/dev/null || source ~/.bashrc 2>/dev/null || true; {cmd}"
        
        stdin, stdout, stderr = client.exec_command(full_cmd, timeout=timeout, get_pty=False)
        
        exit_code = stdout.channel.recv_exit_status()
        
        out = stdout.read().decode('utf-8', errors='replace').strip()
        err = stderr.read().decode('utf-8', errors='replace').strip()
        
        # Some commands write to stderr even on success (e.g., crsctl)
        return out, err, exit_code
        
    except paramiko.SSHException as e:
        return None, f"SSH command execution error: {str(e)}", -1
    except TimeoutError:
        return None, f"Command timed out after {timeout}s", -1
    except Exception as e:
        return None, f"Command execution error: {str(e)}", -1


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def safe_float(value: Any, default: float = 0.0) -> float:
    """Safely convert value to float."""
    try:
        return float(str(value).replace(',', '').replace('%', '').strip())
    except (ValueError, TypeError, AttributeError):
        return default


def safe_int(value: Any, default: int = 0) -> int:
    """Safely convert value to int."""
    try:
        return int(safe_float(value, default))
    except (ValueError, TypeError):
        return default


def determine_status(value: float, warning: float, critical: float, 
                     higher_is_worse: bool = True) -> Status:
    """
    Determine status based on threshold values.
    higher_is_worse=True: value > warning = WARNING, value > critical = CRITICAL
    higher_is_worse=False: value < warning = WARNING, value < critical = CRITICAL
    """
    if higher_is_worse:
        if value >= critical:
            return Status.CRITICAL
        elif value >= warning:
            return Status.WARNING
    else:
        if value <= critical:
            return Status.CRITICAL
        elif value <= warning:
            return Status.WARNING
    return Status.OK


def parse_df_output(output: str, server_name: str) -> CheckResult:
    """
    Parse 'df -h' output with robust error handling.
    """
    entries = []
    errors = []
    
    if not output or not output.strip():
        return CheckResult(
            check_name="STORAGE_CHECK",
            status=Status.UNKNOWN,
            message="No output from df command",
            errors=["Empty output from df -h"]
        )
    
    for line in output.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("Filesystem") or "capacity" in line.lower():
            continue
            
        parts = line.split()
        if len(parts) < 6:
            errors.append(f"Skipped unparseable line: {line[:50]}")
            continue
            
        try:
            # df -h output: Filesystem Size Used Avail Use% Mount
            filesystem = parts[0]
            size = parts[1]
            used = parts[2]
            available = parts[3]
            usage_pct_str = parts[4]
            mount_point = parts[5]
            
            # Parse percentage
            pct = safe_int(usage_pct_str.replace('%', ''))
            
            # Determine status
            status = determine_status(pct, WARNING_THRESHOLD, CRIT_THRESHOLD)
            
            entries.append({
                "server": server_name,
                "filesystem": filesystem,
                "size": size,
                "used": used,
                "available": available,
                "capacity_pct": pct,
                "mount_point": mount_point,
                "status": str(status)
            })
            
        except Exception as e:
            errors.append(f"Error parsing line '{line[:50]}': {str(e)}")
    
    # Overall status is the worst of all entries
    overall_status = Status.OK
    if any(e.get("status") == str(Status.CRITICAL) for e in entries):
        overall_status = Status.CRITICAL
    elif any(e.get("status") == str(Status.WARNING) for e in entries):
        overall_status = Status.WARNING
    
    message = f"Checked {len(entries)} filesystems"
    if overall_status != Status.OK:
        critical_count = sum(1 for e in entries if e.get("status") == str(Status.CRITICAL))
        warning_count = sum(1 for e in entries if e.get("status") == str(Status.WARNING))
        message += f" | Critical: {critical_count}, Warning: {warning_count}"
    
    return CheckResult(
        check_name="STORAGE_CHECK",
        status=overall_status,
        details=entries,
        message=message,
        errors=errors
    )


# ============================================================================
# HEALTH CHECK FUNCTIONS
# ============================================================================

def get_os_info(client: paramiko.SSHClient) -> CheckResult:
    """Get OS information with fallback commands."""
    commands = {
        "hostname": "hostname",
        "uname": "uname -a",
        "uptime": "uptime",
        "os_name": "cat /etc/os-release 2>/dev/null || cat /etc/release 2>/dev/null || uname -sr",
        "cpu": "psrinfo -vp 2>/dev/null | head -6 || lscpu 2>/dev/null | head -10 || uname -p",
        "memory": "prtconf 2>/dev/null | grep 'Memory size' || free -h 2>/dev/null | head -2 || echo 'N/A'"
    }
    
    results = {}
    errors = []
    
    for key, cmd in commands.items():
        out, err, rc = run_command(client, cmd)
        if rc == 0 and out:
            results[key] = out.strip()
        else:
            results[key] = "Unable to retrieve"
            if err:
                errors.append(f"{key}: {err[:100]}")
    
    return CheckResult(
        check_name="OS_INFO",
        status=Status.OK,
        details=[results],
        message=f"Hostname: {results.get('hostname', 'N/A')}",
        errors=errors
    )


def get_rac_cluster_info(client: paramiko.SSHClient, server_name: str) -> CheckResult:
    """Get RAC cluster information with comprehensive error handling."""
    result = {
        "is_rac": False,
        "cluster_name": "N/A",
        "nodes": [],
        "crs_status": [],
        "vip_info": [],
        "status": str(Status.OK)
    }
    
    # Check if CRS is available
    out, err, rc = run_command(
        client, 
        "crsctl check cluster -all 2>/dev/null || echo 'CRS_NOT_FOUND'; olsnodes -n 2>/dev/null || echo 'NOT_RAC_NODE'"
    )
    
    if rc != 0 or not out or "CRS_NOT_FOUND" in out or "NOT_RAC_NODE" in out:
        result["nodes"].append(f"{server_name} (Standalone)")
        return CheckResult(
            check_name="RAC_CLUSTER",
            status=Status.OK,
            details=[result],
            message="Standalone server (no RAC detected)"
        )
    
    # Parse RAC status
    crs_lines = out.splitlines()
    is_rac = any(code in out for code in ["CRS-4537", "CRS-4529", "CRS-4533"]) or \
             "Cluster Ready Services is online" in out
    
    result["is_rac"] = is_rac
    
    # Check for warning/critical conditions
    status = Status.OK
    if any(code in out for code in ["CRS-4535", "CRS-4530"]) or "offline" in out.lower():
        status = Status.WARNING
    if "could not contact" in out.lower() or "CRS-4539" in out:
        status = Status.CRITICAL
    
    result["status"] = str(status)
    
    # Collect CRS status lines
    for line in crs_lines:
        line = line.strip()
        if line and not line.startswith("****"):
            result["crs_status"].append(line)
    
    # Get node list
    nodes_out, _, _ = run_command(client, "olsnodes -n 2>/dev/null || echo 'NOT_RAC_NODE'")
    nodes = []
    if nodes_out and "NOT_RAC_NODE" not in nodes_out:
        for node in nodes_out.splitlines():
            parts = node.strip().split()
            if len(parts) >= 2:
                nodes.append(parts[0].rstrip(':'))
            elif parts:
                nodes.append(parts[0].rstrip(':'))
    
    result["nodes"] = nodes if nodes else [server_name]
    
    # Get cluster name if RAC
    if is_rac:
        cfg_out, _, _ = run_command(
            client,
            "cat /grid/product/19c/crs/install/crsconfig_params 2>/dev/null | grep CLUSTER_NAME"
        )
        if cfg_out:
            for line in cfg_out.splitlines():
                if "CLUSTER_NAME" in line and "=" in line:
                    result["cluster_name"] = line.split("=")[-1].strip()
                    break
    
    message = f"RAC: {'Yes' if is_rac else 'No'} | Cluster: {result['cluster_name']} | Nodes: {', '.join(result['nodes'])}"
    
    return CheckResult(
        check_name="RAC_CLUSTER",
        status=status,
        details=[result],
        message=message
    )


def get_crsctl_resources(client: paramiko.SSHClient) -> CheckResult:
    """Get CRSCTL resource status with robust parsing."""
    out, err, rc = run_command(client, "crsctl status resource -t 2>/dev/null")
    
    if rc != 0 or not out:
        return CheckResult(
            check_name="CRSCTL_RESOURCES",
            status=Status.UNKNOWN,
            message="crsctl command failed or no output",
            errors=[err or "No output from crsctl status resource"]
        )
    
    resource = {}
    current_res = None
    
    # Patterns for parsing crsctl output
    res_name_pattern = re.compile(r'^(ora\.[\w\.]+)$')
    detail_pattern = re.compile(r'^(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)$')
    
    for line in out.splitlines():
        line = line.strip()
        if not line or line.startswith("---") or 'Name' in line:
            continue
            
        name_match = res_name_pattern.match(line)
        if name_match:
            current_res = name_match.group(1)
            if current_res not in resource:
                resource[current_res] = []
            continue
            
        if current_res:
            detail_match = detail_pattern.match(line)
            if detail_match:
                instance_id = detail_match.group(1) if detail_match.group(1) else "1"
                target = detail_match.group(2)
                state = detail_match.group(3)
                server = detail_match.group(4)
                details = detail_match.group(5).strip()
                
                # Determine status
                res_status = Status.OK
                if (state != "ONLINE" or target != "ONLINE") and server:
                    res_status = Status.CRITICAL
                
                entry = {
                    "index": instance_id,
                    "target": target,
                    "state": state,
                    "server": server,
                    "details": details,
                    "status": str(res_status)
                }
                resource[current_res].append(entry)
    
    # Determine overall status
    overall_status = Status.OK
    critical_resources = []
    for res_name, instances in resource.items():
        for inst in instances:
            if inst.get("status") == str(Status.CRITICAL):
                overall_status = Status.CRITICAL
                critical_resources.append(res_name)
    
    message = f"Found {len(resource)} resources"
    if critical_resources:
        message += f" | Critical: {', '.join(critical_resources[:3])}"
    
    return CheckResult(
        check_name="CRSCTL_RESOURCES",
        status=overall_status,
        details=[{"resources": resource}],
        message=message
    )


def get_db_instances(client: paramiko.SSHClient, server_name: str) -> CheckResult:
    """Get database instance status with multiple fallback methods."""
    instances = []
    errors = []
    
    # Method 1: Try srvctl config database
    config_out, config_err, config_rc = run_command(
        client, 
        "srvctl config database 2>/dev/null"
    )
    
    # If srvctl fails, fallback to process check
    if config_rc != 0 or not config_out:
        if any(err_code in (config_out or "") for err_code in ["PRCR-1119", "PRCR-1115", "CRS-0184"]):
            # Try process-based detection
            ps_out, ps_err, ps_rc = run_command(
                client,
                "ps -ef 2>/dev/null | grep ora_pmon | grep -v grep"
            )
            
            if ps_out:
                for line in ps_out.splitlines():
                    m = re.search(r'ora_pmon_(\S+)', line)
                    if m:
                        sid = m.group(1)
                        instances.append({
                            "db_name": sid,
                            "instance": sid,
                            "node": server_name,
                            "state": "running",
                            "status": str(Status.OK)
                        })
                
                return CheckResult(
                    check_name="DB_INSTANCES",
                    status=Status.OK,
                    details=instances,
                    message=f"Found {len(instances)} instance(s) via process check"
                )
            else:
                return CheckResult(
                    check_name="DB_INSTANCES",
                    status=Status.UNKNOWN,
                    message="srvctl not found and no running instances detected",
                    errors=[config_err or "No database instances found"]
                )
        else:
            return CheckResult(
                check_name="DB_INSTANCES",
                status=Status.UNKNOWN,
                message="srvctl command failed",
                errors=[config_err or "Unknown srvctl error"]
            )
    
    # Parse srvctl config output
    db_names = [db.strip() for db in config_out.splitlines() if db.strip()]
    
    for db in db_names:
        status_out, status_err, status_rc = run_command(
            client,
            f"srvctl status database -d {db} 2>/dev/null"
        )
        
        if status_rc != 0 or not status_out:
            errors.append(f"Failed to get status for {db}: {status_err}")
            continue
        
        # Parse instance information
        inst_pattern = re.compile(
            r'Instance\s+(\S+)\s+is\s+(running|not running)\s+on\s+node\s+(\S+)',
            re.IGNORECASE
        )
        db_pattern = re.compile(
            r'Database\s+(\S+)\s+is\s+(running|not running)',
            re.IGNORECASE
        )
        
        insts = inst_pattern.findall(status_out)
        db_match = db_pattern.findall(status_out)
        
        if insts:
            for inst_name, state, node in insts:
                inst_status = Status.OK if state.lower() == "running" else Status.CRITICAL
                instances.append({
                    "db_name": db,
                    "instance": inst_name,
                    "node": node,
                    "state": state,
                    "status": str(inst_status)
                })
        elif db_match and "is running" in status_out.lower():
            instances.append({
                "db_name": db,
                "instance": db,
                "node": server_name,
                "state": "running",
                "status": str(Status.OK)
            })
        elif db_match and "not running" in status_out.lower():
            instances.append({
                "db_name": db,
                "instance": db,
                "node": server_name,
                "state": "not running",
                "status": str(Status.CRITICAL)
            })
    
    # Determine overall status
    overall_status = Status.OK
    if any(i.get("status") == str(Status.CRITICAL) for i in instances):
        overall_status = Status.CRITICAL
    elif not instances:
        overall_status = Status.UNKNOWN
    
    return CheckResult(
        check_name="DB_INSTANCES",
        status=overall_status,
        details=instances,
        message=f"Found {len(instances)} instance(s)",
        errors=errors
    )


def get_listener_status(client: paramiko.SSHClient, is_rac: bool) -> CheckResult:
    """Get listener status with srvctl and lsnrctl checks."""
    results = []
    overall_status = Status.OK
    
    # SRVCTL listener check
    lsnr_out, lsnr_err, lsnr_rc = run_command(
        client,
        "srvctl status listener 2>/dev/null"
    )
    
    if lsnr_out:
        srvctl_listener = {
            "check_name": "SRVCTL_LISTENER",
            "details": [line.strip() for line in lsnr_out.splitlines() if line.strip()],
            "status": str(Status.CRITICAL)  # Default, will update
        }
        
        for line in lsnr_out.splitlines():
            if "is running" in line.lower():
                srvctl_listener["status"] = str(Status.OK)
                break
        
        if srvctl_listener["status"] == str(Status.CRITICAL):
            overall_status = Status.CRITICAL
            
        results.append(srvctl_listener)
    
    # SCAN listener check for RAC
    if is_rac:
        scan_out, scan_err, scan_rc = run_command(
            client,
            "srvctl status scan 2>/dev/null; srvctl status scan_listener 2>/dev/null"
        )
        
        if scan_out:
            srvctl_scan = {
                "check_name": "SRVCTL_SCAN",
                "details": [line.strip() for line in scan_out.splitlines() if line.strip()],
                "status": str(Status.CRITICAL)
            }
            
            for line in scan_out.splitlines():
                if "is running" in line.lower():
                    srvctl_scan["status"] = str(Status.OK)
                    break
            
            if srvctl_scan["status"] == str(Status.CRITICAL):
                overall_status = Status.CRITICAL
                
            results.append(srvctl_scan)
    
    # LSNRCTL detailed check
    lsnrctl_out, lsnrctl_err, lsnrctl_rc = run_command(
        client,
        "lsnrctl status 2>/dev/null | grep -E 'Alias|Status|Start Date|Uptime|Service|Instance'"
    )
    
    if lsnrctl_out and "cannot communicate" not in lsnrctl_out.lower():
        # Parse listener details
        listener_names = []
        for line in lsnrctl_out.splitlines():
            if "Alias" in line:
                parts = line.split()
                if len(parts) >= 2:
                    listener_names.append(parts[-1])
        
        for lsnr_name in set(listener_names):
            lsnr_det = {
                "check_name": "LSNRCTL_STATUS",
                "listener_name": lsnr_name,
                "alias": "UNKNOWN",
                "listener_status": "OFFLINE",
                "start_date": "UNKNOWN",
                "uptime": "UNKNOWN",
                "services": [],
                "status": str(Status.CRITICAL)
            }
            
            lsnr_sts, _, _ = run_command(
                client,
                f"lsnrctl status {lsnr_name} 2>/dev/null | grep -E 'Alias|Status|Start Date|Uptime|Service|Instance'"
            )
            
            if lsnr_sts:
                for line in lsnr_sts.splitlines():
                    line = line.strip()
                    if "Alias" in line:
                        lsnr_det["alias"] = line.split()[-1] if len(line.split()) > 1 else "UNKNOWN"
                    elif "Start Date" in line:
                        lsnr_det["start_date"] = " ".join(line.split()[2:])
                    elif "Uptime" in line:
                        lsnr_det["uptime"] = line.split()[-1] if len(line.split()) > 1 else "UNKNOWN"
                        lsnr_det["listener_status"] = "ONLINE"
                        lsnr_det["status"] = str(Status.OK)
                
                # Parse services
                service_pattern = re.compile(r'Service\s+"([^"]+)"')
                instance_pattern = re.compile(r'Instance\s+"([^"]+)",\s+status\s+(\w+)')
                
                current_service = None
                for line in lsnr_sts.splitlines():
                    svc_match = service_pattern.search(line)
                    if svc_match:
                        current_service = {
                            "service_name": svc_match.group(1),
                            "instances": [],
                            "status": "UNKNOWN"
                        }
                    
                    inst_match = instance_pattern.search(line)
                    if inst_match and current_service:
                        current_service["instances"].append({
                            "instance": inst_match.group(1),
                            "status": inst_match.group(2)
                        })
                        if inst_match.group(2).upper() == "READY":
                            current_service["status"] = "READY"
                
                if current_service:
                    lsnr_det["services"].append(current_service)
            
            if lsnr_det["status"] == str(Status.CRITICAL):
                overall_status = Status.CRITICAL
                
            results.append(lsnr_det)
    
    message = f"Checked {len(results)} listener configurations"
    if overall_status != Status.OK:
        offline = [r.get("listener_name", r.get("check_name")) for r in results 
                   if r.get("status") == str(Status.CRITICAL)]
        message += f" | Offline: {', '.join(offline)}"
    
    return CheckResult(
        check_name="LISTENER_STATUS",
        status=overall_status,
        details=results,
        message=message
    )


def get_asm_status(client: paramiko.SSHClient) -> CheckResult:
    """Get ASM disk group status with usage calculation."""
    out, err, rc = run_command(
        client,
        "asmcmd lsdg 2>/dev/null || echo 'ASMCMD_NOT_FOUND'"
    )
    
    if rc != 0 or not out or "ASMCMD_NOT_FOUND" in out:
        return CheckResult(
            check_name="ASM_STATUS",
            status=Status.NOT_CONFIGURED,
            message="ASMCMD not found or not an ASM node"
        )
    
    asm_disks = []
    errors = []
    
    for line in out.splitlines():
        if not line.strip() or "State" in line:
            continue
            
        parts = line.split()
        if len(parts) < 9:
            continue
            
        try:
            name = parts[-1].rstrip('/')
            state = parts[0]
            total_mb = safe_float(parts[7])
            free_mb = safe_float(parts[8])
            
            used_pct = round((total_mb - free_mb) / total_mb * 100, 1) if total_mb > 0 else 0
            
            status = determine_status(used_pct, WARNING_THRESHOLD, CRIT_THRESHOLD)
            
            asm_disks.append({
                "name": name,
                "total_mb": total_mb,
                "free_mb": free_mb,
                "used_pct": used_pct,
                "state": state,
                "status": str(status)
            })
            
        except Exception as e:
            errors.append(f"Error parsing ASM line: {str(e)}")
    
    # Overall status
    overall_status = Status.OK
    if any(d.get("status") == str(Status.CRITICAL) for d in asm_disks):
        overall_status = Status.CRITICAL
    elif any(d.get("status") == str(Status.WARNING) for d in asm_disks):
        overall_status = Status.WARNING
    
    message = f"Found {len(asm_disks)} disk group(s)"
    if overall_status != Status.OK:
        critical_disks = [d["name"] for d in asm_disks if d.get("status") == str(Status.CRITICAL)]
        warning_disks = [d["name"] for d in asm_disks if d.get("status") == str(Status.WARNING)]
        if critical_disks:
            message += f" | Critical: {', '.join(critical_disks)}"
        if warning_disks:
            message += f" | Warning: {', '.join(warning_disks)}"
    
    return CheckResult(
        check_name="ASM_STATUS",
        status=overall_status,
        details=asm_disks,
        message=message,
        errors=errors
    )


def get_scan_info(client: paramiko.SSHClient, is_rac: bool) -> CheckResult:
    """Get SCAN configuration information."""
    if not is_rac:
        return CheckResult(
            check_name="SCAN_INFO",
            status=Status.NOT_CONFIGURED,
            message="SCAN not applicable for standalone server"
        )
    
    out, err, rc = run_command(client, "srvctl config scan 2>/dev/null")
    
    if rc != 0 or not out:
        return CheckResult(
            check_name="SCAN_INFO",
            status=Status.UNKNOWN,
            message="SCAN info not available",
            errors=[err or "No SCAN configuration found"]
        )
    
    scan_lines = [l.strip() for l in out.splitlines() if l.strip()]
    
    return CheckResult(
        check_name="SCAN_INFO",
        status=Status.OK,
        details=[{"scan_config": scan_lines}],
        message=f"SCAN configured: {len(scan_lines)} line(s)"
    )


def check_goldengate(client: paramiko.SSHClient, gg_enabled: bool) -> CheckResult:
    """Check GoldenGate status."""
    if not gg_enabled:
        return CheckResult(
            check_name="GOLDENGATE",
            status=Status.NOT_CONFIGURED,
            message="GoldenGate check not enabled for this server"
        )
    
    # Check for MGR process
    out, err, rc = run_command(
        client,
        "ps -ef | grep -iw 'mgr' | grep -v grep | head -5 2>/dev/null"
    )
    
    if out and "mgr" in out.lower():
        return CheckResult(
            check_name="GOLDENGATE",
            status=Status.OK,
            details=[{"process": "MGR", "status": "running"}],
            message="GoldenGate MGR process is running"
        )
    
    # Check if GoldenGate is installed
    gg_check, gg_err, gg_rc = run_command(
        client,
        "which ggsci 2>/dev/null || find /ggate/ -name ggsci 2>/dev/null | head -1"
    )
    
    if not gg_check or "no ggsci" in gg_check.lower():
        return CheckResult(
            check_name="GOLDENGATE",
            status=Status.UNKNOWN,
            message="GoldenGate not found",
            errors=["GoldenGate software not installed or not in PATH"]
        )
    
    return CheckResult(
        check_name="GOLDENGATE",
        status=Status.CRITICAL,
        details=[{"process": "MGR", "status": "not running"}],
        message="GoldenGate installed but MGR process not running"
    )


def check_backup_age(client: paramiko.SSHClient, patterns: List[str]) -> CheckResult:
    """Check export backup file age with pattern matching."""
    if not patterns:
        return CheckResult(
            check_name="BACKUP_AGE",
            status=Status.NOT_CONFIGURED,
            message="No export backup patterns configured for this server"
        )
    
    # Find backup files
    cmd = (
        "/usr/gnu/bin/find /oracle/exports/daily /orabkp/exports/daily "
        "-maxdepth 1 -type f "
        r"-name '*.log' -o -name '*.dmp' "
        "2>/dev/null"
    )
    
    out, err, rc = run_command(client, cmd)
    
    if not out or not out.strip():
        return CheckResult(
            check_name="BACKUP_AGE",
            status=Status.UNKNOWN,
            message="No .log or .dmp files found in backup locations",
            errors=["Backup directory empty or not accessible"]
        )
    
    result_entries = []
    errors = []
    
    for fpath in out.splitlines():
        fpath = fpath.strip()
        if not fpath:
            continue
            
        fname = os.path.basename(fpath)
        
        # Check if filename matches any pattern
        if not any(p.lower() in fname.lower() for p in patterns):
            continue
        
        # Escape path for shell
        safe_path = fpath.replace("'", "'\\''")
        
        # Get file modification date
        date_cmd = f"stat -c '%y' '{safe_path}' 2>/dev/null || ls -ld --time-style=full-iso '{safe_path}' 2>/dev/null"
        date_out, date_err, date_rc = run_command(client, date_cmd)
        
        if not date_out or not date_out.strip():
            errors.append(f"Cannot get date for {fname}")
            continue
        
        # Extract date from output
        date_match = re.findall(r'(\d{4})-(\d{2})-(\d{2})', date_out)
        
        if date_match:
            try:
                date_str = "-".join(date_match[0])
                mod_date = datetime.strptime(date_str, "%Y-%m-%d")
                age = (datetime.now() - mod_date).days
                
                status = determine_status(age, 1, 2, higher_is_worse=True)
                # Actually for backup age, older is worse
                # age >= 2: CRITICAL, age >= 1: WARNING
                if age >= 2:
                    status = Status.CRITICAL
                elif age >= 1:
                    status = Status.WARNING
                else:
                    status = Status.OK
                
                result_entries.append({
                    "name": fname,
                    "mod_date": date_str,
                    "age_days": age,
                    "status": str(status)
                })
                
            except ValueError as e:
                errors.append(f"Date parse error for {fname}: {str(e)}")
        else:
            errors.append(f"Date pattern not found for {fname}")
    
    # Determine overall status
    overall_status = Status.OK
    if any(e.get("status") == str(Status.CRITICAL) for e in result_entries):
        overall_status = Status.CRITICAL
    elif any(e.get("status") == str(Status.WARNING) for e in result_entries):
        overall_status = Status.WARNING
    elif not result_entries:
        overall_status = Status.UNKNOWN
    
    message = f"Checked {len(result_entries)} backup file(s)"
    if overall_status != Status.OK:
        old_files = [e["name"] for e in result_entries if e.get("status") != str(Status.OK)]
        message += f" | Stale: {', '.join(old_files)}"
    
    return CheckResult(
        check_name="BACKUP_AGE",
        status=overall_status,
        details=result_entries,
        message=message,
        errors=errors
    )


def check_alert_log(client: paramiko.SSHClient) -> CheckResult:
    """Check Oracle alert log for critical errors."""
    # Find alert log location
    log_loc_cmd = 'find $ORACLE_BASE/diag -name "alert_*.log" 2>/dev/null | head -1'
    log_out, log_err, log_rc = run_command(client, log_loc_cmd)
    
    if not log_out or not log_out.strip():
        return CheckResult(
            check_name="ALERT_LOG",
            status=Status.UNKNOWN,
            message="Alert log not found",
            errors=["Cannot locate alert log file"]
        )
    
    log_file = log_out.strip().splitlines()[0]
    
    # Get last 2000 lines
    content_cmd = f"tail -2000 '{log_file.replace("'", "'\\''")}' 2>/dev/null"
    content_out, content_err, content_rc = run_command(client, content_cmd)
    
    if not content_out:
        return CheckResult(
            check_name="ALERT_LOG",
            status=Status.UNKNOWN,
            message="Cannot read alert log content",
            errors=[content_err or "Empty alert log content"]
        )
    
    # Search for critical patterns
    crit_pattern = re.compile(
        '|'.join(f'({p})' for p in ALERT_CRIT_PATTERNS),
        re.IGNORECASE
    )
    
    matches = crit_pattern.findall(content_out)
    
    # Flatten matches and count
    found_errors = []
    for match_group in matches:
        for m in match_group:
            if m:
                found_errors.append(m)
    
    error_counts = dict(Counter(found_errors))
    
    if not error_counts:
        return CheckResult(
            check_name="ALERT_LOG",
            status=Status.OK,
            details=[],
            message="No critical alert log entries found in last 2000 lines"
        )
    
    # Determine status based on error types
    status = Status.WARNING
    critical_patterns = ['ORA-00600', 'ORA-07445', 'ORA-01578', 'DeadLock', 'Instance shutdown']
    if any(any(cp in err for cp in critical_patterns) for err in found_errors):
        status = Status.CRITICAL
    
    details = [{"error": err, "count": count} for err, count in error_counts.items()]
    
    return CheckResult(
        check_name="ALERT_LOG",
        status=status,
        details=details,
        message=f"Found {len(error_counts)} unique error types ({sum(error_counts.values())} total occurrences)",
        raw_output=content_out[:5000]  # Limit raw output size
    )


# ============================================================================
# REPORT GENERATION
# ============================================================================

def generate_summary(all_reports: List[Dict], all_errors: List[str]) -> List[Dict]:
    """
    Generate summary of only WARNING and CRITICAL items.
    Format: Server Name | Check Name | Details | Status
    """
    summary = []
    
    for report in all_reports:
        server_name = report.get("name", "UNKNOWN")
        
        for check_key, check_result in report.items():
            # Skip non-check fields
            if not isinstance(check_result, dict) or "status" not in check_result:
                continue
            
            status = check_result.get("status", "UNKNOWN")
            
            # Only include WARNING and CRITICAL in summary
            if status not in [str(Status.WARNING), str(Status.CRITICAL)]:
                continue
            
            check_name = check_result.get("check_name", check_key)
            message = check_result.get("message", "")
            details = check_result.get("details", [])
            
            # Extract detail summary
            detail_str = message
            if details and isinstance(details, list) and len(details) > 0:
                if isinstance(details[0], dict):
                    # Try to extract meaningful info
                    if "status" in str(details[0]):
                        critical_items = [
                            d for d in details 
                            if isinstance(d, dict) and d.get("status") in [str(Status.WARNING), str(Status.CRITICAL)]
                        ]
                        if critical_items:
                            names = [
                                d.get("name", d.get("instance", d.get("filesystem", "item"))) 
                                for d in critical_items[:3]
                            ]
                            detail_str = f"{message} | Issues: {', '.join(names)}"
            
            summary.append({
                "server": server_name,
                "check_name": check_name,
                "details": detail_str,
                "status": status
            })
    
    # Add connection/processing errors to summary
    for error in all_errors:
        # Try to extract server name from error
        server_match = re.match(r'^(\w+):', error)
        server = server_match.group(1) if server_match else "UNKNOWN"
        
        summary.append({
            "server": server,
            "check_name": "CONNECTION_ERROR",
            "details": error,
            "status": str(Status.CRITICAL)
        })
    
    return summary


def generate_report_and_save(all_reports: List[Dict], all_errors: List[str], summary: List[Dict]):
    """Generate formatted text report and save to file."""
    WIDTH = 35
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"Oracle_healthCheck_report_V4_{timestamp}.txt"
    
    report_lines = []
    
    def log_line(key: str = "", val: str = ""):
        line = f"{key.ljust(WIDTH)} {val}"
        report_lines.append(line)
        print(line)
    
    def separator(char: str = "=", length: int = 100):
        line = char * length
        report_lines.append(line)
        print(line)
    
    # Header
    separator("=")
    log_line("ORACLE DATABASE HEALTH CHECK REPORT")
    log_line("Generated:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    log_line("Version:", "V4 Improved")
    separator("=")
    report_lines.append("")
    print()
    
    # Summary Section (WARNING/CRITICAL only)
    separator("-")
    log_line("SUMMARY - ISSUES REQUIRING ATTENTION")
    separator("-")
    
    if summary:
        # Table header
        header = f"{'Server':<15} {'Check':<20} {'Status':<10} {'Details'}"
        report_lines.append(header)
        print(header)
        separator("-", 100)
        
        for item in summary:
            # Wrap details if too long
            detail = item["details"][:60] + "..." if len(item["details"]) > 60 else item["details"]
            line = f"{item['server']:<15} {item['check_name']:<20} {item['status']:<10} {detail}"
            report_lines.append(line)
            print(line)
    else:
        log_line("No issues found - all checks passed!")
    
    report_lines.append("")
    print()
    separator("=")
    log_line("DETAILED REPORT")
    separator("=")
    report_lines.append("")
    print()
    
    # Detailed reports per server
    for srv_report in all_reports:
        separator("-")
        log_line("SERVER:", f"{srv_report['name']} - ({srv_report['host']})")
        separator("-")
        
        # OS Info
        os_info = srv_report.get("os_info", {})
        if isinstance(os_info, dict):
            log_line("Host Name:", os_info.get("details", [{}])[0].get("hostname", "N/A") if os_info.get("details") else "N/A")
            log_line("OS Info:", os_info.get("message", "N/A"))
        log_line()
        
        # RAC/Cluster
        rac_info = srv_report.get("rac_cluster", {})
        if isinstance(rac_info, dict):
            log_line("RAC/Cluster:", rac_info.get("message", "N/A"))
        log_line()
        
        # Database Instances
        log_line("Database Instances:")
        db_info = srv_report.get("db_instances", {})
        if isinstance(db_info, dict) and db_info.get("details"):
            for inst in db_info["details"]:
                log_line(f"  DB:", inst.get("db_name", "N/A"))
                log_line(f"  Instance:", inst.get("instance", "N/A"))
                log_line(f"  Node:", inst.get("node", "N/A"))
                log_line(f"  State:", inst.get("state", "N/A"))
                log_line(f"  Status:", inst.get("status", "N/A"))
                log_line()
        else:
            log_line("  ERROR:", db_info.get("message", "No instance detected"))
        log_line()
        
        # Listeners
        log_line("Listener & SCAN:")
        lsnr_info = srv_report.get("listener_status", {})
        if isinstance(lsnr_info, dict) and lsnr_info.get("details"):
            for l in lsnr_info["details"]:
                if isinstance(l, dict):
                    for key, val in l.items():
                        if key != "details":
                            log_line(f"  {key}:", str(val))
                log_line()
        else:
            log_line("  No listener detected")
        log_line()
        
        # Resources
        log_line("Resources Status:")
        res_info = srv_report.get("crsctl_resources", {})
        if isinstance(res_info, dict) and res_info.get("details"):
            for res in res_info["details"]:
                if isinstance(res, dict) and "resources" in res:
                    for res_name, instances in res["resources"].items():
                        log_line(f"  {res_name}:")
                        for inst in instances:
                            log_line(f"    {inst.get('server', 'N/A')}: {inst.get('state', 'N/A')} ({inst.get('status', 'N/A')})")
        else:
            log_line("  CRSCTL resource status check failed")
        log_line()
        
        # SCAN Info
        log_line("Scan Listener Status:")
        scan_info = srv_report.get("scan_info", {})
        if isinstance(scan_info, dict) and scan_info.get("details"):
            for item in scan_info["details"]:
                if isinstance(item, dict) and "scan_config" in item:
                    for line in item["scan_config"]:
                        log_line(f"  {line}")
        else:
            log_line("  No SCAN LISTENER info found")
        log_line()
        
        # ASM
        log_line("ASM Disk Group (DATA/REC):")
        asm_info = srv_report.get("asm_status", {})
        if isinstance(asm_info, dict) and asm_info.get("details"):
            for disk in asm_info["details"]:
                log_line(f"  {disk.get('name', 'N/A')}: "
                        f"Total: {disk.get('total_mb', 0)} MB | "
                        f"Free: {disk.get('free_mb', 0)} MB | "
                        f"Used: {disk.get('used_pct', 0)}% | "
                        f"Status: {disk.get('status', 'N/A')}")
        else:
            log_line("  No DATA/REC disk groups found or asmcmd unavailable")
        log_line()
        
        # GoldenGate
        gg_info = srv_report.get("goldengate", {})
        if isinstance(gg_info, dict):
            log_line("GoldenGate:", gg_info.get("message", "N/A"))
        log_line()
        
        # Storage
        log_line("Storage Utilization:")
        storage_info = srv_report.get("storage", {})
        if isinstance(storage_info, dict) and storage_info.get("details"):
            header = (f"{'Filesystem':<30} {'Mount':<25} {'Size':<10} {'Used':<10} "
                     f"{'Avail':<10} {'Use%':<8} {'Status':<10}")
            report_lines.append(header)
            print(header)
            for e in storage_info["details"]:
                line = (f"{e.get('filesystem', 'N/A')[:28]:<30} "
                       f"{e.get('mount_point', 'N/A')[:23]:<25} "
                       f"{e.get('size', 'N/A'):<10} "
                       f"{e.get('used', 'N/A'):<10} "
                       f"{e.get('available', 'N/A'):<10} "
                       f"{str(e.get('capacity_pct', 'N/A')) + '%':<8} "
                       f"{e.get('status', 'N/A'):<10}")
                report_lines.append(line)
                print(line)
        log_line()
        
        # Backup Check
        log_line("Export Backup Logs (Age Check):")
        backup_info = srv_report.get("backup_age", {})
        if isinstance(backup_info, dict) and backup_info.get("details"):
            for item in backup_info["details"]:
                log_line(f"  {item.get('name', 'N/A')}: "
                        f"Modified: {item.get('mod_date', 'N/A')} | "
                        f"Age: {item.get('age_days', 'N/A')} days | "
                        f"Status: {item.get('status', 'N/A')}")
        else:
            log_line("  " + backup_info.get("message", "No backup check performed"))
        log_line()
        
        # Alert Log
        log_line("Critical Alert Log Entries:")
        alert_info = srv_report.get("alert_log", {})
        if isinstance(alert_info, dict) and alert_info.get("details"):
            for item in alert_info["details"]:
                log_line(f"  {item.get('error', 'N/A')}: {item.get('count', 0)} occurrence(s)")
        else:
            log_line("  " + alert_info.get("message", "No critical alert log entries found"))
        
        report_lines.append("")
        print()
    
    # Error section
    if all_errors:
        separator("=")
        log_line("CONNECTION & PROCESSING ERRORS")
        separator("=")
        for err in all_errors:
            log_line(f"* {err}")
    
    # Footer
    separator("=")
    log_line("Health check complete.")
    log_line("Report saved to:", os.path.abspath(filename))
    separator("=")
    
    # Write to file
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write("\n".join(report_lines))
        print(f"\nReport successfully saved to: {os.path.abspath(filename)}")
    except Exception as e:
        print(f"\nERROR: Failed to save report: {str(e)}")
        sys.exit(1)


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def execute_check(check_func: Callable, *args, **kwargs) -> Dict[str, Any]:
    """Wrapper to execute a check with exception handling."""
    try:
        result = check_func(*args, **kwargs)
        return result.to_dict()
    except Exception as e:
        return CheckResult(
            check_name=check_func.__name__.upper(),
            status=Status.UNKNOWN,
            message=f"Check failed with exception: {str(e)}",
            errors=[str(e)]
        ).to_dict()


def main():
    """Main execution function."""
    if not SERVERS:
        print("No servers configured. Exiting.")
        sys.exit(1)
    
    all_reports = []
    all_errors = []
    
    print("=" * 60)
    print("ORACLE DATABASE HEALTH CHECK - V4")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    print()
    
    for server in SERVERS:
        server_name = server['name']
        host = server['host']
        gg_check = server.get('gg_check', False)
        expdp_patterns = server.get('expdp_list', [])
        
        print(f"\n{'='*60}")
        print(f"Processing server: {server_name} ({host})")
        print(f"{'='*60}")
        
        report = {
            "name": server_name,
            "host": host,
            "os_info": {},
            "rac_cluster": {},
            "db_instances": {},
            "listener_status": {},
            "crsctl_resources": {},
            "scan_info": {},
            "asm_status": {},
            "goldengate": {},
            "storage": {},
            "backup_age": {},
            "alert_log": {}
        }
        
        ora_client = None
        grid_client = None
        
        try:
            # Connect as Oracle user
            print(f"Connecting as Oracle user to {host}...")
            with SSHConnectionManager(server, ORA_USERNAME, ORA_PASSWORD) as ora_conn:
                if not ora_conn.is_connected():
                    error_msg = f"{server_name}: Oracle connection failed - {ora_conn.connection_error}"
                    all_errors.append(error_msg)
                    print(f"FAILED: {ora_conn.connection_error}")
                    all_reports.append(report)
                    continue
                
                ora_client = ora_conn.client
                print("Oracle user connected successfully.")
                
                # Connect as Grid user
                print(f"Connecting as Grid user to {host}...")
                with SSHConnectionManager(server, GRID_USERNAME, GRID_PASSWORD) as grid_conn:
                    if not grid_conn.is_connected():
                        error_msg = f"{server_name}: Grid connection failed - {grid_conn.connection_error}"
                        all_errors.append(error_msg)
                        print(f"WARNING: {grid_conn.connection_error}")
                        # Continue with Oracle-only checks
                    else:
                        grid_client = grid_conn.client
                        print("Grid user connected successfully.")
                    
                    # Execute all checks
                    print("\nExecuting health checks...")
                    
                    # 1. OS Info (Oracle user)
                    report["os_info"] = execute_check(get_os_info, ora_client)
                    
                    # 2. RAC Cluster (Grid user preferred)
                    rac_client = grid_client if grid_client else ora_client
                    report["rac_cluster"] = execute_check(
                        get_rac_cluster_info, rac_client, server_name
                    )
                    
                    is_rac = False
                    if isinstance(report["rac_cluster"], dict):
                        details = report["rac_cluster"].get("details", [{}])
                        if details and isinstance(details[0], dict):
                            is_rac = details[0].get("is_rac", False)
                    
                    # 3. DB Instances (Oracle user)
                    report["db_instances"] = execute_check(
                        get_db_instances, ora_client, server_name
                    )
                    
                    # 4. Listener Status (Grid user preferred)
                    report["listener_status"] = execute_check(
                        get_listener_status, rac_client, is_rac
                    )
                    
                    # 5. ASM Status (Grid user)
                    report["asm_status"] = execute_check(get_asm_status, rac_client)
                    
                    # 6. SCAN Info (Grid user)
                    report["scan_info"] = execute_check(
                        get_scan_info, rac_client, is_rac
                    )
                    
                    # 7. CRSCTL Resources (Grid user)
                    report["crsctl_resources"] = execute_check(
                        get_crsctl_resources, rac_client
                    )
                    
                    # 8. GoldenGate (Oracle user)
                    report["goldengate"] = execute_check(
                        check_goldengate, ora_client, gg_check
                    )
                    
                    # 9. Storage (Oracle user)
                    raw_df, df_err, df_rc = run_command(ora_client, "df -h 2>/dev/null")
                    if df_err:
                        all_errors.append(f"{server_name}: df command error: {df_err}")
                    report["storage"] = parse_df_output(raw_df or "", server_name).to_dict()
                    
                    # 10. Backup Age (Oracle user)
                    report["backup_age"] = execute_check(
                        check_backup_age, ora_client, expdp_patterns
                    )
                    
                    # 11. Alert Log (Oracle user)
                    report["alert_log"] = execute_check(check_alert_log, ora_client)
                    
                    print(f"\nCompleted checks for {server_name}")
                    
        except Exception as e:
            error_msg = f"{server_name}: Unexpected error: {str(e)}"
            all_errors.append(error_msg)
            print(f"ERROR: {str(e)}")
        
        finally:
            # Connections closed by context managers
            pass
        
        all_reports.append(report)
    
    # Generate summary
    print("\n" + "=" * 60)
    print("GENERATING REPORTS...")
    print("=" * 60)
    
    summary = generate_summary(all_reports, all_errors)
    
    # Generate and save report
    generate_report_and_save(all_reports, all_errors, summary)
    
    # Print summary to console
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    if summary:
        print(f"{'Server':<15} {'Check':<20} {'Status':<10} {'Details'}")
        print("-" * 100)
        for item in summary:
            detail = item["details"][:50] + "..." if len(item["details"]) > 50 else item["details"]
            print(f"{item['server']:<15} {item['check_name']:<20} {item['status']:<10} {detail}")
    else:
        print("All checks passed - no issues found!")
    
    print("\n" + "=" * 60)
    print("HEALTH CHECK COMPLETE")
    print("=" * 60)
    
    # Exit with error code if critical issues found
    critical_count = sum(1 for s in summary if s["status"] == str(Status.CRITICAL))
    if critical_count > 0:
        print(f"\nWARNING: {critical_count} critical issue(s) found!")
        sys.exit(2)
    elif summary:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user.")
        sys.exit(130)
    except Exception as e:
        print(f"\nFatal error: {str(e)}")
        sys.exit(1)
