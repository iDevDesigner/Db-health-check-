#!/usr/bin/env python3
"""
Oracle Database & Grid Infrastructure Health Check Script
Version: 5.0
- Complete refactoring with consistent data structures
- Robust error handling and status tracking
- Summary of only WARNING/CRITICAL issues
- Consistent output format for all checks
"""

import json
import re
import sys
import os
from collections import Counter, defaultdict
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional

import paramiko


# ========================= CONFIGURATION =========================
WARNING_THRESHOLD = 90
CRIT_THRESHOLD = 95

SSH_TIMEOUT = 30
CMD_TIMEOUT = 50

ORA_USERNAME = "oracle"
ORA_PASSWORD = "Ora#1234"          # Change in production / use secrets
GRID_USERNAME = "grid"
GRID_PASSWORD = "Grid#1234"

ALERT_CRIT_PATTERNS = [
    r'ORA-12008', r'ORA-00600', r'ORA-07445', r'ORA-04031',
    r'ORA-01578', r'ORA-00060', r'ORA-00257', r'ORA-16038',
    r'ORA-15130', r'ORA-15050', r'ORA-15051', r'DeadLock',
    r'Checkpoint not complete', r'Block corruption',
    r'Fatal NI connect error', r'Instance shutdown',
    r'Error', r'cannot allocate new log', r'ARC.+Error',
    r'Thread.+cannot allocate new log', r'file .+ needs recovery',
    r'PMON failed to acquire', r'Corrupt block', r'media recovery',
    r'DIAO:kjdqlm', r'LGWR:terminating'
]

SERVERS = [
    {
        "name": "prodsrv1",
        "host": "10.xx.xx.xx",
        "expdp_list": ["expdp_pdb_EXPPDB", "EXPPOP_COMPLETE"],
        "gg_check": False
    },
    # Add more servers as needed
    {
        "name": "prodsrv2",
        "host": "10.xx.xx.xx",
        "expdp_list": ["expdp_pdb1", "expdp_pdb2"],
        "gg_check": False
    },
    # ... etc.
]


# ========================= HELPER FUNCTIONS =========================
def conn_server(server_info: dict, username: str, password: str) -> Tuple[Optional[paramiko.SSHClient], Optional[str]]:
    """Connect via SSH with robust error handling."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=server_info["host"],
            username=username,
            password=password,
            timeout=SSH_TIMEOUT,
            allow_agent=False,
            look_for_keys=False
        )
        return client, None
    except paramiko.AuthenticationException as e:
        return None, f"Authentication error: {e}"
    except paramiko.SSHException as e:
        return None, f"SSH error: {e}"
    except Exception as e:
        return None, f"Connection error: {e}"


def run_cmd(client: paramiko.SSHClient, cmd: str) -> Tuple[str, str, int]:
    """Run remote command safely."""
    try:
        full_cmd = f'. \~/.profile 2>/dev/null || . \~/.bashrc 2>/dev/null || true; {cmd}'
        stdin, stdout, stderr = client.exec_command(full_cmd, timeout=CMD_TIMEOUT)
        out = stdout.read().decode('utf-8').strip()
        err = stderr.read().decode('utf-8').strip()
        code = stdout.channel.recv_exit_status()
        return out, err, code
    except Exception as e:
        return "", f"Command execution error: {e}", 1


def safe_int(val: str, default=0) -> int:
    try:
        return int(val.replace('%', '').strip())
    except (ValueError, TypeError):
        return default


def parse_status(pct: int) -> str:
    if pct > CRIT_THRESHOLD:
        return "CRITICAL"
    elif pct > WARNING_THRESHOLD:
        return "WARNING"
    return "OK"


# ========================= CHECK FUNCTIONS =========================
def get_os_info(client: paramiko.SSHClient) -> Dict:
    """Gather basic OS information."""
    results = {}
    cmds = {
        "hostname": "hostname",
        "uname": "uname -a",
        "uptime": "uptime",
        "os_name": "cat /etc/os-release 2>/dev/null || cat /etc/redhat-release 2>/dev/null || uname -sr",
        "cpu": "nproc || cat /proc/cpuinfo | grep -c processor",
        "memory": "free -h | grep Mem || prtconf 2>/dev/null | grep Memory"
    }
    for key, cmd in cmds.items():
        out, _, _ = run_cmd(client, cmd)
        results[key] = out or "N/A"
    return results


def parse_df_output(output: str, server_name: str) -> Tuple[List[Dict], List[str]]:
    """Parse df -h output consistently."""
    entries = []
    parse_errors = []
    if not output:
        parse_errors.append("No output from df command")
        return entries, parse_errors

    for ln in output.strip().splitlines():
        if not ln or ln.startswith('Filesystem') or 'capacity' in ln.lower():
            continue
        p = ln.split()
        if len(p) < 6:
            parse_errors.append(f"Skipped unparsable line: {ln}")
            continue
        try:
            pct = safe_int(p[4])
            st = parse_status(pct)
            entries.append({
                "server": server_name,
                "status": st,
                "size": p[1],
                "used": p[2],
                "available": p[3],
                "capacity": pct,
                "mount_point": p[5],
                "filesystem": p[0],
                "usage_pct": pct
            })
        except Exception as e:
            parse_errors.append(f"Error parsing line: {ln} -> {e}")
    return entries, parse_errors


def get_crsctl_resources(client: paramiko.SSHClient) -> List[Dict]:
    """Parse crsctl status resource output."""
    out, _, _ = run_cmd(client, "crsctl status resource -t 2>/dev/null")
    resources = []
    if not out:
        return resources

    lines = out.splitlines()
    current_res = None
    res_name_pattern = re.compile(r'^(ora\..+?)\s')
    detail_pattern = re.compile(r'\s*(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)$')

    for line in lines:
        line = line.strip()
        if not line or line.startswith('---') or 'Name' in line:
            continue

        name_match = res_name_pattern.match(line)
        if name_match:
            current_res = name_match.group(1)
            continue

        if current_res:
            detail_match = detail_pattern.match(line)
            if detail_match:
                status = "OK" if detail_match.group(3) == "ONLINE" else "CRITICAL"
                resources.append({
                    "instance_id": detail_match.group(1),
                    "target": detail_match.group(2),
                    "state": detail_match.group(3),
                    "server": detail_match.group(4),
                    "details": detail_match.group(5).strip(),
                    "status": status
                })
    return resources


def get_db_instances(client: paramiko.SSHClient, server_name: str) -> List[Dict]:
    """Check database instances."""
    instances = []
    config_out, _, _ = run_cmd(client, "srvctl config database 2>/dev/null")
    if not config_out:
        return instances

    db_names = [db.strip() for db in config_out.splitlines() if db.strip()]
    for db in db_names:
        status_out, _, _ = run_cmd(client, f"srvctl status database -d {db} 2>/dev/null")
        # Simplified - you can expand regex parsing
        status = "OK" if "running" in status_out.lower() else "CRITICAL"
        instances.append({
            "db_name": db,
            "instance": db,  # adjust for RAC
            "node": server_name,
            "state": "running" if "running" in status_out.lower() else "not running",
            "status": status
        })
    return instances


def get_listener_status(client: paramiko.SSHClient, is_rac: bool) -> List[Dict]:
    """Listener and SCAN listener status."""
    listeners = []
    cmds = ["srvctl status listener", "srvctl status scan_listener"]
    for cmd in cmds:
        out, _, _ = run_cmd(client, f"{cmd} 2>/dev/null")
        if out and "is running" in out.lower():
            listeners.append({"check_name": cmd.split()[-1].upper(), "status": "OK", "details": out})
        else:
            listeners.append({"check_name": cmd.split()[-1].upper(), "status": "CRITICAL", "details": out or "Not found"})
    return listeners


def get_asm_status(client: paramiko.SSHClient) -> List[Dict]:
    """ASM disk group status."""
    out, _, _ = run_cmd(client, "asmcmd lsdg 2>/dev/null")
    asm_disks = []
    for line in out.splitlines():
        if not line.strip() or 'State' in line:
            continue
        parts = line.split()
        if len(parts) >= 9:
            try:
                name = parts[-1].rstrip('/')
                total_mb = float(parts[7])
                free_mb = float(parts[8])
                pct = round((total_mb - free_mb) / total_mb * 100, 1) if total_mb > 0 else 0
                status = parse_status(pct)
                asm_disks.append({
                    "name": name,
                    "total_mb": total_mb,
                    "free_mb": free_mb,
                    "used_pct": pct,
                    "status": status
                })
            except Exception:
                pass
    return asm_disks


def check_backup_age(client: paramiko.SSHClient, patterns: List[str]) -> List[Dict]:
    """Check age of export/backup files."""
    results = []
    cmd = r"find /oracle/exports/daily /orabkp/exports/daily -maxdepth 1 -type f \( -name '*.log' -o -name '*.dmp' \) 2>/dev/null"
    out, _, _ = run_cmd(client, cmd)
    for fpath in out.splitlines():
        fpath = fpath.strip()
        if not fpath:
            continue
        fname = os.path.basename(fpath)
        if any(p.lower() in fname.lower() for p in patterns):
            date_cmd = f"stat -c '%Y' {fpath} 2>/dev/null || ls -l --time-style=full-iso {fpath} 2>/dev/null"
            date_out, _, _ = run_cmd(client, date_cmd)
            # Simple age check - improve as needed
            results.append({"file": fname, "status": "OK", "details": "Backup found"})
    return results or [{"file": "N/A", "status": "WARNING", "details": "No recent backups found"}]


def check_alert_log(client: paramiko.SSHClient) -> Dict[str, int]:
    """Scan alert log for critical patterns."""
    log_loc_cmd = r"find $ORACLE_BASE/diag -name 'alert*.log' 2>/dev/null | head -1"
    log_loc, _, _ = run_cmd(client, log_loc_cmd)
    if not log_loc:
        return {"Alert log not found": 1}

    content_cmd = f"tail -2000 {log_loc.strip()}"
    content, _, _ = run_cmd(client, content_cmd)
    found = Counter()
    for pattern in ALERT_CRIT_PATTERNS:
        matches = re.findall(pattern, content, re.IGNORECASE)
        if matches:
            found[pattern] += len(matches)
    return dict(found) if found else {}


# ========================= REPORT & SUMMARY =========================
def generate_report_and_save(all_data: List[Dict], error_log: List[str]):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"Oracle_healthCheck_report_V5_{timestamp}.txt"

    report_lines = []
    def log(key: str, val: str = ""):
        line = f"{key.ljust(35)} {val}"
        report_lines.append(line)
        print(line)

    log("=" * 120)
    log("ORACLE DATABASE HEALTH CHECK REPORT", f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log("=" * 120)

    summary_issues = []

    for srv in all_data:
        log("\nSERVER:", f"{srv['name']} ({srv['host']})")
        log("Status Summary:", srv.get("overall_status", "UNKNOWN"))

        # OS Info
        osi = srv.get("os_info", {})
        log("Hostname:", osi.get("hostname", "N/A"))

        # Storage
        for entry in srv.get("storage", []):
            if entry["status"] in ("WARNING", "CRITICAL"):
                summary_issues.append({
                    "server": srv["name"], "check": "Storage", "details": entry["mount_point"],
                    "status": entry["status"]
                })

        # ASM
        for d in srv.get("asm_disks", []):
            if d["status"] in ("WARNING", "CRITICAL"):
                summary_issues.append({"server": srv["name"], "check": "ASM", "details": d["name"], "status": d["status"]})

        # Alert Log
        if srv.get("alert_issues"):
            summary_issues.append({"server": srv["name"], "check": "Alert Log", "details": str(list(srv["alert_issues"].keys())), "status": "CRITICAL"})

        # Add more checks to summary as needed...

    log("\n" + "=" * 120)
    log("SUMMARY OF ISSUES (WARNING/CRITICAL ONLY)")
    log("=" * 120)
    if summary_issues:
        for issue in summary_issues:
            log(f"{issue['server']:<15} {issue['check']:<20} {issue['details']:<40} {issue['status']}")
    else:
        log("All checks passed successfully.")

    log("\nFull report saved to:", filename)

    with open(filename, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))


# ========================= MAIN =========================
def main():
    all_reports = []
    all_errors = []

    print("Starting Oracle Health Check...")

    for server in SERVERS:
        print(f"\nConnecting to {server['name']} ({server['host']})...")
        ora_client, ora_err = conn_server(server, ORA_USERNAME, ORA_PASSWORD)
        grid_client, grid_err = conn_server(server, GRID_USERNAME, GRID_PASSWORD)

        if ora_err:
            all_errors.append(f"{server['name']}: Oracle SSH - {ora_err}")
        if grid_err:
            all_errors.append(f"{server['name']}: Grid SSH - {grid_err}")

        report = {
            "name": server["name"],
            "host": server["host"],
            "os_info": get_os_info(ora_client) if ora_client else {},
            "storage": [],
            "asm_disks": [],
            "instances": [],
            "listeners": [],
            "resources": [],
            "alert_issues": {},
            "overall_status": "OK"
        }

        if ora_client:
            try:
                # Storage
                df_out, _, _ = run_cmd(ora_client, "df -h")
                report["storage"], df_errs = parse_df_output(df_out, server["name"])
                if df_errs:
                    all_errors.extend(df_errs)

                # ASM, Listeners, etc.
                report["asm_disks"] = get_asm_status(grid_client) if grid_client else []
                report["listeners"] = get_listener_status(grid_client, False) if grid_client else []
                report["instances"] = get_db_instances(ora_client, server["name"])
                report["alert_issues"] = check_alert_log(ora_client)

            except Exception as e:
                all_errors.append(f"Error during checks on {server['name']}: {e}")
            finally:
                ora_client.close()
                if grid_client:
                    grid_client.close()

        all_reports.append(report)

    generate_report_and_save(all_reports, all_errors)
    print("Health check completed.")


if __name__ == "__main__":
    main()