#!/usr/bin/env python3
"""
Oracle Database Infrastructure Automated Health Check Script
Version: 5.0 (Production Refactored)
Description: Automated multi-server health checks for Oracle Single-Instance
             and RAC environments via Paramiko SSH.
"""

import os
import sys
import re
import json
import paramiko
from datetime import datetime
from collections import Counter

# ==========================================
# CONFIGURATION CONSTANTS
# ==========================================
WARNING_THRESHOLD = 90
CRIT_THRESHOLD = 95
SSH_TIMEOUT = 30
CMD_TIMEOUT = 50

ORA_USERNAME = "oracle"
ORA_PASSWORD = "Ora#1234"
GRID_USERNAME = "grid"
GRID_PASSWORD = "Grid#1234"

ALERT_CRIT_PATTERNS = [
    r'ORA-00600', r'ORA-07445', r'ORA-04031', r'ORA-01578', 
    r'ORA-00060', r'ORA-00257', r'ORA-16038', r'ORA-15050',
    r'Checkpoint not complete', r'Block corruption', 
    r'Fatal NI connect error', r'Instance shutdown!', 
    r'cannot allocate new log', r'PMON failed to acquire',
    r'Corrupt block', r'media recovery'
]

# ==========================================
# TARGET SERVERS LIST
# ==========================================
SERVERS = [
    {
        "name": "prodsrv2", 
        "host": "18.xx.xx.xx", 
        "expdp_list": ["expdp_pdb1", "expdp_pdb2"], 
        "gg_check": False
    },
    {
        "name": "prodsrv3", 
        "host": "18.xx.xx.xx", 
        "expdp_list": ["EXPDP_SAS"], 
        "gg_check": True
    },
    {
        "name": "prodsrv4", 
        "host": "118.xx.xx.xx", 
        "expdp_list": ["EXPDP_SAS"], 
        "gg_check": False
    }
]

# ==========================================
# CORE SSH & EXECUTION HELPERS
# ==========================================
def conn_server(server_info, username, password):
    """Establishes a secure SSH connection to target server."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=server_info["host"],
            username=username,
            password=password,
            timeout=SSH_TIMEOUT,
            allow_agent=False,
            look_for_keys=False
        )
        return client, None
    except paramiko.AuthenticationException:
        return None, "Authentication failed."
    except paramiko.SSHException as e:
        return None, f"SSH connection issue: {str(e)}"
    except Exception as e:
        return None, f"Connection failed: {str(e)}"

def run_cmd(client, cmd):
    """Executes commands on remote host, sourcing profile configs automatically."""
    try:
        # Standard login shell profile search sequence for smooth variable evaluation
        full_cmd = (
            f"if [ -f ~/.bash_profile ]; then . ~/.bash_profile; "
            f"elif [ -f ~/.profile ]; then . ~/.profile; "
            f"elif [ -f ~/.bashrc ]; then . ~/.bashrc; fi; {cmd}"
        )
        stdin, stdout, stderr = client.exec_command(full_cmd, timeout=CMD_TIMEOUT)
        out = stdout.read().decode("utf-8").strip()
        err = stderr.read().decode("utf-8").strip()
        code = stdout.channel.recv_exit_status()
        return out, err, code
    except Exception as e:
        return "", f"Execution Error: {str(e)}", -1

# ==========================================
# DATA PARSING & EXTRACTION MODULES
# ==========================================
def create_metric(check_name, status, details):
    """Standardizes the output format across all individual metrics."""
    return {
        "check_name": check_name,
        "status": status,  # OK, WARNING, CRITICAL, or UNKNOWN
        "details": details
    }

def parse_df_output(output):
    """Parses raw text df -h storage details cleanly."""
    metrics = []
    if not output:
        return [create_metric("OS Storage", "UNKNOWN", "No storage data collected")]
    
    lines = output.splitlines()
    for line in lines:
        if line.startswith("Filesystem") or not line.strip():
            continue
        parts = line.split()
        if len(parts) >= 5:
            try:
                fs, size, used, avail, use_pct = parts[0], parts[1], parts[2], parts[3], parts[4]
                pct_val = int(use_pct.replace("%", ""))
                
                status = "OK"
                if pct_val >= CRIT_THRESHOLD:
                    status = "CRITICAL"
                elif pct_val >= WARNING_THRESHOLD:
                    status = "WARNING"
                
                details = f"Mount: {parts[-1]} | Size: {size} | Used: {used} ({use_pct}) | Free: {avail}"
                metrics.append(create_metric(f"Storage: {fs}", status, details))
            except ValueError:
                continue
    return metrics

def get_db_instances(client):
    """Checks the operational availability of database instances."""
    metrics = []
    # Attempt Grid cluster srvctl lookup first
    out, err, code = run_cmd(client, "srvctl seq database 2>/dev/null || srvctl list database 2>/dev/null")
    databases = [line.strip() for line in out.splitlines() if line.strip()]
    
    if databases:
        for db in databases:
            st_out, _, st_code = run_cmd(client, f"srvctl status database -d {db}")
            if st_code == 0 and "is running" in st_out:
                metrics.append(create_metric(f"Database Instance: {db}", "OK", st_out))
            else:
                metrics.append(create_metric(f"Database Instance: {db}", "CRITICAL", st_out if st_out else "Instance is stopped"))
    else:
        # Fallback to local system process evaluation if srvctl is not available
        ps_out, _, _ = run_cmd(client, "ps -ef | grep ora_pmon | grep -v grep")
        if ps_out:
            for line in ps_out.splitlines():
                match = re.search(r'ora_pmon_(.+)$', line)
                if match:
                    sid = match.group(1)
                    metrics.append(create_metric(f"Database Process: {sid}", "OK", f"PMON process running for SID: {sid}"))
        else:
            metrics.append(create_metric("Database Instances", "CRITICAL", "No active Oracle PMON processes detected"))
            
    return metrics

def get_crsctl_resources(client):
    """Checks Clusterware (GI) resources status."""
    metrics = []
    out, _, code = run_cmd(client, "crsctl status resource -t 2>/dev/null")
    if code != 0 or not out:
        return []  # Return empty for non-RAC environments without raising failures
    
    current_res = None
    res_pattern = re.compile(r'^ora\.[\w\.]+')
    
    for line in out.splitlines():
        line = line.strip()
        if not line or "---" in line or "Name" in line:
            continue
            
        if res_pattern.match(line):
            current_res = line.split()[0]
            continue
            
        if current_res and ("ONLINE" in line or "OFFLINE" in line):
            parts = line.split()
            if len(parts) >= 3:
                target, state, node = parts[0], parts[1], parts[2]
                status = "OK" if (target == "ONLINE" and state == "ONLINE") else "CRITICAL"
                details = f"Target: {target} | State: {state} | Server Node: {node}"
                metrics.append(create_metric(f"Cluster Resource: {current_res}", status, details))
    return metrics

def get_listener_status(client):
    """Verifies Oracle local listener and SCAN listener infrastructure health."""
    metrics = []
    
    # 1. Local SRVCTL Listener Validation
    lsnr_out, _, code = run_cmd(client, "srvctl status listener 2>/dev/null")
    if code == 0 and lsnr_out:
        for line in lsnr_out.splitlines():
            status = "OK" if "is running" in line else "CRITICAL"
            metrics.append(create_metric("SRVCTL Listener", status, line.strip()))
    else:
        # Process verification fallback
        ps_lsnr, _, _ = run_cmd(client, "ps -ef | grep tnslsnr | grep -v grep")
        if ps_lsnr:
            for line in ps_lsnr.splitlines():
                metrics.append(create_metric("TNS Listener Process", "OK", f"Listener active: {line.split()[-1]}"))
        else:
            metrics.append(create_metric("Listener Status", "CRITICAL", "No active TNS listener processes found"))

    # 2. SCAN Listeners validation (RAC Specific)
    scan_out, _, code = run_cmd(client, "srvctl status scan_listener 2>/dev/null")
    if code == 0 and scan_out:
        for line in scan_out.splitlines():
            status = "OK" if "is running" in line else "CRITICAL"
            metrics.append(create_metric("SCAN Listener", status, line.strip()))
            
    return metrics

def get_asm_status(client):
    """Evaluates ASM Disk Group free space and structural mounting states."""
    metrics = []
    out, _, code = run_cmd(client, "asmcmd lsdg 2>/dev/null")
    if "not found" in out or code != 0 or not out:
        return []
        
    for line in out.splitlines():
        if not line.strip() or "State" in line:
            continue
        parts = line.split()
        if len(parts) < 9:
            continue
            
        try:
            state = parts[0]
            total_mb = float(parts[7])
            free_mb = float(parts[8])
            name = parts[-1].rstrip("/")
            
            used_mb = total_mb - free_mb
            pct = round((used_mb / total_mb) * 100, 1) if total_mb > 0 else 0
            
            status = "OK"
            if state != "MOUNTED":
                status = "CRITICAL"
            elif pct >= CRIT_THRESHOLD:
                status = "CRITICAL"
            elif pct >= WARNING_THRESHOLD:
                status = "WARNING"
                
            details = f"State: {state} | Total: {total_mb}MB | Free: {free_mb}MB ({pct}% Space Used)"
            metrics.append(create_metric(f"ASM Disk Group: {name}", status, details))
        except (ValueError, IndexError):
            continue
    return metrics

def check_goldengate(client, gg_enabled):
    """Tracks Oracle GoldenGate Manager operational runtime process state."""
    if not gg_enabled:
        return []
    
    out, _, _ = run_cmd(client, "ps -ef | grep -iw 'mgr' | grep -v grep")
    if out:
        return [create_metric("Oracle GoldenGate MGR", "OK", "GoldenGate MGR background routing process is running normally")]
    
    # Locate ggsci path to check if installation is present but process is offline
    loc, _, _ = run_cmd(client, "which ggsci 2>/dev/null || find /ggate/ -name ggsci 2>/dev/null | head -n 1")
    if loc:
        return [create_metric("Oracle GoldenGate MGR", "CRITICAL", "GoldenGate binary exists but Manager process is stopped")]
    
    return [create_metric("Oracle GoldenGate MGR", "WARNING", "GoldenGate enabled in configuration parameters but installation was not found")]

def check_backup_age(client, patterns):
    """Validates physical datadump or backup log generation lifecycle timelines."""
    if not patterns:
        return [create_metric("Backup Age Check", "UNKNOWN", "No target backup matching configuration filters configured")]
        
    metrics = []
    # Dynamic search execution path
    search_cmd = "find /oracle/exports/daily /orabkp/exports/daily /exports/daily -maxdepth 2 -type f \( -name '*.log' -o -name '*.dmp' \) 2>/dev/null"
    out, _, _ = run_cmd(client, search_cmd)
    
    if not out.strip():
        return [create_metric("Backup Age Check", "WARNING", "No active datapump dump or export log tracks pulled from directories")]
        
    found_any = False
    for fpath in out.splitlines():
        fpath = fpath.strip()
        if not fpath:
            continue
        fname = os.path.basename(fpath)
        
        # Filter file targets against configured schema naming filters
        if any(p.lower() in fname.lower() for p in patterns):
            found_any = True
            safe_path = fpath.replace("'", "'\\''")
            date_cmd = f"stat -c '%y' '{safe_path}' 2>/dev/null || ls -ld --time-style=+%Y-%m-%d '{safe_path}' 2>/dev/null"
            date_out, _, _ = run_cmd(client, date_cmd)
            
            date_match = re.search(r'\d{4}-\d{2}-\d{2}', date_out)
            if date_match:
                try:
                    mod_date = datetime.strptime(date_match.group(0), "%Y-%m-%d")
                    age_days = (datetime.now() - mod_date).days
                    
                    status = "OK"
                    if age_days >= 2:
                        status = "CRITICAL"
                    elif age_days >= 1:
                        status = "WARNING"
                        
                    details = f"Last Modified: {date_match.group(0)} | File Age: {age_days} day(s) | Path: {fpath}"
                    metrics.append(create_metric(f"Backup Age: {fname}", status, details))
                except Exception as e:
                    metrics.append(create_metric(f"Backup Age: {fname}", "UNKNOWN", f"Date evaluation error: {str(e)}"))
            else:
                metrics.append(create_metric(f"Backup Age: {fname}", "UNKNOWN", "Failed to retrieve modification date information"))
                
    if not found_any:
        return [create_metric("Backup Age Check", "WARNING", f"No file matches encountered for filters: {patterns}")]
        
    return metrics

def check_alert_log(client):
    """Scans the database alert log trailing rows for errors."""
    log_loc_cmd = "find $ORACLE_BASE/diag -name 'alert_*.log' 2>/dev/null | head -n 1"
    log_path, _, _ = run_cmd(client, log_loc_cmd)
    
    if not log_path.strip():
        # Fallback diagnostics log location
        log_path, _, _ = run_cmd(client, "find /u01/app/oracle/diag -name 'alert_*.log' 2>/dev/null | head -n 1")
        if not log_path.strip():
            return [create_metric("Oracle Alert Log", "WARNING", "Unable to establish trace diagnostic alert log target destination paths")]
            
    tail_cmd = f"tail -n 400 {log_path.strip()}"
    log_content, _, _ = run_cmd(client, tail_cmd)
    
    critical_issues = []
    for line in log_content.splitlines():
        for pattern in ALERT_CRIT_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                critical_issues.append(line.strip())
                break
                
    if critical_issues:
        issue_counts = Counter(re.findall(r'ORA-\d+|Checkpoint not complete|Block corruption', " ".join(critical_issues), re.I))
        summary_issues = ", ".join([f"{k} ({v}x)" for k, v in issue_counts.items()])
        return [create_metric("Oracle Alert Log", "CRITICAL", f"Encountered critical alerts within the last 400 lines: {summary_issues if summary_issues else 'Critical structural errors found.'}")]
        
    return [create_metric("Oracle Alert Log", "OK", "No warning or critical ORA structural exception fingerprints encountered within trailing rows")]

# ==========================================
# REPORT COMPILATION & GENERATION MATRIX
# ==========================================
def generate_report(all_reports, execution_errors):
    """Constructs a clean plain-text infrastructure report file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    filename = f"Oracle_Health_Check_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    
    with open(filename, "w", encoding="utf-8") as f:
        f.write("=" * 120 + "\n")
        f.write(f"ORACLE DATABASE INFRASTRUCTURE ENVIRONMENT HEALTH SYSTEM REPORT - Generated on {timestamp}\n")
        f.write("=" * 120 + "\n\n")
        
        # 1. EXCEPTION SUMMARY OVERVIEW (Requested Non-OK Highlight Matrix)
        f.write("## SECTION 1: CRITICAL & WARNING ALERTS METRIC SUMMARY\n")
        f.write("-" * 120 + "\n")
        f.write(f"{'SERVER NAME':<18} | {'CHECK RUN EXECUTED':<35} | {'ALERTS STATUS':<12} | {'DIAGNOSTIC CRITICAL DETAILS'}\n")
        f.write("-" * 120 + "\n")
        
        alert_rows = 0
        # Incorporate hard operational errors
        for srv, err in execution_errors:
            f.write(f"{srv:<18} | {'System Connectivity Check':<35} | {'CRITICAL':<12} | {err}\n")
            alert_rows += 1
            
        # Parse non-OK elements out from internal structures
        for srv_name, metrics in all_reports.items():
            for m in metrics:
                if m["status"] in ["WARNING", "CRITICAL", "UNKNOWN"]:
                    f.write(f"{srv_name:<18} | {m['check_name']:<35} | {m['status']:<12} | {m['details']}\n")
                    alert_rows += 1
                    
        if alert_rows == 0:
            f.write(f"{'---':<18} | {'All checked parameters are operating normally. No exceptions found.':<35} | {'---':<12} | ---\n")
        f.write("-" * 120 + "\n\n")
        
        # 2. COMPLETE DETAILS SYSTEM OVERVIEW
        f.write("## SECTION 2: EXPANDED INFRASTRUCTURE HEALTH METRIC MATRIX\n")
        for srv_name, metrics in all_reports.items():
            f.write(f"\nSERVER ARCHITECTURE TARGET: [ {srv_name} ]\n")
            f.write("+" * 60 + "\n")
            for m in metrics:
                f.write(f" - [{m['status']}] {m['check_name']}\n   Detail: {m['details']}\n")
            f.write("+" * 60 + "\n")
            
    print(f"\n[+] Comprehensive Infrastructure Verification Execution Completed. Output saved to: {os.path.abspath(filename)}")

# ==========================================
# MAIN ROUTINE ORCHESTRATION ENGINE
# ==========================================
def main():
    all_reports = {}
    execution_errors = []
    
    print("[*] Launching Database Infrastructure Diagnostics Environment Scanner...")
    
    for srv in SERVERS:
        srv_name = srv["name"]
        print(f" -> Connecting to target host node: {srv_name} ({srv['host']})...")
        
        # Primary login via Oracle credentials setup
        client, err_msg = conn_server(srv, ORA_USERNAME, ORA_PASSWORD)
        if err_msg:
            execution_errors.append((srv_name, f"Oracle User Authentication Connection Failure: {err_msg}"))
            continue
            
        # Grid authentication setup for Cluster / ASM evaluations
        grid_client, grid_err = conn_server(srv, GRID_USERNAME, GRID_PASSWORD)
        
        server_metrics = []
        
        # Run storage check
        storage_out, _, _ = run_cmd(client, "df -h 2>/dev/null")
        server_metrics.extend(parse_df_output(storage_out))
        
        # Run DB instance check
        server_metrics.extend(get_db_instances(client))
        
        # Run CRS / Clusterware check
        if grid_client:
            server_metrics.extend(get_crsctl_resources(grid_client))
            server_metrics.extend(get_listener_status(grid_client))
            server_metrics.extend(get_asm_status(grid_client))
        else:
            # Local fallback sweeps
            server_metrics.extend(get_listener_status(client))
            server_metrics.extend([create_metric("Grid Infrastructure Check", "WARNING", "Grid user connection unavailable. Skipping Clusterware and ASM checks.")])
            
        # Run GoldenGate check
        server_metrics.extend(check_goldengate(client, srv.get("gg_check", False)))
        
        # Run Backup checks
        server_metrics.extend(check_backup_age(client, srv.get("expdp_list", [])))
        
        # Run Alert Log check
        server_metrics.extend(check_alert_log(client))
        
        all_reports[srv_name] = server_metrics
        
        # Gracefully release connection resources
        client.close()
        if grid_client:
            grid_client.close()
            
    # Output report compilation
    generate_report(all_reports, execution_errors)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[-] Health Check processing interrupted by user.")
        sys.exit(1)
