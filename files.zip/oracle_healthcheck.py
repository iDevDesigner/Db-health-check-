#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Oracle RAC / Standalone - Database Health Check Script
Run as  : oracle user (with DB environment sourced: ORACLE_HOME, ORACLE_SID)
Compat  : Python 2.7 and Python 3.x | Solaris / Linux

CDB/PDB SUPPORT
  Automatically detects whether the DB is a CDB (12c+) or non-CDB.
  When CDB: iterates over every OPEN PDB and runs tablespace, invalid objects,
  scheduled jobs, datapump, sessions, and performance queries inside each PDB
  using ALTER SESSION SET CONTAINER = <pdb_name>.
  Container-level views (RMAN, FRA, redo logs, RAC, GoldenGate, alert log)
  remain connected to CDB$ROOT.
  Non-CDB: all queries run directly — no change in behaviour.

SQL EXECUTION
  All SQL is written to a tempfile via tempfile.mkstemp() then passed to:
      sqlplus -s '/ as sysdba' @/tmp/hc_XXXXXX.sql
  No echo, no heredoc, no shell escaping issues.
  PDB context is set with ALTER SESSION SET CONTAINER inside the same script,
  then switched back to CDB$ROOT before exit.

USAGE:
  python oracle_healthcheck.py [--output /path] [--sid MYSID] \
                               [--db-name MYDB] [--standalone] [--debug] \
                               [--skip-gg] [--skip-perf]

ENVIRONMENT REQUIRED:
  ORACLE_HOME, ORACLE_SID, PATH (must include $ORACLE_HOME/bin)

CRON (oracle crontab):
  0 6 * * * . /home/oracle/.profile && /usr/bin/python \
    /opt/scripts/oracle_healthcheck.py \
    --output /shared/hc --sid FINDB1 2>>/var/log/oracle_hc.err
"""
from __future__ import print_function, unicode_literals
import os, sys, json, socket, subprocess, datetime, platform
import re, traceback, argparse, tempfile

try:
    import pwd
    def get_username():
        return pwd.getpwuid(os.getuid()).pw_name
except Exception:
    def get_username():
        return os.environ.get("USER", "unknown")

PY2 = sys.version_info[0] == 2
if PY2:
    string_types = (str, unicode)   # noqa: F821
    text_type    = unicode           # noqa: F821
else:
    string_types = (str,)
    text_type    = str

SCRIPT_VERSION = "3.0"

THRESHOLDS = {
    "ts_warn_pct":        80,
    "ts_crit_pct":        90,
    "fra_warn_pct":       75,
    "fra_crit_pct":       85,
    "gg_lag_warn_sec":    60,
    "gg_lag_crit_sec":    300,
    "rman_age_warn_hours":25,
    "rman_full_warn_days":8,
    "alert_log_hours":    24,
    "invalid_obj_warn":   1,
    "session_warn_pct":   80,
    "session_crit_pct":   90,
}

# ── helpers ───────────────────────────────────────────────────────────────────

def now_ts():   return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def now_date(): return datetime.datetime.now().strftime("%Y-%m-%d")
def now_time(): return datetime.datetime.now().strftime("%H:%M:%S")

def st_pct(pct, w, c):
    if pct is None: return "UNKNOWN"
    return "CRITICAL" if pct >= c else "WARNING" if pct >= w else "OK"

def agg(*statuses):
    flat = []
    for s in statuses:
        if isinstance(s, list): flat.extend(s)
        else: flat.append(s)
    for s in ["CRITICAL", "ERROR", "WARNING", "OK", "N/A"]:
        if s in flat: return s
    return "UNKNOWN"

class Log(object):
    def __init__(self, debug=False):
        self.debug_on = debug
    def _w(self, lvl, msg):
        print("[{0}] {1}  {2}".format(lvl, now_ts(), msg), file=sys.stderr)
    def info(self, m):  self._w("INFO ", m)
    def warn(self, m):  self._w("WARN ", m)
    def error(self, m): self._w("ERROR", m)
    def debug(self, m):
        if self.debug_on: self._w("DEBUG", m)

def run(cmd, timeout=60, extra_env=None):
    """Run shell command; return (stdout, stderr, rc). Python 2/3 safe."""
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    try:
        if PY2:
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, env=env)
            out, err = p.communicate()
            rc = p.returncode
        else:
            r = subprocess.run(cmd, shell=True, capture_output=True,
                               timeout=timeout, env=env)
            out, err, rc = r.stdout, r.stderr, r.returncode
        def dec(b):
            return b.decode("utf-8", "replace").strip() if isinstance(b, bytes) else str(b).strip()
        return dec(out), dec(err), rc
    except Exception as e:
        return "", str(e), -1

def find_bin(names, oracle_home=None):
    if isinstance(names, str):
        names = [names]
    dirs = []
    if oracle_home:
        dirs.append(os.path.join(oracle_home, "bin"))
    dirs += [d for d in os.environ.get("PATH", "").split(os.pathsep) if d]
    dirs += ["/sbin", "/usr/sbin", "/bin", "/usr/bin", "/usr/local/bin"]
    for name in names:
        for d in dirs:
            p = os.path.join(d, name)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None


# ── SQL*Plus wrapper ──────────────────────────────────────────────────────────

class SQLPlus(object):
    """
    Wrapper around sqlplus using tempfile.mkstemp() for all SQL delivery.
    No echo, no shell heredoc, no escaping issues on Solaris or Linux.

    run_sql(sql)              -- run in current container (CDB$ROOT / non-CDB)
    run_sql_in_pdb(pdb, sql)  -- ALTER SESSION to pdb, run, return to CDB$ROOT
    """

    CONN_ERRORS = [
        "ORA-01034", "ORA-01089", "ORA-01090", "ORA-12514",
        "ORA-12541", "ORA-12170", "SP2-0640", "SP2-0641",
        "NL-00405", "TNS-", "not available", "ORACLE not available",
    ]

    # PDB-specific errors: ALTER SESSION SET CONTAINER failed — not a root-connect failure
    PDB_ERRORS = [
        "ORA-65011",  # PDB does not exist
        "ORA-65040",  # operation not allowed from within a pluggable database
        "ORA-01219",  # DB/PDB not open — queries allowed on fixed tables only
        "ORA-65169",  # error attempting to switch to PDB
        "ORA-17628",  # remote Oracle error 65011
    ]

    # Standard sqlplus formatting preamble written at top of every script
    _HEADER = (
        "set pagesize 0\n"
        "set linesize 500\n"
        "set feedback off\n"
        "set heading off\n"
        "set echo off\n"
        "set trimout on\n"
        "set trimspool on\n"
        "set define off\n"
        "set serverout off\n"
        "whenever sqlerror continue\n"
    )

    def __init__(self, oracle_home, sid, log):
        self.oracle_home = oracle_home
        self.sid         = sid
        self.log         = log
        self.sqlplus     = find_bin("sqlplus", oracle_home)
        self.available   = self.sqlplus is not None
        self._env        = self._build_env()

    def _build_env(self):
        env = os.environ.copy()
        if self.oracle_home:
            env["ORACLE_HOME"] = self.oracle_home
            bp = os.path.join(self.oracle_home, "bin")
            lp = os.path.join(self.oracle_home, "lib")
            env["PATH"] = bp + os.pathsep + env.get("PATH", "")
            if platform.system() == "SunOS":
                for lv in ("LD_LIBRARY_PATH", "LD_LIBRARY_PATH_64"):
                    env[lv] = lp + os.pathsep + env.get(lv, "")
            else:
                env["LD_LIBRARY_PATH"] = lp + os.pathsep + env.get("LD_LIBRARY_PATH", "")
        if self.sid:
            env["ORACLE_SID"] = self.sid
        return env

    def _exec(self, script_body, timeout=120):
        """
        Write the full SQL script to a mkstemp temp file, invoke sqlplus
        via '@file', parse output, delete temp file.
        Returns (clean_lines, error_str, success_bool).
        """
        if not self.available:
            return [], "sqlplus not found in ORACLE_HOME/bin", False

        full = self._HEADER + script_body + "\nexit;\n"
        tmp  = None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".sql", prefix="hc_")
            with os.fdopen(fd, "w") as fh:
                fh.write(full)

            cmd = "{0} -s '/ as sysdba' @{1}".format(self.sqlplus, tmp)
            out, err, rc = run(cmd, timeout=timeout, extra_env=self._env)

            # Hard connection failure?
            combined = out + "\n" + err
            for ce in self.CONN_ERRORS:
                if ce in combined:
                    return [], "DB not accessible: " + ce, False

            clean  = []
            errors = []
            for line in out.splitlines():
                ls = line.strip()
                if not ls or ls.startswith("SQL>") or ls.startswith("--"):
                    continue
                if "ORA-" in ls or "SP2-" in ls:
                    errors.append(ls)
                else:
                    clean.append(line.rstrip())

            return clean, "\n".join(errors), (rc == 0 and not errors)
        except Exception as ex:
            self.log.error("sqlplus exec error: {}".format(ex))
            return [], str(ex), False
        finally:
            if tmp:
                try: os.unlink(tmp)
                except Exception: pass

    def run_sql(self, sql, timeout=120):
        """Run SQL in CDB$ROOT (or non-CDB instance)."""
        return self._exec(sql, timeout=timeout)

    def run_sql_in_pdb(self, pdb_name, sql, timeout=120):
        """
        Switch to pdb_name, execute sql, switch back to CDB$ROOT — all in one
        sqlplus session, written entirely to a single mkstemp temp file.

        The script uses PROMPT markers to let _exec_in_pdb() isolate the data
        rows from the ALTER SESSION housekeeping output so callers receive only
        the rows produced by <sql>.

        Returns (clean_lines, error_str, success_bool).
        """
        # PROMPT lines act as start/end sentinels — they never appear in data.
        script = (
            "whenever sqlerror continue\n"
            "alter session set container = {pdb};\n"
            "prompt <<<PDB_DATA_START>>>\n"
            "{sql}\n"
            "prompt <<<PDB_DATA_END>>>\n"
            "alter session set container = CDB$ROOT;\n"
        ).format(pdb=pdb_name, sql=sql)
        return self._exec_in_pdb(pdb_name, script, timeout=timeout)

    def _exec_in_pdb(self, pdb_name, script_body, timeout=120):
        """
        Like _exec() but:
        1. Detects PDB-specific ALTER SESSION errors (ORA-65011 etc.) and
           returns success=False with a clear error message.
        2. Strips everything outside the <<<PDB_DATA_START>>> / <<<PDB_DATA_END>>>
           sentinels so callers only see rows from their SQL, not ALTER SESSION
           confirmation messages.
        """
        if not self.available:
            return [], "sqlplus not found in ORACLE_HOME/bin", False

        full = self._HEADER + script_body + "\nexit;\n"
        tmp  = None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".sql", prefix="hc_pdb_")
            with os.fdopen(fd, "w") as fh:
                fh.write(full)

            cmd = "{0} -s '/ as sysdba' @{1}".format(self.sqlplus, tmp)
            out, err, rc = run(cmd, timeout=timeout, extra_env=self._env)

            combined = out + "\n" + err

            # Hard root-connection failure
            for ce in self.CONN_ERRORS:
                if ce in combined:
                    return [], "DB not accessible: " + ce, False

            # PDB switch failure — ALTER SESSION returned a PDB-specific ORA-
            for pe in self.PDB_ERRORS:
                if pe in combined:
                    return [], "PDB '{}' not accessible: {} found in output".format(
                        pdb_name, pe), False

            # Extract only the rows between the sentinels
            in_data  = False
            clean    = []
            errors   = []
            for line in out.splitlines():
                ls = line.strip()
                if ls == "<<<PDB_DATA_START>>>":
                    in_data = True
                    continue
                if ls == "<<<PDB_DATA_END>>>":
                    in_data = False
                    continue
                if not in_data:
                    continue           # skip ALTER SESSION output
                if not ls or ls.startswith("SQL>") or ls.startswith("--"):
                    continue
                if "ORA-" in ls or "SP2-" in ls:
                    errors.append(ls)
                else:
                    clean.append(line.rstrip())

            return clean, "\n".join(errors), (rc == 0 and not errors)
        except Exception as ex:
            self.log.error("sqlplus pdb exec error: {}".format(ex))
            return [], str(ex), False
        finally:
            if tmp:
                try: os.unlink(tmp)
                except Exception: pass


# ── CDB/PDB detection ─────────────────────────────────────────────────────────

def detect_cdb_info(sql, log):
    """
    Probe the DB to find out if it is a CDB and enumerate open PDBs.
    Returns:
        {
          "is_cdb": True/False,
          "version": "19.22.0.0.0",
          "pdbs": [{"name":"HRPDB","open_mode":"READ WRITE","restricted":"NO"}, ...]
        }
    """
    info = {"is_cdb": False, "version": "unknown", "pdbs": []}

    vl, ve, vo = sql.run_sql("select version from v$instance;", timeout=20)
    if vo and vl:
        info["version"] = vl[0].strip()

    # v$database.cdb only exists on 12c+; ORA-00904 means pre-12c non-CDB
    cdb_lines, ce, co = sql.run_sql(
        "select cdb, con_id from v$database;", timeout=20)
    if "ORA-00904" in ce or not co:
        log.info("DB is non-CDB (pre-12c or column absent)")
        info["is_cdb"] = False
        return info

    if co and cdb_lines:
        p = cdb_lines[0].split()
        info["is_cdb"] = (p[0].upper() == "YES") if p else False

    if not info["is_cdb"]:
        log.info("DB is non-CDB (cdb=NO)")
        return info

    # Enumerate PDBs excluding PDB$SEED.
    # Use '|' delimiter because open_mode is "READ WRITE" (two words) and
    # plain split() would only capture "READ" in p[1].
    pdb_lines, pe, po = sql.run_sql(
        "select name||'|'||open_mode||'|'||restricted"
        " from v$pdbs"
        " where name != 'PDB$SEED'"
        " order by name;", timeout=30)
    if po:
        for line in pdb_lines:
            line = line.strip()
            if not line:
                continue
            p = line.split("|")
            info["pdbs"].append({
                "name":       p[0].strip(),
                "open_mode":  p[1].strip() if len(p) > 1 else "UNKNOWN",
                "restricted": p[2].strip() if len(p) > 2 else "UNKNOWN",
            })
    log.info("CDB detected. PDBs: {}".format(
        ", ".join(x["name"] for x in info["pdbs"]) or "none"))
    return info


def open_pdbs(cdb_info):
    """Return PDBs that are READ WRITE (we can ALTER SESSION into them)."""
    return [p for p in cdb_info.get("pdbs", [])
            if "READ WRITE" in p.get("open_mode", "")]


# ── Env detection ─────────────────────────────────────────────────────────────

class Env(object):
    def __init__(self, sid="", standalone=False, log=None):
        self.log         = log or Log()
        self.standalone  = standalone
        self.hostname    = socket.gethostname()
        self.short       = self.hostname.split(".")[0].upper()
        self.os_sys      = platform.system()
        self.os_ver      = self._os_ver()
        self.user        = get_username()
        self.oracle_home = self._find_oracle_home()
        self.oracle_base = os.environ.get("ORACLE_BASE", "/u01/app/oracle")
        self.oracle_ver  = self._detect_oracle_version()
        self.sid         = sid or os.environ.get("ORACLE_SID", "")
        self.db_name     = (os.environ.get("ORACLE_UNQNAME")
                            or os.environ.get("DB_UNIQUE_NAME") or self.sid)
        if self.oracle_home:
            bp = os.path.join(self.oracle_home, "bin")
            os.environ["PATH"] = bp + os.pathsep + os.environ.get("PATH", "")
            os.environ["ORACLE_HOME"] = self.oracle_home
        if self.sid:
            os.environ["ORACLE_SID"] = self.sid

    def _os_ver(self):
        try:
            if platform.system() == "SunOS":
                o, _, _ = run("uname -a", 5)
                return o
            return platform.platform()
        except Exception: return "Unknown"

    def _find_oracle_home(self):
        oh = os.environ.get("ORACLE_HOME", "")
        if oh and os.path.isdir(oh): return oh
        for oratab in ["/etc/oratab", "/var/opt/oracle/oratab"]:
            if os.path.isfile(oratab):
                try:
                    with open(oratab) as fh:
                        for line in fh:
                            line = line.strip()
                            if not line or line.startswith("#"): continue
                            parts = line.split(":")
                            if len(parts) >= 2:
                                h = parts[1].strip()
                                if os.path.isdir(h): return h
                except Exception: pass
        for c in ["/u01/app/oracle/product/19.0.0/dbhome_1",
                  "/u01/app/oracle/product/19.3.0/dbhome_1",
                  "/u01/app/oracle/product/21.0.0/dbhome_1",
                  "/u01/app/oracle/product/12.2.0.1/dbhome_1",
                  "/opt/oracle/product/19c/dbhome_1"]:
            if os.path.isdir(c): return c
        sp = find_bin("sqlplus")
        if sp: return os.path.dirname(os.path.dirname(sp))
        return None

    def _detect_oracle_version(self):
        if self.oracle_home:
            sp = find_bin("sqlplus", self.oracle_home)
            if sp:
                o, _, _ = run("{} -V 2>&1".format(sp), 10)
                m = re.search(r"Release\s+([\d.]+)", o, re.I)
                if m: return m.group(1)
        return os.environ.get("ORACLE_VERSION", "unknown")

    def bin(self, name): return find_bin(name, self.oracle_home)


# ════════════════════════════════════════════════════════════════════════════════
# CHECK FUNCTIONS
# Annotation on each function:
#   CDB scope  = queries that must run in CDB$ROOT
#   PDB scope  = queries that run once per open PDB via run_sql_in_pdb()
# ════════════════════════════════════════════════════════════════════════════════

# ── DB connectivity ───────────────────────────────────────────────────────────
# CDB scope : v$instance — container-level only; no PDB iteration needed

def chk_db_connectivity(env, sql, log):
    sec = {"section": "db_connectivity", "section_status": "UNKNOWN", "checks": {}}
    if not sql.available:
        sec["section_status"] = "ERROR"
        sec["checks"]["sqlplus"] = {"status": "ERROR",
            "error": "sqlplus not found. Set ORACLE_HOME correctly."}
        return sec, False

    lines, err, ok = sql.run_sql(
        "select 'ALIVE|'||instance_name||'|'||status"
        "||'|'||database_status from v$instance;", timeout=30)
    if not ok or not lines:
        sec["section_status"] = "CRITICAL"
        sec["checks"]["connection"] = {"status": "CRITICAL",
            "error": err or "DB returned no rows — instance may be down", "sid": env.sid}
        return sec, False

    row = [l for l in lines if "ALIVE|" in l]
    if row:
        parts     = row[0].split("|")
        inst_name = parts[1] if len(parts) > 1 else env.sid
        inst_st   = parts[2] if len(parts) > 2 else "UNKNOWN"
        db_status = parts[3] if len(parts) > 3 else "UNKNOWN"
        db_ok     = inst_st == "OPEN" and db_status == "ACTIVE"
        st        = "OK" if db_ok else "CRITICAL"
        sec["checks"]["connection"] = {"status": st, "instance_name": inst_name,
            "instance_status": inst_st, "database_status": db_status,
            "error": "Instance {} database {}".format(inst_st, db_status) if not db_ok else None}
    else:
        sec["checks"]["connection"] = {"status": "WARNING", "raw": lines[:3]}

    sec["section_status"] = sec["checks"]["connection"]["status"]
    return sec, sec["section_status"] == "OK"


# ── DB info ───────────────────────────────────────────────────────────────────
# CDB scope : v$database, v$instance, v$parameter + cdb_info already populated

def chk_database_info(env, sql, cdb_info, log):
    lines, err, ok = sql.run_sql(
        "select 'INFO|'||name||'|'||db_unique_name||'|'||open_mode"
        "||'|'||log_mode||'|'||database_role||'|'||current_scn"
        " from v$database;", timeout=30)
    info = {"status": "OK" if ok else "WARNING"}
    if ok and lines:
        for l in lines:
            if l.startswith("INFO|"):
                p = l.split("|")
                info.update({
                    "db_name":    p[1] if len(p) > 1 else "",
                    "db_unique":  p[2] if len(p) > 2 else "",
                    "open_mode":  p[3] if len(p) > 3 else "",
                    "log_mode":   p[4] if len(p) > 4 else "",
                    "db_role":    p[5] if len(p) > 5 else "",
                    "current_scn":p[6] if len(p) > 6 else "",
                })
    else:
        info["error"] = err[:300]

    vl, ve, vo = sql.run_sql("select version from v$instance;", timeout=20)
    if vo and vl: info["oracle_version"] = vl[0].strip()

    rl, re2, ro = sql.run_sql(
        "select value from v$parameter where name='cluster_database';", timeout=20)
    info["is_rac"] = (rl and rl[0].strip().lower() == "true") if ro else None

    info["is_cdb"] = cdb_info.get("is_cdb")
    info["pdbs"]   = cdb_info.get("pdbs", [])
    return info


# ── Tablespaces ───────────────────────────────────────────────────────────────
# CDB scope : runs in CDB$ROOT — returns SYSTEM, SYSAUX, UNDO, shared TEMP
# PDB scope : runs in each open PDB — returns all application tablespaces
#             dba_data_files, dba_tablespaces, dba_free_space, v$temp_space_header

_TS_SQL = """
select ts.tablespace_name,
       round(ts.total_mb,  1),
       round(ts.used_mb,   1),
       round(ts.used_pct,  1),
       ts.autoextensible,
       ts.ts_status,
       ts.contents
from (
  select f.tablespace_name,
         sum(f.bytes) / 1048576                                  total_mb,
         sum(f.bytes - nvl(ff.free_bytes,0)) / 1048576           used_mb,
         round(sum(f.bytes - nvl(ff.free_bytes,0)) /
               nullif(sum(f.bytes),0) * 100, 1)                  used_pct,
         max(f.autoextensible)                                    autoextensible,
         t.status                                                 ts_status,
         t.contents
  from   dba_data_files f
  join   dba_tablespaces t on t.tablespace_name = f.tablespace_name
  left join (
    select tablespace_name, sum(bytes) free_bytes
    from   dba_free_space
    group  by tablespace_name
  ) ff on ff.tablespace_name = f.tablespace_name
  group  by f.tablespace_name, t.status, t.contents
  union all
  select tablespace_name,
         sum(bytes_used + bytes_free) / 1048576,
         sum(bytes_used) / 1048576,
         round(sum(bytes_used) /
               nullif(sum(bytes_used + bytes_free),0) * 100, 1),
         'N/A', 'ONLINE', 'TEMPORARY'
  from   v$temp_space_header
  group  by tablespace_name
) ts
order by ts.used_pct desc nulls last;
"""


def _parse_ts_rows(lines, container, w, c):
    details = []
    for line in lines:
        p = line.split()
        if len(p) < 4: continue
        try:
            name     = p[0]
            total    = float(p[1]) if p[1] not in ("N/A", "-") else 0
            used     = float(p[2]) if p[2] not in ("N/A", "-") else 0
            pct      = float(p[3]) if p[3] not in ("N/A", "-") else 0
            autoext  = p[4] if len(p) > 4 else "UNKNOWN"
            status   = p[5] if len(p) > 5 else "UNKNOWN"
            contents = p[6] if len(p) > 6 else ""
            ts_st    = st_pct(pct, w, c)
            if status.upper() != "ONLINE": ts_st = "CRITICAL"
            issue = None
            if ts_st in ("CRITICAL", "WARNING"):
                issue = "[{}] {} at {}%".format(container, name, pct)
                if autoext.upper() == "NO":
                    issue += (" — NO autoextend, add datafile immediately"
                              if ts_st == "CRITICAL" else " — NO autoextend, monitor closely")
            details.append({
                "name": name, "container": container,
                "total_mb": round(total, 1), "used_mb": round(used, 1),
                "used_pct": pct, "autoextend": autoext,
                "status": ts_st, "ts_status": status,
                "contents": contents, "issue": issue,
            })
        except Exception: continue
    return details


def chk_tablespaces(env, sql, cdb_info, log):
    """
    Non-CDB: one query.
    CDB    : CDB$ROOT query + one query per open PDB via ALTER SESSION SET CONTAINER.
    """
    sec    = {"section": "tablespaces", "section_status": "UNKNOWN", "checks": {}}
    w, c   = THRESHOLDS["ts_warn_pct"], THRESHOLDS["ts_crit_pct"]
    is_cdb = cdb_info.get("is_cdb", False)
    all_details  = []
    by_container = {}
    errors       = []

    # ── CDB$ROOT or non-CDB ─────────────────────────────────────────────────
    root_lbl = "CDB$ROOT" if is_cdb else "NON-CDB"
    log.debug("Tablespace check: {}".format(root_lbl))
    lines, err, ok = sql.run_sql(_TS_SQL.strip(), timeout=60)
    if not ok: errors.append("{}: {}".format(root_lbl, err[:200]))
    root_d = _parse_ts_rows(lines, root_lbl, w, c)
    all_details.extend(root_d)
    by_container[root_lbl] = {
        "details": root_d, "total": len(root_d),
        "critical": sum(1 for d in root_d if d["status"] == "CRITICAL"),
        "warning":  sum(1 for d in root_d if d["status"] == "WARNING"),
        "ok":       sum(1 for d in root_d if d["status"] == "OK"),
        "error": err[:300] if not ok else None,
    }

    # ── Each open PDB ────────────────────────────────────────────────────────
    if is_cdb:
        for pdb in open_pdbs(cdb_info):
            pname = pdb["name"]
            log.debug("Tablespace check: PDB={}".format(pname))
            plines, perr, pok = sql.run_sql_in_pdb(pname, _TS_SQL.strip(), timeout=90)
            if not pok:
                errors.append("{}: {}".format(pname, perr[:200]))
                by_container[pname] = {
                    "details": [], "total": 0, "critical": 0, "warning": 0, "ok": 0,
                    "open_mode": pdb.get("open_mode", ""),
                    "error": "Cannot switch to PDB {}: {}".format(pname, perr[:200]),
                }
                continue
            pdb_d = _parse_ts_rows(plines, pname, w, c)
            all_details.extend(pdb_d)
            by_container[pname] = {
                "details": pdb_d, "total": len(pdb_d),
                "critical": sum(1 for d in pdb_d if d["status"] == "CRITICAL"),
                "warning":  sum(1 for d in pdb_d if d["status"] == "WARNING"),
                "ok":       sum(1 for d in pdb_d if d["status"] == "OK"),
                "open_mode": pdb.get("open_mode", ""),
                "error": perr[:300] if not pok else None,
            }

    all_sts = [d["status"] for d in all_details]
    sec_st  = agg(all_sts) if all_sts else ("ERROR" if errors else "OK")
    sec["section_status"] = sec_st
    sec["checks"]["tablespaces"] = {
        "status": sec_st, "is_cdb": is_cdb,
        "total": len(all_details),
        "critical": all_sts.count("CRITICAL"),
        "warning":  all_sts.count("WARNING"),
        "ok":       all_sts.count("OK"),
        "by_container": by_container,
        "all_details":  all_details,
        "errors": errors if errors else None,
    }
    return sec


# ── Recovery area ─────────────────────────────────────────────────────────────
# CDB scope : v$recovery_file_dest, v$archived_log, v$parameter — CDB-wide
# PDB scope : none (FRA is shared across the entire CDB)

def chk_recovery_area(env, sql, log):
    sec = {"section": "recovery_area", "section_status": "UNKNOWN", "checks": {}}
    w, c = THRESHOLDS["fra_warn_pct"], THRESHOLDS["fra_crit_pct"]

    lines, err, ok = sql.run_sql(
        "select name,"
        " space_limit / 1073741824,"
        " space_used  / 1073741824,"
        " space_reclaimable / 1073741824,"
        " round((space_used - space_reclaimable)"
        " / nullif(space_limit,0) * 100, 1)"
        " from v$recovery_file_dest;", timeout=30)

    fra = {"status": "UNKNOWN", "error": err[:300] if not ok else None}
    if ok and lines:
        for line in lines:
            p = line.split()
            if len(p) < 5: continue
            try:
                fra["path"]           = p[0]
                fra["limit_gb"]       = round(float(p[1]), 2)
                fra["used_gb"]        = round(float(p[2]), 2)
                fra["reclaimable_gb"] = round(float(p[3]), 2)
                fra["used_net_pct"]   = float(p[4])
                fra["used_gross_pct"] = (round(fra["used_gb"] / fra["limit_gb"] * 100, 1)
                                         if fra["limit_gb"] > 0 else 0)
                fra["status"] = st_pct(fra["used_gross_pct"], w, c)
                if fra["status"] != "OK":
                    fra["issue"] = (
                        "FRA at {}% — {:.1f} GB used of {:.1f} GB."
                        " Reclaimable: {:.1f} GB".format(
                            fra["used_gross_pct"], fra["used_gb"],
                            fra["limit_gb"], fra["reclaimable_gb"]))
            except Exception: pass
    elif not ok:
        fra["status"] = "ERROR"

    # Archivelog rate (last hour) — container-wide
    al_lines, al_err, al_ok = sql.run_sql(
        "select count(*),"
        " round(sum(blocks * block_size) / 1073741824, 2)"
        " from v$archived_log"
        " where first_time > sysdate - 1/24"
        " and dest_id = 1;", timeout=30)
    if al_ok and al_lines:
        p = al_lines[0].split()
        if len(p) >= 2:
            try:
                fra["archivelogs_last_hour"]   = int(p[0])
                fra["archivelog_gb_last_hour"] = float(p[1])
                if fra.get("limit_gb", 0) > 0 and fra.get("archivelog_gb_last_hour", 0) > 0:
                    free_gb = (fra["limit_gb"] - fra["used_gb"]
                               + fra.get("reclaimable_gb", 0))
                    hrs = free_gb / fra["archivelog_gb_last_hour"]
                    fra["estimated_hours_to_full"] = round(hrs, 1)
                    if hrs < 4 and fra.get("status") != "CRITICAL":
                        fra["status"] = "CRITICAL"
                        fra["issue"]  = (fra.get("issue", "") +
                            " | Est. full in {:.1f}h at current archivelog rate".format(hrs))
            except Exception: pass

    rp_l, rp_e, rp_o = sql.run_sql(
        "select value from v$parameter"
        " where name = 'db_recovery_file_dest_size';", timeout=20)
    if rp_o and rp_l:
        fra["dest_size_param"] = rp_l[0].strip()

    # ── Per-PDB archivelog generation (CDB only, runs in CDB$ROOT) ───────────
    # v$archived_log has a con_id column in 12c+ that identifies which PDB
    # generated each archivelog.  Non-CDB: this query returns no rows from
    # the group by con_id > 1 filter so it is safe to run unconditionally.
    pdb_arch_lines, pae, pao = sql.run_sql(
        "select p.name,"
        " count(al.sequence#) logs_last_hour,"
        " round(sum(al.blocks * al.block_size) / 1073741824, 3) gb_last_hour"
        " from v$archived_log al"
        " join v$pdbs p on p.con_id = al.con_id"
        " where al.first_time > sysdate - 1/24"
        " and al.dest_id = 1"
        " and al.standby_dest = 'NO'"
        " and p.name != 'PDB$SEED'"
        " group by p.name"
        " order by gb_last_hour desc;", timeout=30)
    if pao and pdb_arch_lines:
        pdb_arch_rates = []
        for line in pdb_arch_lines:
            p = line.split()
            if len(p) >= 3:
                try:
                    pdb_arch_rates.append({
                        "pdb_name":       p[0],
                        "logs_last_hour": int(p[1]),
                        "gb_last_hour":   float(p[2]),
                    })
                except Exception:
                    pass
        if pdb_arch_rates:
            fra["pdb_archivelog_rates"] = pdb_arch_rates

    sec["checks"]["fra"] = fra
    sec["section_status"] = fra.get("status", "UNKNOWN")
    return sec


# ── Invalid objects ───────────────────────────────────────────────────────────
# CDB scope : SYS/SYSTEM invalids at CDB$ROOT (patching indicators)
# PDB scope : application schema invalids inside each open PDB
#             dba_objects, dba_errors

_INV_OBJ_SQL = (
    "select owner, object_name, object_type,"
    " to_char(last_ddl_time,'YYYY-MM-DD HH24:MI:SS')"
    " from dba_objects"
    " where status = 'INVALID'"
    " and owner not in ('SYS','SYSTEM','OUTLN','XDB','CTXSYS','MDSYS',"
    "  'ORDSYS','DBSNMP','WMSYS','EXFSYS','SYSMAN','GSMADMIN_INTERNAL')"
    " order by owner, object_type, object_name;"
)
_INV_ERR_SQL = (
    "select count(*) from dba_errors"
    " where type in ('PACKAGE','PACKAGE BODY','PROCEDURE',"
    "  'FUNCTION','TRIGGER','VIEW');"
)
_SYS_INV_SQL = (
    "select count(*) from dba_objects"
    " where status = 'INVALID'"
    " and owner in ('SYS','SYSTEM');"
)


def _parse_inv_rows(lines):
    objs = []
    for line in lines:
        p = line.split(None, 3)
        if len(p) >= 3:
            objs.append({"owner": p[0], "name": p[1], "type": p[2],
                         "last_ddl": p[3].strip() if len(p) > 3 else ""})
    return objs


def chk_invalid_objects(env, sql, cdb_info, log):
    """
    Non-CDB: query once.
    CDB    : CDB$ROOT for SYS invalids + each open PDB for application invalids.
    """
    sec    = {"section": "invalid_objects", "section_status": "UNKNOWN", "checks": {}}
    is_cdb = cdb_info.get("is_cdb", False)
    all_objects  = []
    by_container = {}
    errors       = []

    root_lbl = "CDB$ROOT" if is_cdb else "NON-CDB"
    lines, err, ok = sql.run_sql(_INV_OBJ_SQL, timeout=60)
    el, ee, eo = sql.run_sql(_INV_ERR_SQL, timeout=30)
    root_comp = 0
    if eo and el:
        try: root_comp = int(el[0].strip())
        except Exception: pass
    root_objs = _parse_inv_rows(lines) if ok else []
    all_objects.extend(root_objs)
    if not ok: errors.append("{}: {}".format(root_lbl, err[:200]))
    by_container[root_lbl] = {
        "objects": root_objs, "total": len(root_objs),
        "compile_errors": root_comp,
        "error": err[:200] if not ok else None,
    }

    if is_cdb:
        for pdb in open_pdbs(cdb_info):
            pname = pdb["name"]
            log.debug("Invalid objects: PDB={}".format(pname))
            plines, perr, pok = sql.run_sql_in_pdb(pname, _INV_OBJ_SQL, timeout=90)
            pel, pee, peo = sql.run_sql_in_pdb(pname, _INV_ERR_SQL, timeout=30)
            pdb_comp = 0
            if peo and pel:
                try: pdb_comp = int(pel[0].strip())
                except Exception: pass
            pdb_objs = _parse_inv_rows(plines) if pok else []
            all_objects.extend(pdb_objs)
            if not pok: errors.append("{}: {}".format(pname, perr[:200]))
            by_container[pname] = {
                "objects": pdb_objs, "total": len(pdb_objs),
                "compile_errors": pdb_comp,
                "open_mode": pdb.get("open_mode", ""),
                "error": perr[:200] if not pok else None,
            }

    sys_lines, se, so = sql.run_sql(_SYS_INV_SQL, timeout=30)
    sys_inv = 0
    if so and sys_lines:
        try: sys_inv = int(sys_lines[0].strip())
        except Exception: pass

    total  = len(all_objects)
    sec_st = ("CRITICAL" if total >= 5
              else "WARNING" if total >= THRESHOLDS["invalid_obj_warn"]
              else "OK")
    if sys_inv > 0 and sec_st == "OK":
        sec_st = "WARNING"

    sec["section_status"] = sec_st
    sec["checks"]["invalid_objects"] = {
        "status": sec_st, "is_cdb": is_cdb,
        "total": total, "by_container": by_container,
        "all_objects": all_objects[:100],
        "sys_invalid_count": sys_inv,
        "sys_note": "SYS/SYSTEM invalid objects may indicate incomplete patching" if sys_inv > 0 else None,
        "errors": errors if errors else None,
    }
    return sec


# ── Scheduled jobs ────────────────────────────────────────────────────────────
# CDB scope : CDB$ROOT — maintenance and sys-level scheduler jobs
# PDB scope : each open PDB — application scheduler and DBMS_JOB

_JOB_SUMMARY_SQL = (
    "select state, count(*)"
    " from dba_scheduler_jobs"
    " group by state"
    " union all"
    " select 'FAILED_24H', count(*)"
    " from dba_scheduler_job_run_details"
    " where status = 'FAILED'"
    " and log_date > sysdate - 1;"
)
_JOB_FAILED_SQL = (
    "select j.job_name, j.owner,"
    " to_char(d.log_date,'YYYY-MM-DD HH24:MI:SS'),"
    " d.error#,"
    " substr(d.additional_info,1,120)"
    " from dba_scheduler_job_run_details d"
    " join dba_scheduler_jobs j"
    "  on j.job_name = d.job_name and j.owner = d.owner"
    " where d.status = 'FAILED'"
    " and d.log_date > sysdate - 1"
    " order by d.log_date desc;"
)
_JOB_RUNNING_SQL = (
    "select j.job_name, j.owner, j.running_instance,"
    " to_char(j.last_start_date,'YYYY-MM-DD HH24:MI:SS'),"
    " round((sysdate - j.last_start_date)*24*60,0) elapsed_min"
    " from dba_scheduler_running_jobs j"
    " order by j.last_start_date;"
)
_DBMSJOB_SQL = (
    "select job, log_user,"
    " to_char(last_date,'YYYY-MM-DD'), last_sec,"
    " failures, broken"
    " from dba_jobs"
    " where failures > 0 or broken = 'Y'"
    " order by failures desc;"
)


def _run_job_checks_for(label, run_fn, log):
    sl, se, so = run_fn(_JOB_SUMMARY_SQL, timeout=60)
    fl, fe, fo = run_fn(_JOB_FAILED_SQL,  timeout=60)
    rl, re2,ro = run_fn(_JOB_RUNNING_SQL, timeout=60)
    ll, le, lo = run_fn(_DBMSJOB_SQL,     timeout=30)

    summary = {"RUNNING": 0, "SCHEDULED": 0, "DISABLED": 0, "FAILED_24H": 0, "SUCCEEDED": 0}
    if so:
        for line in sl:
            p = line.split()
            if len(p) >= 2:
                try: summary[p[0].upper()] = int(p[-1])
                except Exception: pass

    failed = []
    if fo:
        for line in fl:
            p = line.split(None, 4)
            if len(p) >= 3:
                failed.append({"job": p[0], "owner": p[1],
                    "last_run": p[2] if len(p) > 2 else "",
                    "error_num": p[3] if len(p) > 3 else "",
                    "error_info": p[4][:200] if len(p) > 4 else ""})

    running = []
    if ro:
        for line in rl:
            p = line.split()
            if len(p) >= 4:
                try:
                    elapsed = float(p[-1]) if p[-1].replace(".", "", 1).isdigit() else 0
                    running.append({"job": p[0], "owner": p[1],
                        "node": p[2] if len(p) > 2 else "",
                        "started": " ".join(p[3:5]) if len(p) > 4 else p[3],
                        "elapsed_min": int(elapsed)})
                except Exception: pass

    legacy = []
    if lo:
        for line in ll:
            p = line.split()
            if len(p) >= 3:
                legacy.append({"job": p[0], "owner": p[1],
                    "last_run": p[2] if len(p) > 2 else "",
                    "failures": p[4] if len(p) > 4 else "?",
                    "broken": p[5] if len(p) > 5 else "?"})

    any_fail = len(failed) > 0 or len(legacy) > 0
    st = "CRITICAL" if len(failed) >= 3 else "WARNING" if any_fail else "OK"
    return {"status": st, "container": label, "summary": summary,
            "failed_last_24h": failed[:20], "long_running": running[:10],
            "legacy_failures": legacy[:10],
            "error": (fe or se or re2 or "")[:200] or None}


def chk_scheduled_jobs(env, sql, cdb_info, log):
    sec    = {"section": "scheduled_jobs", "section_status": "UNKNOWN", "checks": {}}
    is_cdb = cdb_info.get("is_cdb", False)
    by_container = {}

    root_lbl = "CDB$ROOT" if is_cdb else "NON-CDB"
    log.debug("Job check: {}".format(root_lbl))
    by_container[root_lbl] = _run_job_checks_for(root_lbl, sql.run_sql, log)

    if is_cdb:
        for pdb in open_pdbs(cdb_info):
            pname = pdb["name"]
            log.debug("Job check: PDB={}".format(pname))
            def _pdb(q, timeout=60, _p=pname):
                return sql.run_sql_in_pdb(_p, q, timeout=timeout)
            by_container[pname] = _run_job_checks_for(pname, _pdb, log)

    all_sts = [v["status"] for v in by_container.values()]
    total_f = sum(len(v.get("failed_last_24h", [])) for v in by_container.values())
    sec["section_status"] = agg(all_sts)
    sec["checks"]["scheduler_jobs"] = {
        "status": sec["section_status"], "is_cdb": is_cdb,
        "total_failed_24h": total_f, "by_container": by_container,
    }
    return sec


# ── RMAN backup ───────────────────────────────────────────────────────────────
# CDB scope : v$backup_set_details, v$backup_piece, v$archive_gap — CDB-wide.
#             RMAN backs up the entire CDB; all PDB datafiles are included.
# PDB scope : Per-PDB backup coverage check — queries v$datafile filtered by
#             con_id to detect any PDB whose datafiles were NOT in the last
#             full backup (e.g. PDB added after last backup, or PDB excluded).
#             Runs in CDB$ROOT using con_id column (available 12c+).
#             Also checks v$backup_datafile joined to v$datafile per PDB.

def chk_rman_backup(env, sql, log):
    sec = {"section": "rman_backup", "section_status": "UNKNOWN", "checks": {}}
    sts = []

    # Last full backup
    full_lines, fe, fo = sql.run_sql(
        "select bs.start_time, bs.completion_time,"
        " bs.elapsed_seconds / 60, bs.status,"
        " bs.input_bytes / 1073741824,"
        " bs.output_bytes / 1073741824,"
        " bs.compression_ratio"
        " from v$backup_set_details bs"
        " where bs.backup_type = 'D'"
        " and bs.incremental_level is null"
        " and bs.start_time = ("
        "  select max(b2.start_time)"
        "  from v$backup_set_details b2"
        "  where b2.backup_type = 'D'"
        "  and b2.incremental_level is null)"
        " and rownum = 1;", timeout=60)

    full = {"status": "UNKNOWN", "error": fe[:300] if not fo else None}
    if fo and full_lines:
        p = full_lines[0].split()
        try:
            bst  = p[5] if len(p) > 5 else "UNKNOWN"
            full = {"status": "OK" if bst.upper() in
                    ("COMPLETED","COMPLETED WITH WARNINGS") else "CRITICAL",
                "backup_status": bst,
                "started":   " ".join(p[0:2]) if len(p) >= 2 else p[0],
                "completed": " ".join(p[2:4]) if len(p) >= 4 else "",
                "duration_min": round(float(p[4]), 1) if len(p) > 4 else 0,
                "input_gb":     round(float(p[6]), 2) if len(p) > 6 else 0,
                "output_gb":    round(float(p[7]), 2) if len(p) > 7 else 0,
                "compression_ratio": round(float(p[8]), 2) if len(p) > 8 and float(p[8]) else None,
                "issue": "Full backup status: {}".format(bst) if bst.upper() != "COMPLETED" else None}
            age_l, ae, ao = sql.run_sql(
                "select round((sysdate - max(start_time))*24, 1)"
                " from v$backup_set_details"
                " where backup_type = 'D'"
                " and incremental_level is null;", timeout=30)
            if ao and age_l:
                age_h = float(age_l[0].strip())
                full["age_hours"] = age_h
                age_d = age_h / 24.0
                if age_d >= THRESHOLDS["rman_full_warn_days"]:
                    full["status"] = "CRITICAL"
                    full["issue"]  = "Full backup {:.1f} days old (threshold {} days)".format(
                        age_d, THRESHOLDS["rman_full_warn_days"])
        except Exception as ex:
            full["parse_error"] = str(ex)
    sts.append(full.get("status", "UNKNOWN"))
    sec["checks"]["full_backup"] = full

    # Last incremental backup
    incr_lines, ie, io = sql.run_sql(
        "select bs.start_time, bs.completion_time,"
        " bs.elapsed_seconds / 60, bs.status,"
        " bs.input_bytes / 1073741824,"
        " bs.incremental_level"
        " from v$backup_set_details bs"
        " where bs.backup_type = 'D'"
        " and bs.incremental_level > 0"
        " and bs.start_time = ("
        "  select max(b2.start_time)"
        "  from v$backup_set_details b2"
        "  where b2.backup_type = 'D'"
        "  and b2.incremental_level > 0)"
        " and rownum = 1;", timeout=60)
    incr = {"status": "UNKNOWN", "error": ie[:300] if not io else None}
    if io and incr_lines:
        p = incr_lines[0].split()
        try:
            bst  = p[5] if len(p) > 5 else "UNKNOWN"
            incr = {"status": "OK" if bst.upper() in
                    ("COMPLETED","COMPLETED WITH WARNINGS") else "CRITICAL",
                "backup_status": bst,
                "level":   p[7] if len(p) > 7 else "1",
                "started": " ".join(p[0:2]) if len(p) >= 2 else p[0],
                "completed": " ".join(p[2:4]) if len(p) >= 4 else "",
                "duration_min": round(float(p[4]), 1) if len(p) > 4 else 0,
                "input_gb": round(float(p[6]), 2) if len(p) > 6 else 0,
                "issue": "Incremental backup status: {}".format(bst) if bst.upper() != "COMPLETED" else None}
            age2_l, a2e, a2o = sql.run_sql(
                "select round((sysdate - max(start_time))*24, 1)"
                " from v$backup_set_details"
                " where backup_type = 'D'"
                " and incremental_level > 0;", timeout=30)
            if a2o and age2_l:
                age_h = float(age2_l[0].strip())
                incr["age_hours"] = age_h
                if age_h > THRESHOLDS["rman_age_warn_hours"]:
                    incr["status"] = "WARNING"
                    incr["issue"]  = "No incremental backup for {:.0f}h".format(age_h)
        except Exception as ex:
            incr["parse_error"] = str(ex)
    sts.append(incr.get("status", "UNKNOWN"))
    sec["checks"]["incremental_backup"] = incr

    # Archivelog backup last 24h
    arch_l, ache, acho = sql.run_sql(
        "select count(*),"
        " round(sum(blocks * block_size) / 1073741824, 2)"
        " from v$backup_piece bp"
        " join v$backup_set bs on bs.set_stamp = bp.set_stamp"
        " where bs.backup_type = 'L'"
        " and bp.completion_time > sysdate - 1"
        " and bp.status = 'A';", timeout=60)
    arch = {"status": "UNKNOWN"}
    if acho and arch_l:
        p = arch_l[0].split()
        if len(p) >= 2:
            try:
                cnt = int(p[0]); gb = float(p[1])
                arch = {"status": "OK" if cnt > 0 else "WARNING",
                    "pieces_last_24h": cnt, "size_gb": gb,
                    "issue": "No archivelog backup in last 24h" if cnt == 0 else None}
            except Exception: arch["parse_error"] = arch_l[0]
    sts.append(arch.get("status", "UNKNOWN"))
    sec["checks"]["archivelog_backup"] = arch

    # Archive log gaps
    gap_l, ge, go = sql.run_sql("select count(*) from v$archive_gap;", timeout=20)
    gaps = 0
    if go and gap_l:
        try: gaps = int(gap_l[0].strip())
        except Exception: pass
    sec["checks"]["archive_gaps"] = {
        "status": "CRITICAL" if gaps > 0 else "OK", "gaps": gaps,
        "issue": "{} archive log gap(s) — data loss risk".format(gaps) if gaps > 0 else None}
    sts.append(sec["checks"]["archive_gaps"]["status"])

    # RMAN job failures (7 days)
    rf_l, rfe, rfo = sql.run_sql(
        "select count(*) from v$rman_backup_job_details"
        " where status not in ('COMPLETED','COMPLETED WITH WARNINGS')"
        " and start_time > sysdate - 7;", timeout=30)
    rf = 0
    if rfo and rf_l:
        try: rf = int(rf_l[0].strip())
        except Exception: pass
    sec["checks"]["rman_failures_7d"] = {
        "status": "WARNING" if rf > 0 else "OK", "failed_jobs": rf}
    if rf > 0: sts.append("WARNING")

    # ── Per-PDB backup coverage (CDB only, runs in CDB$ROOT) ─────────────────
    # Identifies PDBs whose datafiles were NOT covered by the most recent full
    # backup — e.g. a PDB plugged in after the last RMAN run, or explicitly
    # excluded via RMAN SKIP.  Uses con_id available from 12c+.
    pdb_cov_lines, pce, pco = sql.run_sql(
        "select p.name pdb_name,"
        " count(df.file#) total_files,"
        " sum(case when bd.file# is not null then 1 else 0 end) backed_files,"
        " count(df.file#) - sum(case when bd.file# is not null then 1 else 0 end) unbacked"
        " from v$pdbs p"
        " join v$datafile df on df.con_id = p.con_id"
        " left join ("
        "   select distinct file# from v$backup_datafile"
        "   where completion_time > sysdate - {days}"
        " ) bd on bd.file# = df.file#"
        " where p.name != 'PDB$SEED'"
        " group by p.name"
        " order by p.name;".format(days=THRESHOLDS["rman_full_warn_days"]),
        timeout=60)
    pdb_coverage = []
    if pco:
        for line in pdb_cov_lines:
            p = line.split()
            if len(p) >= 4:
                try:
                    unbacked = int(p[3])
                    pdb_coverage.append({
                        "pdb_name":     p[0],
                        "total_files":  int(p[1]),
                        "backed_files": int(p[2]),
                        "unbacked_files": unbacked,
                        "status": "CRITICAL" if unbacked > 0 else "OK",
                        "issue": "PDB {} has {} datafile(s) not in backup within {}d".format(
                            p[0], unbacked, THRESHOLDS["rman_full_warn_days"]
                        ) if unbacked > 0 else None,
                    })
                except Exception:
                    pass
    if pdb_coverage:
        pdb_cov_sts = [p["status"] for p in pdb_coverage]
        pdb_cov_st  = agg(pdb_cov_sts)
        if pdb_cov_st != "OK":
            sts.append(pdb_cov_st)
        sec["checks"]["pdb_backup_coverage"] = {
            "status": pdb_cov_st,
            "pdbs": pdb_coverage,
            "note": "Checks whether all PDB datafiles are covered in last {} days".format(
                THRESHOLDS["rman_full_warn_days"]),
        }

    sec["section_status"] = agg(sts)
    return sec


# ── DataPump ──────────────────────────────────────────────────────────────────
# CDB scope : CDB$ROOT — DBA_DATAPUMP_JOBS owned by SYS / root-level jobs
# PDB scope : each open PDB — application expdp/impdp jobs

_DP_SQL = (
    "select owner_name, job_name, operation, job_mode, state,"
    " to_char(start_time,'YYYY-MM-DD HH24:MI:SS'),"
    " to_char(end_time,  'YYYY-MM-DD HH24:MI:SS'),"
    " degree, error_count"
    " from dba_datapump_jobs"
    " where start_time > sysdate - 7"
    " order by start_time desc;"
)


def _parse_dp_rows(lines, container):
    jobs = []
    for line in lines:
        p = line.split(None, 8)
        if len(p) >= 5:
            jobs.append({"container": container,
                "owner": p[0], "job_name": p[1], "operation": p[2],
                "mode": p[3], "state": p[4],
                "start_time": p[5] if len(p) > 5 else "",
                "end_time":   p[6] if len(p) > 6 else "",
                "degree":     p[7] if len(p) > 7 else "",
                "errors": int(p[8]) if len(p) > 8 and p[8].strip().isdigit() else 0})
    return jobs


def chk_datapump(env, sql, cdb_info, log):
    sec    = {"section": "datapump_exports", "section_status": "UNKNOWN", "checks": {}}
    is_cdb = cdb_info.get("is_cdb", False)
    all_jobs     = []
    by_container = {}

    root_lbl = "CDB$ROOT" if is_cdb else "NON-CDB"
    lines, err, ok = sql.run_sql(_DP_SQL, timeout=60)
    root_jobs = _parse_dp_rows(lines, root_lbl) if ok else []
    all_jobs.extend(root_jobs)
    by_container[root_lbl] = {"jobs": root_jobs, "total": len(root_jobs),
        "failed": sum(1 for j in root_jobs if j.get("errors", 0) > 0),
        "error": err[:200] if not ok else None}

    if is_cdb:
        for pdb in open_pdbs(cdb_info):
            pname = pdb["name"]
            log.debug("DataPump check: PDB={}".format(pname))
            plines, perr, pok = sql.run_sql_in_pdb(pname, _DP_SQL, timeout=90)
            pdb_jobs = _parse_dp_rows(plines, pname) if pok else []
            all_jobs.extend(pdb_jobs)
            by_container[pname] = {"jobs": pdb_jobs, "total": len(pdb_jobs),
                "failed": sum(1 for j in pdb_jobs if j.get("errors", 0) > 0),
                "open_mode": pdb.get("open_mode", ""),
                "error": perr[:200] if not pok else None}

    total_f = sum(v["failed"] for v in by_container.values())
    sec_st  = "WARNING" if total_f > 0 else "OK"
    sec["section_status"] = sec_st
    sec["checks"]["datapump_jobs"] = {
        "status": sec_st, "is_cdb": is_cdb,
        "total_7d": len(all_jobs), "total_failed": total_f,
        "by_container": by_container, "all_jobs": all_jobs[:40]}
    return sec


# ── GoldenGate ────────────────────────────────────────────────────────────────
# CDB scope : ggsci is OS-level; all processes visible regardless of PDB.
# PDB scope : none (ggsci is not SQL; extract/replicat connect to a specific
#             PDB via their config — visible in ggsci "info all")
# SQL temp  : ggsci commands written to a mkstemp .oby file (no echo/pipe)

def chk_goldengate(env, sql, log):
    sec = {"section": "goldengate", "section_status": "UNKNOWN", "checks": {}}

    gg_home = os.environ.get("GG_HOME") or os.environ.get("OGG_HOME", "")
    if not gg_home:
        for p in ["/u01/app/oracle/goldengate",
                  "/u01/app/goldengate/product/21c", "/opt/goldengate"]:
            if os.path.isdir(p): gg_home = p; break

    if not gg_home:
        sec["section_status"] = "N/A"
        sec["note"] = "GoldenGate home not found. Set GG_HOME env var."
        return sec

    ggsci = os.path.join(gg_home, "ggsci")
    if not (os.path.isfile(ggsci) and os.access(ggsci, os.X_OK)):
        ggsci = find_bin("ggsci", gg_home)
    if not ggsci:
        sec["section_status"] = "WARNING"
        sec["checks"]["error"] = "ggsci not found in {}".format(gg_home)
        return sec

    sts = []

    def _gg_run(cmd_text, timeout=25):
        """Write ggsci command to a mkstemp .oby file and run via 'ggsci obey file'."""
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".oby", prefix="hc_gg_")
            with os.fdopen(fd, "w") as fh:
                fh.write(cmd_text + "\n")
            out, err, rc = run("{} obey {}".format(ggsci, tmp), timeout=timeout)
            return out, err, rc
        except Exception as ex:
            return "", str(ex), -1
        finally:
            if tmp:
                try: os.unlink(tmp)
                except Exception: pass

    mg_out, mg_err, mg_rc = _gg_run("info mgr")
    mgr_running = "running" in mg_out.lower() or "started" in mg_out.lower()
    mgr_port    = None
    mp = re.search(r"port\s+(\d+)", mg_out, re.I)
    if mp: mgr_port = int(mp.group(1))
    mgr_st = "OK" if mgr_running else "CRITICAL"
    sts.append(mgr_st)
    sec["checks"]["manager"] = {"status": mgr_st, "running": mgr_running,
        "port": mgr_port, "raw": mg_out[:300],
        "error": mg_err[:200] if not mgr_running else None}

    proc_out, pe, pr = _gg_run("info all")
    processes = []
    for line in proc_out.splitlines():
        m = re.match(
            r"\s*(EXTRACT|REPLICAT|DATAPUMP)\s+(\S+)\s+"
            r"(RUNNING|STOPPED|ABENDED|STARTING|RECOVERING)\s*(.*)$", line, re.I)
        if m:
            ptype = m.group(1).upper(); pname = m.group(2).upper()
            pst   = m.group(3).upper(); rest  = m.group(4).strip()
            lag_sec = None
            lm = re.search(r"(\d+):(\d+):(\d+)", rest)
            if lm:
                lag_sec = int(lm.group(1))*3600 + int(lm.group(2))*60 + int(lm.group(3))
            proc_st = ("OK" if pst == "RUNNING"
                       else "CRITICAL" if pst in ("ABENDED","STOPPED") else "WARNING")
            w_l = THRESHOLDS["gg_lag_warn_sec"]; c_l = THRESHOLDS["gg_lag_crit_sec"]
            if lag_sec is not None and pst == "RUNNING":
                if lag_sec >= c_l: proc_st = "CRITICAL"
                elif lag_sec >= w_l and proc_st == "OK": proc_st = "WARNING"
            issue = None
            if pst == "ABENDED":   issue = "{} ABENDED — check ggserr.log".format(pname)
            elif pst == "STOPPED": issue = "{} is STOPPED".format(pname)
            elif lag_sec and lag_sec >= w_l:
                issue = "{} lag {}s >= threshold {}s".format(pname, lag_sec, w_l)
            processes.append({"name": pname, "type": ptype, "status": pst,
                "health": proc_st, "lag_sec": lag_sec, "issue": issue})

    proc_sts = [p["health"] for p in processes]
    proc_agg = agg(proc_sts) if proc_sts else "OK"
    sts.append(proc_agg)
    sec["checks"]["processes"] = {"status": proc_agg,
        "total": len(processes),
        "running": sum(1 for p in processes if p["status"] == "RUNNING"),
        "abended": sum(1 for p in processes if p["status"] == "ABENDED"),
        "stopped": sum(1 for p in processes if p["status"] == "STOPPED"),
        "processes": processes}

    sec["section_status"] = agg(sts)
    return sec


# ── Alert log ─────────────────────────────────────────────────────────────────
# CDB scope : single CDB alert log covers all PDB messages — no per-PDB file
# PDB scope : none needed (all PDB errors appear in the CDB alert log)
# File I/O  : reads alert log with Python open() after locating via v$diag_info

def chk_alert_log(env, sql, log):
    sec  = {"section": "alert_log", "section_status": "UNKNOWN", "checks": {}}
    sts  = []
    hours = THRESHOLDS["alert_log_hours"]

    # ── Locate the CDB alert log (covers all PDB messages) ───────────────────
    adr_lines, ae, ao = sql.run_sql(
        "select value from v$diag_info where name = 'Diag Trace'"
        " union all"
        " select value from v$parameter"
        " where name = 'background_dump_dest';", timeout=30)
    adr_path = ""
    if ao and adr_lines: adr_path = adr_lines[0].strip()

    alert_log = ""
    if adr_path:
        for fname in ["alert_{}.log".format(env.sid),
                      "alert_{}.log".format(env.sid.lower()), "alert.log"]:
            cand = os.path.join(adr_path, fname)
            if os.path.isfile(cand): alert_log = cand; break

    if not alert_log and env.oracle_base:
        diag_base = os.path.join(env.oracle_base, "diag", "rdbms")
        if os.path.isdir(diag_base):
            try:
                for dbdir in sorted(os.listdir(diag_base)):
                    idir = os.path.join(diag_base, dbdir, env.sid.lower(), "trace")
                    cand = os.path.join(idir, "alert_{}.log".format(env.sid.lower()))
                    if os.path.isfile(cand): alert_log = cand; break
            except Exception: pass

    # ── Collect per-PDB trace directories from v$pdbs (CDB 12c+) ─────────────
    # In a CDB the single alert log contains all PDB messages, but each PDB
    # also has its own trace subdirectory under the ADR home for PDB-specific
    # background processes.  We record the paths for operator reference.
    pdb_trace_lines, pte, pto = sql.run_sql(
        "select p.name||'|'||d.value"
        " from v$pdbs p"
        " cross join v$diag_info d"
        " where d.name = 'Diag Trace'"
        " and p.name != 'PDB$SEED'"
        " order by p.name;", timeout=20)
    pdb_trace_paths = {}
    if pto:
        for line in pdb_trace_lines:
            line = line.strip()
            if "|" in line:
                parts = line.split("|", 1)
                pdb_trace_paths[parts[0].strip()] = parts[1].strip()
    if pdb_trace_paths:
        sec["checks"]["pdb_trace_dirs"] = {
            "note": "PDB trace files are in the CDB ADR trace directory. "
                    "The CDB alert log contains all PDB messages.",
            "paths": pdb_trace_paths,
        }

    if not alert_log:
        sec["section_status"] = "WARNING"
        sec["checks"]["alert_log"] = {"status": "WARNING",
            "note": "Alert log not found. Checked adr_path={}, oracle_base={}".format(
                adr_path, env.oracle_base)}
        return _chk_alert_log_via_sql(env, sql, log, sec, sts, hours)

    return _parse_alert_log_file(alert_log, env, sec, sts, hours, log)


def _parse_alert_log_file(alert_log, env, sec, sts, hours, log):
    cutoff  = datetime.datetime.now() - datetime.timedelta(hours=hours)
    err_keys = ["ORA-600","ORA-7445","ORA-1578","ORA-4031","ORA-1650"]
    errors   = {k: [] for k in err_keys}; errors["OTHER"] = []
    err_cnts = {k: 0  for k in err_keys + ["OTHER"]}
    warnings = []; log_sw = 0; chkpt_nc = False; total_e = 0; cur_ts = None

    ts_cls = re.compile(r"^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+\w+\s+\d+\s+\d+:\d+:\d+\s+\d{4}$")
    ts_iso = re.compile(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})")
    try:
        tail_out, _, _ = run("tail -50000 {}".format(alert_log), timeout=45)
        for line in tail_out.splitlines():
            s = line.strip()
            if not s: continue
            m = ts_iso.match(s)
            if m:
                try: cur_ts = datetime.datetime.strptime(m.group(1), "%Y-%m-%dT%H:%M:%S")
                except Exception: pass
                continue
            if ts_cls.match(s):
                try: cur_ts = datetime.datetime.strptime(
                    re.sub(r"\s+", " ", s), "%a %b %d %H:%M:%S %Y")
                except Exception: pass
                continue
            if cur_ts and cur_ts < cutoff: continue
            ts_str = str(cur_ts) if cur_ts else "unknown"
            if "ORA-" in s:
                total_e += 1; matched = False
                for key in err_keys:
                    norm = re.sub(r"ORA-0+", "ORA-", key)
                    if key in s or norm in s:
                        err_cnts[key] += 1
                        if len(errors[key]) < 5:
                            errors[key].append({"timestamp": ts_str, "message": s[:300]})
                        matched = True; break
                if not matched:
                    err_cnts["OTHER"] += 1
                    if len(errors["OTHER"]) < 10:
                        errors["OTHER"].append({"timestamp": ts_str, "message": s[:200]})
            if "checkpoint not complete" in s.lower():
                chkpt_nc = True
                if len(warnings) < 20: warnings.append({"timestamp": ts_str, "message": s})
            if re.search(r"log file switch|thread \d+ advanced", s, re.I):
                log_sw += 1
            if ("WARNING" in s.upper() or "ERROR" in s.upper()) \
                    and "ORA-" not in s and len(warnings) < 20:
                warnings.append({"timestamp": ts_str, "message": s[:200]})
    except Exception as ex:
        sec["checks"]["parse_error"] = str(ex)
        sec["section_status"] = "WARNING"; return sec

    ls_rate = round(log_sw / max(hours, 1), 1); ls_warn = 12; ls_crit = 20
    has_600  = err_cnts["ORA-600"]  > 0
    has_7445 = err_cnts["ORA-7445"] > 0
    has_1578 = err_cnts["ORA-1578"] > 0
    if has_600 or has_7445 or has_1578 or chkpt_nc or ls_rate >= ls_crit:
        al_st = "CRITICAL"
    elif err_cnts["ORA-4031"] > 0 or err_cnts["ORA-1650"] > 0 \
            or ls_rate >= ls_warn or total_e > 0:
        al_st = "WARNING"
    else:
        al_st = "OK"

    msgs = []
    if has_600:   msgs.append("ORA-600 detected!")
    if has_7445:  msgs.append("ORA-7445 detected!")
    if has_1578:  msgs.append("ORA-1578 (block corruption)!")
    if chkpt_nc:  msgs.append("Checkpoint not complete!")
    if err_cnts.get("ORA-4031", 0): msgs.append("{} ORA-4031".format(err_cnts["ORA-4031"]))
    if err_cnts.get("ORA-1650", 0): msgs.append("{} ORA-1650".format(err_cnts["ORA-1650"]))
    if ls_rate >= ls_warn: msgs.append("Log switch {}/hr > {}/hr".format(ls_rate, ls_warn))

    sts.append(al_st)
    sec["checks"]["alert_log"] = {
        "status": al_st, "log_path": alert_log, "hours_scanned": hours,
        "total_ora_errors": total_e, "error_counts": err_cnts,
        "critical_errors": errors["ORA-600"] + errors["ORA-7445"] + errors["ORA-1578"],
        "warning_errors":  errors["ORA-4031"] + errors["ORA-1650"],
        "other_errors": errors["OTHER"][:10],
        "warnings": warnings[:10], "log_switches": log_sw,
        "log_switch_rate_per_hour": ls_rate, "log_switch_threshold": ls_warn,
        "checkpoint_not_complete": chkpt_nc,
        "issue": " | ".join(msgs) if msgs else None}
    sec["section_status"] = agg(sts)
    return sec


def _chk_alert_log_via_sql(env, sql, log, sec, sts, hours):
    """Fallback: query v$diag_alert_ext (12c+) when alert log file not found."""
    lines, err, ok = sql.run_sql(
        "select count(*), originating_timestamp, problem_key, message_text"
        " from v$diag_alert_ext"
        " where originating_timestamp > systimestamp - interval '{h}' hour".format(h=hours) +
        " and message_level <= 2"
        " group by originating_timestamp, problem_key, message_text"
        " order by originating_timestamp desc;", timeout=60)
    if ok and lines:
        errs = [l for l in lines if "ORA-" in l or "CRITICAL" in l.upper()]
        st   = ("CRITICAL" if any("ORA-600" in l or "ORA-7445" in l for l in errs)
                else "WARNING" if errs else "OK")
        sts.append(st)
        sec["checks"]["alert_log_sql"] = {"status": st, "source": "v$diag_alert_ext",
            "critical_errors": [l[:200] for l in errs[:10]]}
    else:
        sec["checks"]["alert_log_sql"] = {"status": "WARNING", "source": "v$diag_alert_ext",
            "note": "Cannot query v$diag_alert_ext — may be 11g or view inaccessible"}
        sts.append("WARNING")
    sec["section_status"] = agg(sts)
    return sec


# ── Sessions and locks ────────────────────────────────────────────────────────
# CDB scope : CDB$ROOT — v$resource_limit, v$session (container-wide in root)
# PDB scope : each open PDB — per-PDB session counts, blocking locks, long queries

_SESS_LIMIT_SQL  = ("select current_utilization, max_utilization, limit_value"
                    " from v$resource_limit where resource_name = 'sessions';")
_BLOCK_LOCK_SQL  = (
    "select waiter.sid, waiter.serial#, waiter.username,"
    " blocker.sid, blocker.username,"
    " round(waiter.seconds_in_wait / 60, 1) wait_min"
    " from v$session waiter, v$session blocker"
    " where waiter.blocking_session = blocker.sid"
    " and waiter.blocking_session_status = 'VALID'"
    " order by wait_min desc;")
_LONG_SQL_SQL = (
    "select s.sid, s.username,"
    " round(s.last_call_et / 60, 1) elapsed_min,"
    " substr(q.sql_text, 1, 80) sql_snippet"
    " from v$session s"
    " left join v$sqlarea q on q.sql_id = s.sql_id"
    " where s.status = 'ACTIVE' and s.type = 'USER'"
    " and s.last_call_et / 60 > 30"
    " order by s.last_call_et desc;")


def _run_session_checks_for(label, run_fn, log):
    sl, se, so = run_fn(_SESS_LIMIT_SQL,  timeout=20)
    bl, be, bo = run_fn(_BLOCK_LOCK_SQL,  timeout=30)
    lql,lqe,lqo= run_fn(_LONG_SQL_SQL,   timeout=30)

    sess = {}
    if so and sl:
        p = sl[0].split()
        if len(p) >= 3:
            try:
                cur = int(p[0]); maxu = int(p[1]); lim = int(p[2])
                pct = round(cur * 100.0 / lim, 1) if lim > 0 else 0
                sess = {"current": cur, "max_ever": maxu, "limit": lim, "used_pct": pct,
                    "status": st_pct(pct, THRESHOLDS["session_warn_pct"], THRESHOLDS["session_crit_pct"])}
            except Exception: pass

    locks = []
    if bo:
        for line in bl:
            p = line.split()
            if len(p) >= 6:
                try:
                    locks.append({"waiter_sid": p[0], "waiter_user": p[2],
                        "blocker_sid": p[3], "blocker_user": p[4],
                        "wait_minutes": float(p[5])})
                except Exception: pass
    long_l = [l for l in locks if l.get("wait_minutes", 0) > 5]
    lock_st= "CRITICAL" if long_l else "WARNING" if locks else "OK"

    lq = []
    if lqo:
        for line in lql:
            p = line.split(None, 3)
            if len(p) >= 3:
                lq.append({"sid": p[0], "user": p[1], "elapsed_min": p[2],
                    "sql": p[3][:80] if len(p) > 3 else ""})
    lq_st = "WARNING" if len(lq) >= 3 else "OK"

    return {"status": agg([sess.get("status", "OK"), lock_st, lq_st]),
        "container": label, "sessions": sess,
        "blocking_locks": {"status": lock_st, "total_blockers": len(locks),
            "long_waits_5min": len(long_l), "details": locks[:10]},
        "long_running_queries": {"status": lq_st, "count": len(lq), "queries": lq[:10]}}


def chk_sessions_locks(env, sql, cdb_info, log):
    sec    = {"section": "sessions_locks", "section_status": "UNKNOWN", "checks": {}}
    is_cdb = cdb_info.get("is_cdb", False)
    by_container = {}

    root_lbl = "CDB$ROOT" if is_cdb else "NON-CDB"
    log.debug("Session check: {}".format(root_lbl))
    by_container[root_lbl] = _run_session_checks_for(root_lbl, sql.run_sql, log)

    if is_cdb:
        for pdb in open_pdbs(cdb_info):
            pname = pdb["name"]
            log.debug("Session check: PDB={}".format(pname))
            def _pdb(q, timeout=30, _p=pname):
                return sql.run_sql_in_pdb(_p, q, timeout=timeout)
            by_container[pname] = _run_session_checks_for(pname, _pdb, log)

    all_sts = [v["status"] for v in by_container.values()]
    sec["section_status"] = agg(all_sts)
    sec["checks"]["sessions"] = {"status": sec["section_status"],
        "is_cdb": is_cdb, "by_container": by_container}
    return sec


# ── Redo logs ─────────────────────────────────────────────────────────────────
# CDB scope : v$log — redo logs are instance-level; shared by all PDBs
# PDB scope : none

def chk_redo_logs(env, sql, log):
    sec = {"section": "redo_logs", "section_status": "UNKNOWN", "checks": {}}
    sts = []

    rl_lines, re2, ro = sql.run_sql(
        "select group#, thread#, members, status,"
        " round(bytes / 1048576, 0) mb"
        " from v$log order by thread#, group#;", timeout=30)
    groups = []
    if ro:
        for line in rl_lines:
            p = line.split()
            if len(p) >= 5:
                groups.append({"group": p[0], "thread": p[1],
                    "members": p[2], "status": p[3], "size_mb": p[4]})
    invalid = [r for r in groups if r.get("status") in ("INVALID", "UNUSED")]
    rl_st   = "WARNING" if invalid else ("OK" if groups else "WARNING")
    sts.append(rl_st)
    sec["checks"]["redo_groups"] = {"status": rl_st,
        "groups": len(groups), "details": groups, "issues": invalid}

    min_m = min(int(r.get("members", 1)) for r in groups) if groups else 0
    if min_m < 2:
        sec["checks"]["multiplexing"] = {"status": "WARNING",
            "note": "Some redo log groups have < 2 members. Add multiplexed members."}
        sts.append("WARNING")
    else:
        sec["checks"]["multiplexing"] = {"status": "OK", "min_members": min_m}

    sec["section_status"] = agg(sts)
    return sec


# ── Performance ───────────────────────────────────────────────────────────────
# CDB scope : v$sgastat, v$pgastat, dba_hist_snapshot — instance-level
# PDB scope : each open PDB — v$system_event (scoped per container in 12c+)

_WAIT_SQL = (
    "select event, total_waits,"
    " round(time_waited / 100, 1) secs"
    " from v$system_event"
    " where event not like 'SQL*Net%'"
    " and event not like '%idle%'"
    " and event not like 'Streams AQ%'"
    " and event not in ('pipe get','pmon timer','rdbms ipc message',"
    "  'class slave wait','Null event')"
    " order by time_waited desc;"
)


def chk_performance(env, sql, cdb_info, log):
    sec    = {"section": "performance", "section_status": "UNKNOWN", "checks": {}}
    is_cdb = cdb_info.get("is_cdb", False)
    sts    = []

    # SGA — CDB/instance-level only
    sga_l, sge, sgo = sql.run_sql(
        "select pool, round(sum(bytes) / 1073741824, 2) gb"
        " from v$sgastat group by pool;", timeout=20)
    sga = {}
    if sgo:
        for line in sga_l:
            p = line.split()
            if len(p) >= 2:
                try: sga[p[0]] = float(p[-1])
                except Exception: pass
    sec["checks"]["sga"] = {"status": "OK", "pools_gb": sga}

    # PGA — CDB/instance-level only
    pga_l, pge, pgo = sql.run_sql(
        "select name, round(value / 1073741824, 2)"
        " from v$pgastat"
        " where name in ('total PGA inuse','total PGA allocated',"
        "  'cache hit percentage');", timeout=20)
    pga = {}
    if pgo:
        for line in pga_l:
            p = line.rsplit(None, 1)
            if len(p) == 2:
                try: pga[p[0].strip()] = float(p[1])
                except Exception: pass
    pga_hit = pga.get("cache hit percentage", 100)
    pga_st  = "WARNING" if pga_hit < 80 else "OK"
    sts.append(pga_st)
    sec["checks"]["pga"] = {"status": pga_st, "stats": pga,
        "issue": "PGA cache hit {:.0f}% < 80%".format(pga_hit) if pga_hit < 80 else None}

    # Wait events — CDB$ROOT
    root_lbl   = "CDB$ROOT" if is_cdb else "NON-CDB"
    wait_by_con = {}
    wl, we, wo = sql.run_sql(_WAIT_SQL, timeout=30)
    root_waits = []
    if wo:
        for line in wl[:10]:
            p = line.rsplit(None, 2)
            if len(p) >= 3:
                root_waits.append({"event": p[0], "waits": p[1], "seconds": p[2]})
    wait_by_con[root_lbl] = root_waits

    # Wait events — each open PDB
    if is_cdb:
        for pdb in open_pdbs(cdb_info):
            pname = pdb["name"]
            log.debug("Performance check: PDB={}".format(pname))
            pwl, pwe, pwo = sql.run_sql_in_pdb(pname, _WAIT_SQL, timeout=60)
            pdb_waits = []
            if pwo:
                for line in pwl[:10]:
                    p = line.rsplit(None, 2)
                    if len(p) >= 3:
                        pdb_waits.append({"event": p[0], "waits": p[1], "seconds": p[2]})
            wait_by_con[pname] = pdb_waits

    sec["checks"]["top_wait_events"] = {"status": "OK", "is_cdb": is_cdb,
        "by_container": wait_by_con}

    # AWR (root only)
    awr_l, ae, ao = sql.run_sql(
        "select count(*) from dba_hist_snapshot"
        " where snap_id = (select max(snap_id) from dba_hist_snapshot);", timeout=20)
    if ao and awr_l:
        try: sec["checks"]["awr"] = {"status": "OK",
                "latest_snapshot_rows": int(awr_l[0].strip())}
        except Exception: pass

    sec["section_status"] = agg(sts) if sts else "OK"
    return sec


# ── RAC-specific ──────────────────────────────────────────────────────────────
# CDB scope : gv$instance, gv$pdbs (CDB only), v$archive_dest, v$sysstat
# PDB scope : gv$pdbs used to check each PDB's open_mode on each RAC node

def chk_rac_specific(env, sql, cdb_info, log):
    sec    = {"section": "rac_checks", "section_status": "UNKNOWN", "checks": {}}
    is_cdb = cdb_info.get("is_cdb", False)
    if env.standalone:
        sec["section_status"] = "N/A"; sec["note"] = "Standalone mode"; return sec
    sts = []

    # All instance status via gv$instance
    inst_l, ie, io = sql.run_sql(
        "select inst_id, instance_name, status, database_status,"
        " active_state, archiver, thread#"
        " from gv$instance order by inst_id;", timeout=30)
    instances = []
    if io:
        for line in inst_l:
            p = line.split()
            if len(p) >= 5:
                st = "OK" if p[2] == "OPEN" and p[3] == "ACTIVE" else "CRITICAL"
                instances.append({"inst_id": p[0], "name": p[1],
                    "status": p[2], "db_status": p[3],
                    "active_state": p[4] if len(p) > 4 else "",
                    "archiver": p[5] if len(p) > 5 else "",
                    "thread": p[6] if len(p) > 6 else "", "health": st})
    inst_agg = agg([i["health"] for i in instances]) if instances else "WARNING"
    sts.append(inst_agg)
    sec["checks"]["instances"] = {"status": inst_agg, "count": len(instances),
        "instances": instances, "error": ie[:200] if not io else None}

    # PDB status across all RAC instances via gv$pdbs (CDB only).
    # Use pipe delimiter: open_mode is "READ WRITE" (two words) so plain split()
    # gives wrong results.
    if is_cdb:
        pdb_l, pie, pio = sql.run_sql(
            "select inst_id||'|'||name||'|'||open_mode||'|'||restricted"
            " from gv$pdbs"
            " where name != 'PDB$SEED'"
            " order by name, inst_id;", timeout=30)
        pdb_status = []
        if pio:
            for line in pdb_l:
                line = line.strip()
                if not line:
                    continue
                p = line.split("|")
                if len(p) >= 3:
                    pdb_status.append({
                        "inst_id":    p[0].strip(),
                        "pdb_name":   p[1].strip(),
                        "open_mode":  p[2].strip() if len(p) > 2 else "",
                        "restricted": p[3].strip() if len(p) > 3 else "",
                    })
        pdb_issues = [p for p in pdb_status if "READ WRITE" not in p.get("open_mode", "")]
        pdb_st = "WARNING" if pdb_issues else "OK"
        sts.append(pdb_st)
        sec["checks"]["pdb_instance_status"] = {
            "status": pdb_st, "total": len(pdb_status),
            "not_open": pdb_issues, "all_pdbs": pdb_status,
            "note": ("All PDBs checked across all RAC instances via gv$pdbs"
                     if pdb_status else "No PDB data returned")}

    # GCS stats
    gcs_l, ge, go = sql.run_sql(
        "select name, round(value / 1000, 0) k_val"
        " from v$sysstat"
        " where name in ('gc cr blocks received','gc current blocks received',"
        "  'gc cr block build time','gc current block pin time')"
        " order by name;", timeout=20)
    gcs = {}
    if go:
        for line in gcs_l:
            p = line.rsplit(None, 1)
            if len(p) == 2:
                try: gcs[p[0].strip()] = int(p[1])
                except Exception: pass
    sec["checks"]["global_cache"] = {"status": "OK", "stats": gcs}

    # Archive destinations
    arch_l, arde, ardo = sql.run_sql(
        "select dest_id, status, target, archiver, destination"
        " from v$archive_dest"
        " where status != 'INACTIVE' and target = 'PRIMARY'"
        " order by dest_id;", timeout=20)
    arch_dests = []
    if ardo:
        for line in arch_l:
            p = line.split(None, 4)
            if len(p) >= 3:
                arch_dests.append({"dest_id": p[0], "status": p[1],
                    "target": p[2], "destination": p[4] if len(p) > 4 else ""})
    failed_d = [a for a in arch_dests if a.get("status") != "VALID"]
    arch_st  = "CRITICAL" if failed_d else ("OK" if arch_dests else "WARNING")
    sts.append(arch_st)
    sec["checks"]["archive_destinations"] = {"status": arch_st,
        "destinations": arch_dests, "failed": failed_d}

    sec["section_status"] = agg(sts)
    return sec


# ════════════════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(
        description="Oracle RAC/CDB Database Health Check (oracle user)")
    ap.add_argument("--output",     default="/tmp",      help="Output directory")
    ap.add_argument("--sid",        default="",          help="ORACLE_SID")
    ap.add_argument("--db-name",    default="",          help="DB unique name")
    ap.add_argument("--standalone", action="store_true", help="Standalone DB (no RAC)")
    ap.add_argument("--debug",      action="store_true", help="Verbose debug logging")
    ap.add_argument("--skip-gg",    action="store_true", help="Skip GoldenGate checks")
    ap.add_argument("--skip-perf",  action="store_true", help="Skip performance checks")
    args = ap.parse_args()

    log = Log(debug=args.debug)
    env = Env(sid=args.sid, standalone=args.standalone, log=log)

    if args.db_name:
        env.db_name = args.db_name
        for k in ("ORACLE_UNQNAME", "DB_UNIQUE_NAME"):
            os.environ[k] = args.db_name

    log.info("=== ORACLE DB health check START | {} | SID={} | user={} ===".format(
        env.hostname, env.sid, env.user))

    if not env.oracle_home:
        log.error("ORACLE_HOME not found. Set ORACLE_HOME or check /etc/oratab.")
        sys.exit(2)

    sql = SQLPlus(env.oracle_home, env.sid, log)

    # Step 1: connectivity
    conn_sec, db_ok = chk_db_connectivity(env, sql, log)

    # Step 2: CDB/PDB detection (required before any section that iterates PDBs)
    cdb_info = {"is_cdb": False, "version": "unknown", "pdbs": []}
    db_info  = {}
    if db_ok:
        cdb_info = detect_cdb_info(sql, log)
        db_info  = chk_database_info(env, sql, cdb_info, log)
        pdb_names = [p["name"] for p in cdb_info.get("pdbs", [])]
        log.info("CDB={} | open PDBs={}".format(
            cdb_info.get("is_cdb"), ", ".join(pdb_names) or "N/A"))

    # Step 3: build section list
    sections_to_run = []
    if db_ok:
        sections_to_run = [
            ("tablespaces",     lambda: chk_tablespaces(env, sql, cdb_info, log)),
            ("recovery_area",   lambda: chk_recovery_area(env, sql, log)),
            ("invalid_objects", lambda: chk_invalid_objects(env, sql, cdb_info, log)),
            ("scheduled_jobs",  lambda: chk_scheduled_jobs(env, sql, cdb_info, log)),
            ("rman_backup",     lambda: chk_rman_backup(env, sql, log)),
            ("datapump_exports",lambda: chk_datapump(env, sql, cdb_info, log)),
            ("sessions_locks",  lambda: chk_sessions_locks(env, sql, cdb_info, log)),
            ("redo_logs",       lambda: chk_redo_logs(env, sql, log)),
            ("alert_log",       lambda: chk_alert_log(env, sql, log)),
            ("rac_checks",      lambda: chk_rac_specific(env, sql, cdb_info, log)),
        ]
        if not args.skip_gg:
            sections_to_run.append(("goldengate", lambda: chk_goldengate(env, sql, log)))
        if not args.skip_perf:
            sections_to_run.append(("performance", lambda: chk_performance(env, sql, cdb_info, log)))
    else:
        log.warn("DB connection failed — skipping all SQL checks")

    # Step 4: run sections
    result  = {"db_connectivity": conn_sec}
    all_sts = [conn_sec.get("section_status", "UNKNOWN")]
    errs    = []
    cnts    = {"CRITICAL": 0, "WARNING": 0, "OK": 0, "ERROR": 0, "N/A": 0}
    cs      = conn_sec.get("section_status", "UNKNOWN")
    cnts[cs] = cnts.get(cs, 0) + 1

    for key, fn in sections_to_run:
        try:
            log.info("Checking: {}".format(key))
            data = fn()
            result[key] = data
            st = data.get("section_status", "UNKNOWN")
            all_sts.append(st)
            cnts[st] = cnts.get(st, 0) + 1
        except Exception as ex:
            tb = traceback.format_exc()
            log.error("Section '{}' failed: {}".format(key, ex))
            result[key] = {"section": key, "section_status": "ERROR",
                "error": str(ex), "traceback": tb[-600:]}
            all_sts.append("ERROR")
            cnts["ERROR"] = cnts.get("ERROR", 0) + 1
            errs.append({"section": key, "error": str(ex)})

    overall = agg(all_sts)

    # Step 5: meta
    try: ip = socket.gethostbyname(env.hostname)
    except Exception: ip = "unknown"

    result["meta"] = {
        "report_type":    "DB",
        "script":         "oracle_healthcheck.py",
        "script_version": SCRIPT_VERSION,
        "server_name":    env.short,
        "hostname":       env.hostname,
        "ip_address":     ip,
        "os":             env.os_ver,
        "oracle_home":    env.oracle_home or "NOT_FOUND",
        "oracle_base":    env.oracle_base,
        "oracle_version": env.oracle_ver,
        "oracle_sid":     env.sid,
        "db_name":        db_info.get("db_name", "") or env.db_name,
        "db_unique":      db_info.get("db_unique", ""),
        "db_role":        db_info.get("db_role", ""),
        "open_mode":      db_info.get("open_mode", ""),
        "log_mode":       db_info.get("log_mode", ""),
        "is_rac":         db_info.get("is_rac"),
        "is_cdb":         cdb_info.get("is_cdb"),
        "pdbs":           cdb_info.get("pdbs", []),
        "standalone":     env.standalone,
        "db_connectable": db_ok,
        "check_date":     now_date(),
        "check_time":     now_time(),
        "check_user":     env.user,
        "overall_status": overall,
        "summary": {
            "total_sections": len(sections_to_run) + 1,
            "critical": cnts.get("CRITICAL", 0),
            "warning":  cnts.get("WARNING", 0),
            "ok":       cnts.get("OK", 0),
            "errors":   cnts.get("ERROR", 0),
            "na":       cnts.get("N/A", 0),
            "section_errors": errs,
        },
        "completed_at": now_ts(),
    }

    ordered = {"meta": result.pop("meta")}
    ordered.update(result)

    # Step 6: write output
    out_dir = args.output
    if not os.path.isdir(out_dir):
        try: os.makedirs(out_dir)
        except Exception as ex:
            log.warn("Cannot create {}: {} — using /tmp".format(out_dir, ex))
            out_dir = "/tmp"

    fname = ("{}_DB_{}.json".format(env.short, datetime.datetime.now().strftime("%Y%m%d"))
             if not env.sid
             else "{}_{}_DB_{}.json".format(
                 env.short, env.sid, datetime.datetime.now().strftime("%Y%m%d")))
    fpath = os.path.join(out_dir, fname)

    written = False
    for path in [fpath, os.path.join("/tmp", fname)]:
        try:
            with open(path, "w") as fh:
                json.dump(ordered, fh, indent=2, default=str)
            log.info("Written: {}".format(path))
            print(path)
            written = True; break
        except Exception as ex:
            log.warn("Cannot write {}: {}".format(path, ex))

    if not written:
        log.error("All write attempts failed!")
        sys.exit(2)

    log.info("=== ORACLE DB health check DONE | overall={} ===".format(overall))
    sys.exit(0 if overall in ("OK", "N/A") else 1 if overall == "WARNING" else 2)


if __name__ == "__main__":
    main()
