#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Oracle RAC / Standalone - Grid Infrastructure Health Check
Run as  : grid user (with GI environment sourced)
Compat  : Python 2.7 and Python 3.x | Solaris / Linux

USAGE:
  python grid_healthcheck.py [--output /path] [--standalone] [--debug]

CRON (grid crontab):
  0 6 * * * GRID_HOME=/u01/app/19.0.0/grid /usr/bin/python \
    /opt/scripts/grid_healthcheck.py --output /shared/hc 2>>/var/log/grid_hc.err
"""
from __future__ import print_function, unicode_literals
import os, sys, json, socket, subprocess, datetime, platform
import re, traceback, argparse, time

try:
    import pwd
    def get_username():
        return pwd.getpwuid(os.getuid()).pw_name
except Exception:
    def get_username():
        return os.environ.get("USER", "unknown")

PY2 = sys.version_info[0] == 2
if PY2:
    string_types = (str, unicode)
    text_type    = unicode
else:
    string_types = (str,)
    text_type    = str

SCRIPT_VERSION = "2.0"

THRESHOLDS = {
    "asm_warn_pct": 75, "asm_crit_pct": 85,
    "fs_warn_pct":  80, "fs_crit_pct":  90,
    "swap_warn_pct":70, "swap_crit_pct":90,
    "cpu_warn_pct": 85, "cpu_crit_pct": 95,
    "ic_latency_warn_ms": 1.0, "ic_latency_crit_ms": 5.0,
}

# ── helpers ──────────────────────────────────────────────────────────────────

def now_ts(): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def now_date(): return datetime.datetime.now().strftime("%Y-%m-%d")
def now_time(): return datetime.datetime.now().strftime("%H:%M:%S")

def st_pct(pct, w, c):
    if pct is None: return "UNKNOWN"
    return "CRITICAL" if pct >= c else "WARNING" if pct >= w else "OK"

def agg(*statuses):
    flat = []
    for s in statuses:
        if isinstance(s, list): flat.extend(s)
        else: flat.append(s)
    for s in ["CRITICAL","ERROR","WARNING","OK","N/A"]:
        if s in flat: return s
    return "UNKNOWN"

class Log(object):
    def __init__(self, debug=False):
        self.debug_on = debug
    def _w(self, lvl, msg):
        print("[{0}] {1}  {2}".format(lvl, now_ts(), msg), file=sys.stderr)
    def info(self, m):  self._w("INFO ", m)
    def warn(self, m):  self._w("WARN ", m)
    def error(self, m): self._w("ERROR", m)
    def debug(self, m):
        if self.debug_on: self._w("DEBUG", m)

def run(cmd, timeout=60, extra_env=None):
    """Run shell command; return (stdout, stderr, rc). Python 2/3 safe."""
    env = os.environ.copy()
    if extra_env: env.update(extra_env)
    try:
        if PY2:
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, env=env)
            out, err = p.communicate()
            rc = p.returncode
        else:
            r = subprocess.run(cmd, shell=True, capture_output=True,
                               timeout=timeout, env=env)
            out, err, rc = r.stdout, r.stderr, r.returncode
        def dec(b):
            return b.decode("utf-8","replace").strip() if isinstance(b,bytes) else str(b).strip()
        return dec(out), dec(err), rc
    except Exception as e:
        return "", str(e), -1

def find_bin(names, grid_home=None):
    """Find first executable from list; check GRID_HOME/bin first."""
    if isinstance(names, str): names = [names]
    dirs = []
    if grid_home: dirs.append(os.path.join(grid_home,"bin"))
    dirs += [d for d in os.environ.get("PATH","").split(os.pathsep) if d]
    dirs += ["/sbin","/usr/sbin","/usr/local/sbin","/bin","/usr/bin","/usr/local/bin"]
    for name in names:
        for d in dirs:
            p = os.path.join(d, name)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None

# ── environment ───────────────────────────────────────────────────────────────

class Env(object):
    def __init__(self, standalone=False, log=None):
        self.log        = log or Log()
        self.standalone = standalone
        self.hostname   = socket.gethostname()
        self.short      = self.hostname.split(".")[0].upper()
        self.os_sys     = platform.system()
        self.os_ver     = self._os_ver()
        self.user       = get_username()
        self.grid_home  = self._find_grid_home()
        self.oracle_base= os.environ.get("ORACLE_BASE","/u01/app/oracle")
        if self.grid_home:
            bp = os.path.join(self.grid_home,"bin")
            os.environ["PATH"] = bp + os.pathsep + os.environ.get("PATH","")
            os.environ["ORACLE_HOME"] = self.grid_home
            os.environ["GI_HOME"]     = self.grid_home

    def _os_ver(self):
        try:
            if platform.system() == "SunOS":
                o,_,_ = run("uname -a", timeout=5)
                return o
            return platform.platform()
        except: return "Unknown"

    def _find_grid_home(self):
        gh = os.environ.get("GRID_HOME") or os.environ.get("GI_HOME")
        if gh and os.path.isdir(gh): return gh
        for p in ["/u01/app/19.0.0/grid","/u01/app/21.0.0/grid",
                  "/u01/app/12.2.0.1/grid","/u01/app/grid/product/19c",
                  "/opt/oracle/grid"]:
            if os.path.isdir(p): return p
        # Try to find from crsctl location in PATH
        crs = find_bin("crsctl")
        if crs:
            return os.path.dirname(os.path.dirname(crs))
        return None

    def bin(self, name): return find_bin(name, self.grid_home)

# ── check functions ───────────────────────────────────────────────────────────

def chk_crsctl(env, log):
    sec = {"section":"clusterware","section_status":"UNKNOWN","checks":{}}
    if env.standalone:
        sec["section_status"] = "N/A"
        sec["note"] = "Standalone mode — clusterware not applicable"
        return sec

    crsctl = env.bin("crsctl")
    if not crsctl:
        sec["section_status"] = "ERROR"
        sec["checks"]["error"] = "crsctl not found. Ensure GRID_HOME is set and grid software installed."
        return sec

    sts = []

    # check crs
    o1,e1,r1 = run("{} check crs".format(crsctl), 30)
    comps = {}
    for line in (o1+"\n"+e1).splitlines():
        for kw in ["CRS","CRSD","CSSD","EVMD","OHASD","MDNSD","GIPCD","GPNPD","DISKMON"]:
            if kw in line.upper():
                st = "ONLINE" if any(w in line.lower() for w in ["online","healthy","active"]) \
                    else "OFFLINE"
                comps[kw] = {"status": st,
                             "issue": "{} not ONLINE".format(kw) if st=="OFFLINE" else None}
    crs_st = "CRITICAL" if any(v["status"]!="ONLINE" for v in comps.values()) \
             else "OK" if (r1==0 and comps) else ("WARNING" if r1==0 else "CRITICAL")
    sts.append(crs_st)
    sec["checks"]["crs_daemons"] = {
        "status": crs_st, "components": comps,
        "error": e1[:400] if r1!=0 else None
    }

    # check cluster -all
    o2,e2,r2 = run("{} check cluster -all".format(crsctl), 45)
    nodes = []
    for m in re.finditer(r"(\w[\w-]+):\s*CRS\s+appears\s+(\w+)", o2, re.I):
        nodes.append({"node": m.group(1), "status": m.group(2).upper()})
    if not nodes:
        # fallback parse
        for m in re.finditer(r"(\w[\w-]+)\s+(ONLINE|OFFLINE)", o2):
            nodes.append({"node": m.group(1), "status": m.group(2)})
    offline = [n for n in nodes if n["status"]!="ONLINE"]
    cl_st   = "CRITICAL" if offline else ("OK" if nodes else "WARNING")
    sts.append(cl_st)
    sec["checks"]["cluster_nodes"] = {
        "status": cl_st, "total": len(nodes),
        "online": len(nodes)-len(offline), "offline": len(offline),
        "nodes": nodes,
        "parse_note": "No nodes parsed — raw: "+o2[:200] if not nodes else None
    }

    # stat res
    o3,e3,r3 = run("{} stat res -t".format(crsctl), 60)
    offline_r = [l.strip() for l in o3.splitlines()
                 if "OFFLINE" in l.upper() and "----" not in l and l.strip()]
    res_st = "WARNING" if offline_r else "OK"
    sts.append(res_st)
    sec["checks"]["cluster_resources"] = {
        "status": res_st, "offline_resources": offline_r[:15]
    }

    # OCR
    ocrcheck = env.bin("ocrcheck")
    if ocrcheck:
        o4,e4,r4 = run(ocrcheck, 30)
        ok4 = r4==0 and "healthy" in (o4+e4).lower()
        bks = []
        for m in re.finditer(r"(day|week|month)\s+(\d{4}[/\-]\d+[/\-]\d+\s+\S+)\s+(\S+)", o4, re.I):
            bks.append({"type":m.group(1),"timestamp":m.group(2),"location":m.group(3)})
        ocr_st = "OK" if ok4 else "CRITICAL"
        sts.append(ocr_st)
        sec["checks"]["ocr"] = {
            "status": ocr_st, "integrity": "PASSED" if ok4 else "FAILED",
            "backups": bks, "error": e4[:300] if not ok4 else None
        }
    else:
        sec["checks"]["ocr"] = {"status":"WARNING","error":"ocrcheck not found"}
        sts.append("WARNING")

    # Voting disks
    o5,e5,r5 = run("{} query css votedisk".format(crsctl), 30)
    vdisks = []
    for line in o5.splitlines():
        if re.search(r"(ONLINE|OFFLINE)", line, re.I):
            st = "ONLINE" if "ONLINE" in line.upper() else "OFFLINE"
            parts = line.strip().split()
            dev = parts[1] if len(parts)>1 else parts[0] if parts else "unknown"
            vdisks.append({"device": dev, "status": st})
    if not vdisks and r5==0:
        # try seq format
        for m in re.finditer(r"\d+\.\s+(\S+)", o5):
            vdisks.append({"device": m.group(1), "status": "ONLINE"})
    vd_offline = [v for v in vdisks if v["status"]!="ONLINE"]
    vd_st = "CRITICAL" if vd_offline else ("OK" if vdisks else "WARNING")
    sts.append(vd_st)
    sec["checks"]["voting_disks"] = {
        "status": vd_st, "total": len(vdisks),
        "online": len(vdisks)-len(vd_offline), "offline": len(vd_offline),
        "disks": vdisks,
        "error": e5[:300] if not vdisks else None
    }

    sec["section_status"] = agg(sts)
    return sec


def chk_srvctl(env, log):
    sec = {"section":"srvctl","section_status":"UNKNOWN","checks":{}}
    if env.standalone:
        sec["section_status"] = "N/A"
        sec["note"] = "Standalone — srvctl not applicable"
        return sec

    srvctl = env.bin("srvctl")
    if not srvctl:
        sec["section_status"] = "ERROR"
        sec["checks"]["error"] = "srvctl not found"
        return sec

    sts = []

    # Get DB name
    dbname = (os.environ.get("ORACLE_UNQNAME") or os.environ.get("DB_UNIQUE_NAME")
              or os.environ.get("ORACLE_SID","")).strip()
    if not dbname:
        o_cfg,_,_ = run("{} config database".format(srvctl), 20)
        dbs = [l.strip() for l in o_cfg.splitlines() if l.strip() and not l.startswith("#")]
        dbname = dbs[0] if dbs else ""

    # DB status
    if dbname:
        o1,e1,r1 = run("{} status database -d {}".format(srvctl, dbname), 40)
    else:
        o1,e1,r1 = run("{} status database".format(srvctl), 40)

    insts = []
    for m in re.finditer(r"Instance\s+(\S+)\s+is\s+(running|stopped|not running)", o1, re.I):
        insts.append({"instance":m.group(1),
                      "status":"ONLINE" if "running" in m.group(2).lower() else "OFFLINE"})
    for m in re.finditer(r"(\S+)\s+is\s+(running|stopped)\s+on\s+node\s+(\S+)", o1, re.I):
        name = m.group(1); node = m.group(3)
        st   = "ONLINE" if "running" in m.group(2).lower() else "OFFLINE"
        known = [i["instance"] for i in insts]
        if name not in known:
            insts.append({"instance":name,"node":node,"status":st})
        else:
            for i in insts:
                if i["instance"]==name: i["node"]=node

    db_off = [i for i in insts if i["status"]!="ONLINE"]
    db_st  = "CRITICAL" if db_off else ("OK" if insts else "WARNING")
    sts.append(db_st)
    sec["checks"]["database"] = {
        "status": db_st, "db_name": dbname or "UNKNOWN",
        "instances": insts,
        "running": len(insts)-len(db_off), "stopped": len(db_off),
        "error": e1[:400] if not insts else None,
        "raw": o1[:300] if not insts else None
    }

    # Services
    svc_cmd = "{} status service -d {}".format(srvctl, dbname) if dbname \
              else "{} status service".format(srvctl)
    o2,e2,r2 = run(svc_cmd, 30)
    svcs = []
    for m in re.finditer(r"Service\s+(\S+)\s+is\s+(running|stopped|not running)", o2, re.I):
        st = "ONLINE" if "running" in m.group(2).lower() else "OFFLINE"
        svcs.append({"name":m.group(1),"status":st,
                     "issue":"Service {} OFFLINE".format(m.group(1)) if st=="OFFLINE" else None})
    svc_off = [s for s in svcs if s["status"]!="ONLINE"]
    svc_st  = "WARNING" if svc_off else ("OK" if svcs else "OK")
    sts.append(svc_st)
    sec["checks"]["services"] = {
        "status": svc_st, "total": len(svcs),
        "online": len(svcs)-len(svc_off), "offline": len(svc_off),
        "services": svcs
    }

    # ASM
    o3,e3,r3 = run("{} status asm".format(srvctl), 20)
    asm_ok = r3==0 and "running" in o3.lower()
    asm_st = "OK" if asm_ok else "CRITICAL"
    sts.append(asm_st)
    sec["checks"]["asm"] = {"status":asm_st, "raw": o3[:200],
                            "error": e3[:200] if not asm_ok else None}

    # Diskgroups via srvctl
    o4,e4,r4 = run("{} status diskgroup".format(srvctl), 20)
    dg_issues = [l.strip() for l in o4.splitlines()
                 if "not mounted" in l.lower() or "offline" in l.lower()]
    dg_st = "WARNING" if dg_issues else "OK"
    sts.append(dg_st)
    sec["checks"]["diskgroups_srvctl"] = {
        "status": dg_st, "issues": dg_issues, "raw": o4[:400]
    }

    sec["section_status"] = agg(sts)
    return sec


def chk_listeners(env, log):
    sec = {"section":"listeners","section_status":"UNKNOWN","checks":{}}

    lsnrctl = env.bin("lsnrctl")
    if not lsnrctl:
        sec["section_status"] = "ERROR"
        sec["checks"]["error"] = "lsnrctl not found. Source GI/DB env before running."
        return sec

    # Discover running listeners from process list
    ps_out,_,_ = run("ps -ef 2>/dev/null || ps aux 2>/dev/null", 15)
    found = set()
    for m in re.finditer(r"tnslsnr\s+(\S+)", ps_out, re.I):
        found.add(m.group(1).upper())

    if not found:
        short = env.short.upper()
        found = {"LISTENER", "LISTENER_{}".format(short)}
        if not env.standalone:
            found.update({"LISTENER_SCAN1","LISTENER_SCAN2","LISTENER_SCAN3"})

    sts = []
    results = {}
    for lname in sorted(found)[:12]:
        log.debug("Checking: lsnrctl status {}".format(lname))
        o,e,r = run("{} status {} 2>&1".format(lsnrctl, lname), 25)
        up = r==0 and (len(o)>40) and any(kw in o.lower()
             for kw in ["uptime","service","alias","started"])
        port = 1521
        pm = re.search(r"PORT\s*=\s*(\d+)", o, re.I)
        if pm: port = int(pm.group(1))
        uptime = ""
        um = re.search(r"Uptime\s+(.*)", o, re.I)
        if um: uptime = um.group(1).strip()
        svc_count = 0
        sm = re.search(r"(\d+)\s+(?:services?|instance)", o, re.I)
        if sm: svc_count = int(sm.group(1))
        st = "OK" if up else "CRITICAL"
        sts.append(st)
        results[lname] = {
            "status": st, "port": port, "uptime": uptime,
            "services_registered": svc_count,
            "connection_test": "PASSED" if up else "FAILED",
            "error": (e+"\n"+o)[:400] if not up else None
        }

    sec["checks"]["listeners"] = results

    # SCAN listeners (RAC)
    if not env.standalone:
        srvctl = env.bin("srvctl")
        scan_res = {"status":"UNKNOWN","scan_listeners":[],"scan_vips":[]}
        scan_sts = []
        if srvctl:
            os1,_,rc1 = run("{} status scan_listener".format(srvctl), 30)
            for m in re.finditer(r"(LISTENER_SCAN\d+)\s+is\s+(running|stopped)", os1, re.I):
                st = "RUNNING" if "running" in m.group(2).lower() else "STOPPED"
                scan_res["scan_listeners"].append({"name":m.group(1),"status":st})
                scan_sts.append(st)
            os2,_,rc2 = run("{} status scan".format(srvctl), 20)
            for line in os2.splitlines():
                mv = re.search(r"(scan.*?vip\w*|SCAN VIP\s*\d*)\s+\S+\s+is\s+(online|offline|running|stopped)",
                               line, re.I)
                if mv:
                    st = "ONLINE" if mv.group(2).lower() in ("online","running") else "OFFLINE"
                    scan_res["scan_vips"].append({"status":st,"raw":line.strip()})
        if scan_sts:
            stopped = [s for s in scan_sts if s!="RUNNING"]
            scan_res["status"] = "CRITICAL" if stopped else "OK"
        elif not scan_res["scan_listeners"]:
            scan_res["status"] = "WARNING"
            scan_res["note"]   = "Could not parse SCAN status — ensure srvctl is accessible"
        sts.append(scan_res["status"])
        sec["checks"]["scan"] = scan_res

    sec["section_status"] = agg(sts) if sts else "UNKNOWN"
    return sec


def chk_asm(env, log):
    sec = {"section":"asm","section_status":"UNKNOWN","checks":{}}
    sts = []

    # Check ASM process
    ps_out,_,_ = run("ps -ef 2>/dev/null || ps aux 2>/dev/null", 15)
    asm_procs = [l for l in ps_out.splitlines()
                 if "+asm" in l.lower() and "pmon" in l.lower()]
    asm_up = len(asm_procs) > 0
    asm_inst = "+ASM"
    for line in asm_procs:
        m = re.search(r"pmon_(\+ASM\d*)", line, re.I)
        if m: asm_inst = m.group(1); break
    if asm_inst == "+ASM":
        n = re.search(r"\d+", env.short)
        if n: asm_inst = "+ASM{}".format(n.group())
    sec["checks"]["instance"] = {
        "name": asm_inst, "status": "RUNNING" if asm_up else "NOT RUNNING",
        "health": "OK" if asm_up else "CRITICAL"
    }
    sts.append("OK" if asm_up else "CRITICAL")

    asmcmd = env.bin("asmcmd")
    if not asmcmd:
        sec["section_status"] = agg(sts)
        sec["checks"]["asmcmd"] = {"status":"WARNING","error":"asmcmd not found in GRID_HOME/bin"}
        return sec

    aenv = dict(os.environ)
    aenv["ORACLE_SID"]  = asm_inst
    aenv["ORACLE_HOME"] = env.grid_home or os.environ.get("ORACLE_HOME","")

    # Diskgroups
    o1,e1,r1 = run("{} lsdg 2>&1".format(asmcmd), 60, aenv)
    dgs = []
    for line in o1.splitlines():
        if not line.strip() or line.startswith("State") or "----" in line: continue
        p = line.split()
        if len(p) < 9: continue
        try:
            state    = p[0]; dg_type = p[1]
            total_mb = float(p[7]); free_mb = float(p[8])
            dg_name  = p[-1].rstrip("/")
            if not dg_name.startswith("+"): dg_name = "+"+dg_name
            used_pct = round((total_mb-free_mb)/total_mb*100,1) if total_mb>0 else 0
            w = THRESHOLDS["asm_warn_pct"]; c = THRESHOLDS["asm_crit_pct"]
            if state.upper() != "MOUNTED":
                st = "CRITICAL"
            else:
                st = st_pct(used_pct, w, c)
            offline_d = 0
            try: offline_d = int(p[-4])
            except: pass
            issue = None
            if state.upper()!="MOUNTED":
                issue = "{} state is {} (expected MOUNTED)".format(dg_name, state)
            elif offline_d > 0:
                issue = "{} has {} offline disk(s)".format(dg_name, offline_d)
            elif st=="CRITICAL":
                issue = "{} at {}% — expand immediately (threshold {}%)".format(dg_name, used_pct, c)
            elif st=="WARNING":
                issue = "{} at {}% — plan expansion (threshold {}%)".format(dg_name, used_pct, w)
            dgs.append({
                "name":dg_name,"state":state,"redundancy":dg_type,
                "total_gb":round(total_mb/1024,1),"free_gb":round(free_mb/1024,1),
                "used_gb":round((total_mb-free_mb)/1024,1),"used_pct":used_pct,
                "status":st,"offline_disks":offline_d,"issue":issue
            })
        except Exception as ex:
            log.warn("Could not parse DG line: {} ({})".format(line, ex))
    dg_sts = [d["status"] for d in dgs]
    dg_st  = agg(dg_sts) if dg_sts else "WARNING"
    sts.append(dg_st)
    sec["checks"]["diskgroups"] = {
        "status":dg_st,"count":len(dgs),"diskgroups":dgs,
        "error": e1[:400] if not dgs else None
    }

    # Rebalance
    o2,e2,r2 = run("{} lsop 2>&1 || {} lsattr -G 2>&1".format(asmcmd,asmcmd), 30, aenv)
    rebal = [l.strip() for l in o2.splitlines() if "rebal" in l.lower() and l.strip()]
    sec["checks"]["rebalance"] = {
        "status":"WARNING" if rebal else "OK",
        "active_operations": rebal[:10]
    }

    sec["section_status"] = agg(sts)
    return sec


def chk_network(env, log):
    sec = {"section":"network","section_status":"UNKNOWN","checks":{}}
    sts = []

    # Hostname resolve
    try:
        ip = socket.gethostbyname(env.hostname)
        sec["checks"]["dns"] = {"status":"OK","hostname":env.hostname,"resolved":ip}
        sts.append("OK")
    except Exception as ex:
        sec["checks"]["dns"] = {"status":"WARNING","hostname":env.hostname,"error":str(ex)}
        sts.append("WARNING")

    # Interfaces
    if env.os_sys == "SunOS":
        ifc_out,_,_ = run("ifconfig -a 2>/dev/null", 15)
    else:
        ifc_out,_,_ = run("ip link show 2>/dev/null || ifconfig -a 2>/dev/null", 15)
    ifaces = []
    cur = None
    for line in ifc_out.splitlines():
        m = re.match(r"^(\w[\w.:]+):", line)
        if m:
            cur = {"name":m.group(1),"status":"UP" if "UP" in line else "DOWN","flags":line.strip()}
            ifaces.append(cur)
        elif cur and "inet " in line:
            im = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)", line)
            if im: cur["ip"] = im.group(1)
    sec["checks"]["interfaces"] = {"status":"OK","list":ifaces[:12]}

    # Interconnect ping
    priv_ip = _find_priv_ip(env)
    if priv_ip:
        if env.os_sys == "SunOS":
            ping_cmd = "ping -s {} 8192 3 2>&1".format(priv_ip)
        else:
            ping_cmd = "ping -c 3 -s 8192 {} 2>&1 || ping -c 3 {} 2>&1".format(priv_ip, priv_ip)
        po,_,pr = run(ping_cmd, 20)
        latency = None
        for pat in [r"avg.*?=\s*[\d.]+/([\d.]+)", r"time[=<]([\d.]+)\s*ms"]:
            lm = re.search(pat, po)
            if lm: latency = float(lm.group(1)); break
        w = THRESHOLDS["ic_latency_warn_ms"]; c = THRESHOLDS["ic_latency_crit_ms"]
        if latency is not None:
            ping_st = "CRITICAL" if latency>=c else "WARNING" if latency>=w else "OK"
        else:
            ping_st = "OK" if pr==0 else "WARNING"
        sts.append(ping_st)
        sec["checks"]["interconnect"] = {
            "status":ping_st,"private_ip":priv_ip,"latency_ms":latency,
            "reachable":pr==0,
            "issue":"Latency {}ms >= threshold {}ms".format(latency,w) if latency and latency>=w else None
        }
    else:
        sec["checks"]["interconnect"] = {"status":"WARNING",
                                         "note":"Private interconnect IP not detected"}

    sec["section_status"] = agg(sts) if sts else "OK"
    return sec


def _find_priv_ip(env):
    try:
        with open("/etc/hosts") as fh:
            for line in fh:
                if "priv" in line.lower() and env.short.lower() in line.lower():
                    parts = line.strip().split()
                    if parts and re.match(r"^\d+\.\d+\.\d+\.\d+$", parts[0]):
                        return parts[0]
    except: pass
    out,_,_ = run("ifconfig -a 2>/dev/null", 15)
    for m in re.finditer(r"inet\s+(192\.168\.\d+\.\d+|172\.\d+\.\d+\.\d+)", out):
        return m.group(1)
    return None


def chk_mountpoints(env, log):
    sec = {"section":"mount_points","section_status":"UNKNOWN","checks":{}}
    sts = []
    w = THRESHOLDS["fs_warn_pct"]; c = THRESHOLDS["fs_crit_pct"]

    # Filesystems
    if env.os_sys == "SunOS":
        df_out,df_err,_ = run("df -kl 2>/dev/null || df -k 2>/dev/null", 30)
    else:
        df_out,df_err,_ = run("df -k --local 2>/dev/null || df -k 2>/dev/null", 30)
    fss = []
    for line in df_out.splitlines():
        parts = line.split()
        if len(parts) < 5 or "Filesystem" in parts[0] or parts[0].startswith("-"):
            continue
        pct_str = None
        for p in parts:
            if p.endswith("%"):
                pct_str = p; break
        if not pct_str: continue
        try:
            pct   = int(pct_str.rstrip("%"))
            mount = parts[-1]
            total = int(parts[1]) if parts[1].isdigit() else 0
            used  = int(parts[2]) if len(parts)>2 and parts[2].isdigit() else 0
            st    = "CRITICAL" if pct>=c else "WARNING" if pct>=w else "OK"
            fss.append({
                "mount":mount,"device":parts[0],
                "total_gb":round(total/1024/1024.0,1) if total else None,
                "used_gb": round(used /1024/1024.0,1) if used  else None,
                "used_pct":pct,"status":st,
                "issue": "{} at {}%".format(mount,pct) if st!="OK" else None
            })
        except: continue
    fs_st = agg([f["status"] for f in fss]) if fss else "WARNING"
    sts.append(fs_st)
    sec["checks"]["filesystems"] = {
        "status":fs_st,"count":len(fss),"filesystems":fss,
        "critical":[f for f in fss if f["status"]=="CRITICAL"],
        "warning": [f for f in fss if f["status"]=="WARNING"],
        "error": df_err[:300] if not fss else None
    }

    # Inodes
    if env.os_sys != "SunOS":
        di_out,_,_ = run("df -i --local 2>/dev/null || df -i 2>/dev/null", 20)
        inode_warn = []
        for line in di_out.splitlines():
            parts = line.split()
            if len(parts)<5: continue
            for p in parts:
                if p.endswith("%"):
                    try:
                        pct = int(p.rstrip("%"))
                        if pct >= w:
                            inode_warn.append({"mount":parts[-1],"used_pct":pct,
                                "status":"CRITICAL" if pct>=c else "WARNING"})
                    except: pass
        in_st = agg([i["status"] for i in inode_warn]) if inode_warn else "OK"
        sts.append(in_st)
        sec["checks"]["inodes"] = {"status":in_st,"issues":inode_warn}

    # Swap
    sw_used_pct = None
    if env.os_sys == "SunOS":
        sw,_,_ = run("swap -s 2>/dev/null", 15)
        m = re.search(r"(\d+)k\s+used.*?(\d+)k\s+available", sw)
        if m:
            u=int(m.group(1)); a=int(m.group(2))
            t=u+a; sw_used_pct = int(u*100/t) if t else 0
    else:
        fr,_,_ = run("free -k 2>/dev/null", 10)
        for line in fr.splitlines():
            if line.lower().startswith("swap"):
                parts = line.split()
                if len(parts)>=3:
                    try:
                        t=int(parts[1]); u=int(parts[2])
                        sw_used_pct = int(u*100/t) if t else 0
                    except: pass
    if sw_used_pct is not None:
        sw_st = st_pct(sw_used_pct, THRESHOLDS["swap_warn_pct"], THRESHOLDS["swap_crit_pct"])
        sts.append(sw_st)
        sec["checks"]["swap"] = {"status":sw_st,"used_pct":sw_used_pct}

    sec["section_status"] = agg(sts) if sts else "UNKNOWN"
    return sec


def chk_sysinfo(env):
    info = {"hostname":env.hostname,"short_hostname":env.short,
            "ip_address":"unknown","os":env.os_sys,"os_version":env.os_ver,
            "kernel":"","cpu_count":0,"memory_gb":0,"uptime":""}
    try: info["ip_address"] = socket.gethostbyname(env.hostname)
    except: pass
    try: info["kernel"] = platform.release()
    except: pass
    try:
        u,_,_ = run("uptime 2>/dev/null", 10)
        info["uptime"] = u[:100]
    except: pass
    try:
        if env.os_sys == "SunOS":
            co,_,_ = run("psrinfo -p 2>/dev/null || psrinfo 2>/dev/null | wc -l", 10)
            info["cpu_count"] = int(co.strip()) if co.strip().isdigit() else 0
            mo,_,_ = run("prtconf 2>/dev/null | grep -i 'memory size'", 15)
            mm = re.search(r"(\d+)\s*Megabytes", mo, re.I)
            if mm: info["memory_gb"] = round(int(mm.group(1))/1024.0,1)
        else:
            co,_,_ = run("nproc 2>/dev/null || grep -c processor /proc/cpuinfo 2>/dev/null", 10)
            info["cpu_count"] = int(co.strip()) if co.strip().isdigit() else 0
            mo,_,_ = run("grep MemTotal /proc/meminfo 2>/dev/null", 10)
            mm = re.search(r"(\d+)\s+kB", mo)
            if mm: info["memory_gb"] = round(int(mm.group(1))/1024.0/1024.0,1)
    except: pass
    return info

# ── main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Oracle RAC Grid Health Check")
    ap.add_argument("--output",     default="/tmp",    help="Output directory")
    ap.add_argument("--db-name",    default="",        help="DB unique name (optional)")
    ap.add_argument("--standalone", action="store_true",help="Standalone DB (no RAC)")
    ap.add_argument("--debug",      action="store_true",help="Debug logging")
    args = ap.parse_args()

    log = Log(debug=args.debug)
    env = Env(standalone=args.standalone, log=log)

    if args.db_name:
        for k in ("ORACLE_UNQNAME","DB_UNIQUE_NAME"):
            os.environ[k] = args.db_name

    log.info("=== GRID health check START | {} | user={} ===".format(env.hostname, env.user))

    sections_to_run = [
        ("clusterware",  lambda: chk_crsctl(env, log)),
        ("srvctl",       lambda: chk_srvctl(env, log)),
        ("listeners",    lambda: chk_listeners(env, log)),
        ("asm",          lambda: chk_asm(env, log)),
        ("network",      lambda: chk_network(env, log)),
        ("mount_points", lambda: chk_mountpoints(env, log)),
    ]

    result    = {}
    all_sts   = []
    errs      = []
    cnts      = {"CRITICAL":0,"WARNING":0,"OK":0,"ERROR":0,"N/A":0}

    for key, fn in sections_to_run:
        try:
            log.info("Checking: {}".format(key))
            data = fn()
            result[key] = data
            st = data.get("section_status","UNKNOWN")
            all_sts.append(st)
            cnts[st] = cnts.get(st,0) + 1
        except Exception as ex:
            tb = traceback.format_exc()
            log.error("Section '{}' failed: {}".format(key, ex))
            result[key] = {"section":key,"section_status":"ERROR",
                           "error":str(ex),"traceback":tb[-600:]}
            all_sts.append("ERROR")
            cnts["ERROR"] = cnts.get("ERROR",0)+1
            errs.append({"section":key,"error":str(ex)})

    sysinfo = chk_sysinfo(env)
    overall  = agg(all_sts)

    result["meta"] = {
        "report_type":   "GRID",
        "script":        "grid_healthcheck.py",
        "script_version":SCRIPT_VERSION,
        "server_name":   env.short,
        "hostname":      env.hostname,
        "ip_address":    sysinfo.get("ip_address","unknown"),
        "os":            sysinfo.get("os_version", env.os_ver),
        "grid_home":     env.grid_home or "NOT_FOUND",
        "oracle_base":   env.oracle_base,
        "oracle_version":os.environ.get("ORACLE_VERSION","unknown"),
        "check_date":    now_date(),
        "check_time":    now_time(),
        "check_user":    env.user,
        "standalone":    env.standalone,
        "overall_status":overall,
        "summary":       {
            "total_sections": len(sections_to_run),
            "critical": cnts.get("CRITICAL",0),
            "warning":  cnts.get("WARNING",0),
            "ok":       cnts.get("OK",0),
            "errors":   cnts.get("ERROR",0),
            "na":       cnts.get("N/A",0),
            "section_errors": errs
        },
        "system_info":   sysinfo,
        "completed_at":  now_ts()
    }

    # Move meta to top
    ordered = {"meta": result.pop("meta")}
    ordered.update(result)

    # Write output
    out_dir = args.output
    if not os.path.isdir(out_dir):
        try: os.makedirs(out_dir)
        except Exception as ex:
            log.warn("Cannot create {}: {} — using /tmp".format(out_dir, ex))
            out_dir = "/tmp"

    fname = "{}_GRID_{}.json".format(env.short, datetime.datetime.now().strftime("%Y%m%d"))
    fpath = os.path.join(out_dir, fname)

    written = False
    for path in [fpath, os.path.join("/tmp", fname)]:
        try:
            with open(path,"w") as fh:
                json.dump(ordered, fh, indent=2, default=str)
            log.info("Written: {}".format(path))
            print(path)
            written = True
            break
        except Exception as ex:
            log.warn("Cannot write {}: {}".format(path, ex))

    if not written:
        log.error("All write attempts failed!")
        sys.exit(2)

    log.info("=== GRID health check DONE | overall={} ===".format(overall))
    sys.exit(0 if overall in ("OK","N/A") else 1 if overall=="WARNING" else 2)

if __name__ == "__main__":
    main()
