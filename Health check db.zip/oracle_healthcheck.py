#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Oracle RAC / Standalone - Database Health Check Script
Run as  : oracle user (with DB environment sourced: ORACLE_HOME, ORACLE_SID)
Compat  : Python 2.7 and Python 3.x | Solaris / Linux

USAGE:
  python oracle_healthcheck.py [--output /path] [--sid MYSID] \
                               [--db-name MYDB] [--standalone] [--debug]

ENVIRONMENT REQUIRED:
  ORACLE_HOME, ORACLE_SID, PATH (must include $ORACLE_HOME/bin)
  For sysdba: wallet or /etc/oratab + bequeath connection

CRON (oracle crontab):
  0 6 * * * . /home/oracle/.profile && /usr/bin/python \
    /opt/scripts/oracle_healthcheck.py \
    --output /shared/hc --sid FINDB1 2>>/var/log/oracle_hc.err
"""
from __future__ import print_function, unicode_literals
import os, sys, json, socket, subprocess, datetime, platform
import re, traceback, argparse, tempfile, time

try:
    import pwd
    def get_username():
        return pwd.getpwuid(os.getuid()).pw_name
except Exception:
    def get_username():
        return os.environ.get("USER","unknown")

PY2 = sys.version_info[0] == 2
if PY2:
    string_types = (str, unicode)
    text_type    = unicode
else:
    string_types = (str,)
    text_type    = str

SCRIPT_VERSION = "2.0"

THRESHOLDS = {
    "ts_warn_pct":      80,
    "ts_crit_pct":      90,
    "fra_warn_pct":     75,
    "fra_crit_pct":     85,
    "gg_lag_warn_sec":  60,
    "gg_lag_crit_sec":  300,
    "job_runtime_warn_x": 2.0,  # N times expected
    "rman_age_warn_hours": 25,
    "rman_full_warn_days": 8,
    "alert_log_hours":  24,
    "invalid_obj_warn": 1,
    "session_warn_pct": 80,
    "session_crit_pct": 90,
}

# ── helpers (same helpers as grid script) ────────────────────────────────────

def now_ts():   return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def now_date(): return datetime.datetime.now().strftime("%Y-%m-%d")
def now_time(): return datetime.datetime.now().strftime("%H:%M:%S")

def st_pct(pct, w, c):
    if pct is None: return "UNKNOWN"
    return "CRITICAL" if pct >= c else "WARNING" if pct >= w else "OK"

def agg(*statuses):
    flat = []
    for s in statuses:
        if isinstance(s, list): flat.extend(s)
        else: flat.append(s)
    for s in ["CRITICAL","ERROR","WARNING","OK","N/A"]:
        if s in flat: return s
    return "UNKNOWN"

class Log(object):
    def __init__(self, debug=False):
        self.debug_on = debug
    def _w(self, lvl, msg):
        print("[{0}] {1}  {2}".format(lvl, now_ts(), msg), file=sys.stderr)
    def info(self, m):  self._w("INFO ", m)
    def warn(self, m):  self._w("WARN ", m)
    def error(self, m): self._w("ERROR", m)
    def debug(self, m):
        if self.debug_on: self._w("DEBUG", m)

def run(cmd, timeout=60, extra_env=None):
    env = os.environ.copy()
    if extra_env: env.update(extra_env)
    try:
        if PY2:
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, env=env)
            out, err = p.communicate()
            rc = p.returncode
        else:
            r = subprocess.run(cmd, shell=True, capture_output=True,
                               timeout=timeout, env=env)
            out, err, rc = r.stdout, r.stderr, r.returncode
        def dec(b):
            return b.decode("utf-8","replace").strip() if isinstance(b,bytes) else str(b).strip()
        return dec(out), dec(err), rc
    except Exception as e:
        return "", str(e), -1

def find_bin(names, oracle_home=None):
    if isinstance(names, str): names = [names]
    dirs = []
    if oracle_home: dirs.append(os.path.join(oracle_home,"bin"))
    dirs += [d for d in os.environ.get("PATH","").split(os.pathsep) if d]
    dirs += ["/sbin","/usr/sbin","/bin","/usr/bin","/usr/local/bin"]
    for name in names:
        for d in dirs:
            p = os.path.join(d, name)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None

# ── SQL*Plus wrapper ──────────────────────────────────────────────────────────

class SQLPlus(object):
    """Thin wrapper around sqlplus for running queries."""

    def __init__(self, oracle_home, sid, log):
        self.oracle_home = oracle_home
        self.sid         = sid
        self.log         = log
        self.sqlplus     = find_bin("sqlplus", oracle_home)
        self.available   = self.sqlplus is not None

    def run_sql(self, sql, timeout=120):
        """
        Run SQL via sqlplus / as sysdba.
        Returns (output_lines, error_string, success_bool).
        """
        if not self.available:
            return [], "sqlplus not found in ORACLE_HOME/bin", False

        # Build sqlplus script
        script = (
            "set pagesize 0\n"
            "set linesize 500\n"
            "set feedback off\n"
            "set heading off\n"
            "set echo off\n"
            "set trimout on\n"
            "set trimspool on\n"
            "set define off\n"
            "set serverout off\n"
            "whenever sqlerror exit 1\n"
            + sql + "\n"
            "exit;\n"
        )

        env = os.environ.copy()
        env["ORACLE_SID"]  = self.sid
        env["ORACLE_HOME"] = self.oracle_home
        bin_path = os.path.join(self.oracle_home, "bin")
        lib_path = os.path.join(self.oracle_home, "lib")
        env["PATH"] = bin_path + os.pathsep + env.get("PATH","")
        if platform.system() == "SunOS":
            for lv in ("LD_LIBRARY_PATH","LD_LIBRARY_PATH_64"):
                env[lv] = lib_path + os.pathsep + env.get(lv,"")
        else:
            env["LD_LIBRARY_PATH"] = lib_path + os.pathsep + env.get("LD_LIBRARY_PATH","")

        # Write script to temp file (avoids shell escaping issues)
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".sql", prefix="hc_")
            with os.fdopen(fd,"w") as fh:
                fh.write(script)

            cmd = "{} -s '/ as sysdba' @{}".format(self.sqlplus, tmp)
            out, err, rc = run(cmd, timeout=timeout, extra_env=env)

            # Detect connection errors
            conn_errors = ["ORA-01034","ORA-01089","ORA-01090","ORA-12514",
                           "ORA-12541","SP2-0640","SP2-0641","NL-00405",
                           "TNS-","not available","ORACLE not available"]
            for ce in conn_errors:
                if ce in out or ce in err:
                    return [], "DB not accessible: "+ce, False

            lines = [l.rstrip() for l in out.splitlines()
                     if l.strip() and not l.strip().startswith("SQL>")
                     and not l.strip().startswith("--")
                     and "ORA-" not in l and "SP2-" not in l]
            errs  = [l for l in out.splitlines() if "ORA-" in l or "SP2-" in l]
            return lines, "\n".join(errs) if errs else "", rc == 0
        except Exception as ex:
            self.log.error("sqlplus wrapper error: {}".format(ex))
            return [], str(ex), False
        finally:
            if tmp:
                try: os.unlink(tmp)
                except: pass


# ── Env detection ─────────────────────────────────────────────────────────────

class Env(object):
    def __init__(self, sid="", standalone=False, log=None):
        self.log         = log or Log()
        self.standalone  = standalone
        self.hostname    = socket.gethostname()
        self.short       = self.hostname.split(".")[0].upper()
        self.os_sys      = platform.system()
        self.os_ver      = self._os_ver()
        self.user        = get_username()
        self.oracle_home = self._find_oracle_home()
        self.oracle_base = os.environ.get("ORACLE_BASE","/u01/app/oracle")
        self.oracle_ver  = self._detect_oracle_version()
        self.sid         = sid or os.environ.get("ORACLE_SID","")
        self.db_name     = (os.environ.get("ORACLE_UNQNAME")
                            or os.environ.get("DB_UNIQUE_NAME") or self.sid)
        if self.oracle_home:
            bp = os.path.join(self.oracle_home,"bin")
            os.environ["PATH"] = bp + os.pathsep + os.environ.get("PATH","")
            os.environ["ORACLE_HOME"] = self.oracle_home
        if self.sid:
            os.environ["ORACLE_SID"] = self.sid

    def _os_ver(self):
        try:
            if platform.system() == "SunOS":
                o,_,_ = run("uname -a",5); return o
            return platform.platform()
        except: return "Unknown"

    def _find_oracle_home(self):
        oh = os.environ.get("ORACLE_HOME","")
        if oh and os.path.isdir(oh): return oh
        # Try oratab
        for oratab in ["/etc/oratab","/var/opt/oracle/oratab"]:
            if os.path.isfile(oratab):
                try:
                    with open(oratab) as fh:
                        for line in fh:
                            line = line.strip()
                            if not line or line.startswith("#"): continue
                            parts = line.split(":")
                            if len(parts) >= 2:
                                h = parts[1].strip()
                                if os.path.isdir(h): return h
                except: pass
        candidates = [
            "/u01/app/oracle/product/19.0.0/dbhome_1",
            "/u01/app/oracle/product/19.3.0/dbhome_1",
            "/u01/app/oracle/product/12.2.0.1/dbhome_1",
            "/opt/oracle/product/19c/dbhome_1",
        ]
        for c in candidates:
            if os.path.isdir(c): return c
        sp = find_bin("sqlplus")
        if sp: return os.path.dirname(os.path.dirname(sp))
        return None

    def _detect_oracle_version(self):
        if self.oracle_home:
            sp = find_bin("sqlplus", self.oracle_home)
            if sp:
                o,_,_ = run("{} -V 2>&1".format(sp), 10)
                m = re.search(r"Release\s+([\d.]+)", o, re.I)
                if m: return m.group(1)
        return os.environ.get("ORACLE_VERSION","unknown")

    def bin(self, name): return find_bin(name, self.oracle_home)


# ── Check functions ───────────────────────────────────────────────────────────

def chk_db_connectivity(env, sql, log):
    """Verify DB is up and connectable."""
    sec = {"section":"db_connectivity","section_status":"UNKNOWN","checks":{}}

    if not sql.available:
        sec["section_status"] = "ERROR"
        sec["checks"]["sqlplus"] = {
            "status":"ERROR",
            "error":"sqlplus not found. Set ORACLE_HOME correctly."
        }
        return sec, False

    # Quick connect test
    lines, err, ok = sql.run_sql("select 'ALIVE|'||instance_name||'|'||status"
                                  "||'|'||database_status from v$instance;", timeout=30)
    if not ok or not lines:
        sec["section_status"] = "CRITICAL"
        sec["checks"]["connection"] = {
            "status":"CRITICAL",
            "error": err or "DB returned no rows — instance may be down",
            "sid": env.sid
        }
        return sec, False

    row = [l for l in lines if "ALIVE|" in l]
    if row:
        parts = row[0].split("|")
        inst_name = parts[1] if len(parts)>1 else env.sid
        inst_st   = parts[2] if len(parts)>2 else "UNKNOWN"
        db_status = parts[3] if len(parts)>3 else "UNKNOWN"
        db_ok     = inst_st == "OPEN" and db_status == "ACTIVE"
        st = "OK" if db_ok else "CRITICAL"
        sec["checks"]["connection"] = {
            "status": st, "instance_name": inst_name,
            "instance_status": inst_st, "database_status": db_status,
            "error": "Instance {} database {}".format(inst_st,db_status) if not db_ok else None
        }
    else:
        sec["checks"]["connection"] = {"status":"WARNING","raw": lines[:3]}

    sec["section_status"] = sec["checks"]["connection"]["status"]
    return sec, sec["section_status"] == "OK"


def chk_database_info(env, sql, log):
    """Collect general DB info: version, role, open_mode, SCN, etc."""
    lines, err, ok = sql.run_sql(
        "select 'INFO|'||name||'|'||db_unique_name||'|'||open_mode"
        "||'|'||log_mode||'|'||database_role||'|'||current_scn"
        " from v$database;", timeout=30)
    info = {"status":"OK" if ok else "WARNING"}
    if ok and lines:
        for l in lines:
            if l.startswith("INFO|"):
                p = l.split("|")
                info.update({
                    "db_name":    p[1] if len(p)>1 else "",
                    "db_unique":  p[2] if len(p)>2 else "",
                    "open_mode":  p[3] if len(p)>3 else "",
                    "log_mode":   p[4] if len(p)>4 else "",
                    "db_role":    p[5] if len(p)>5 else "",
                    "current_scn":p[6] if len(p)>6 else "",
                })
    else:
        info["error"] = err[:300]

    # Oracle version
    vl, ve, vo = sql.run_sql("select version from v$instance;", timeout=20)
    if vo and vl: info["oracle_version"] = vl[0].strip()

    # RAC check
    rl, re2, ro = sql.run_sql(
        "select value from v$parameter where name='cluster_database';", timeout=20)
    info["is_rac"] = (rl and rl[0].strip().lower()=="true") if ro else None

    return info


def chk_tablespaces(env, sql, log):
    sec = {"section":"tablespaces","section_status":"UNKNOWN","checks":{}}
    w = THRESHOLDS["ts_warn_pct"]; c = THRESHOLDS["ts_crit_pct"]

    query = """
select ts.tablespace_name,
       round(ts.total_mb,1),
       round(ts.used_mb,1),
       round(ts.used_pct,1),
       ts.autoextensible,
       ts.status,
       ts.contents
from (
  select f.tablespace_name,
         sum(f.bytes)/1048576 total_mb,
         sum(f.bytes - nvl(ff.free_bytes,0))/1048576 used_mb,
         round((sum(f.bytes - nvl(ff.free_bytes,0))/sum(f.bytes))*100,1) used_pct,
         max(f.autoextensible) autoextensible,
         t.status, t.contents
  from dba_data_files f
  join dba_tablespaces t on t.tablespace_name = f.tablespace_name
  left join (
    select tablespace_name, sum(bytes) free_bytes
    from dba_free_space group by tablespace_name
  ) ff on ff.tablespace_name = f.tablespace_name
  group by f.tablespace_name, t.status, t.contents
  union all
  select tablespace_name, sum(bytes_used+bytes_free)/1048576,
         sum(bytes_used)/1048576,
         round(sum(bytes_used)/(nullif(sum(bytes_used+bytes_free),0))*100,1),
         'N/A', 'ONLINE','TEMPORARY'
  from v$temp_space_header group by tablespace_name
) ts
order by ts.used_pct desc nulls last;
""".strip()

    lines, err, ok = sql.run_sql(query, timeout=60)
    details = []
    if ok:
        for line in lines:
            p = line.split()
            if len(p) < 4: continue
            try:
                name    = p[0]
                total   = float(p[1]) if p[1] not in ("N/A","-") else 0
                used    = float(p[2]) if p[2] not in ("N/A","-") else 0
                pct     = float(p[3]) if p[3] not in ("N/A","-") else 0
                autoext = p[4] if len(p)>4 else "UNKNOWN"
                status  = p[5] if len(p)>5 else "UNKNOWN"
                contents= p[6] if len(p)>6 else ""
                ts_st   = st_pct(pct, w, c)
                if status.upper() != "ONLINE": ts_st = "CRITICAL"
                issue = None
                if ts_st == "CRITICAL":
                    issue = "{} at {}%".format(name, pct)
                    if autoext.upper() == "NO":
                        issue += " — NO autoextend, add datafile immediately"
                elif ts_st == "WARNING":
                    issue = "{} at {}%".format(name, pct)
                    if autoext.upper() == "NO":
                        issue += " — NO autoextend, monitor closely"
                details.append({
                    "name":name,"total_mb":round(total,1),"used_mb":round(used,1),
                    "used_pct":pct,"autoextend":autoext,"status":ts_st,
                    "ts_status":status,"contents":contents,"issue":issue
                })
            except: continue

    ts_sts = [d["status"] for d in details]
    sec["section_status"] = agg(ts_sts) if ts_sts else ("WARNING" if not ok else "OK")
    sec["checks"]["tablespaces"] = {
        "status": sec["section_status"],
        "total": len(details),
        "critical": ts_sts.count("CRITICAL"),
        "warning":  ts_sts.count("WARNING"),
        "ok":       ts_sts.count("OK"),
        "details":  details,
        "error":    err[:400] if not ok else None
    }
    return sec


def chk_recovery_area(env, sql, log):
    sec = {"section":"recovery_area","section_status":"UNKNOWN","checks":{}}
    w = THRESHOLDS["fra_warn_pct"]; c = THRESHOLDS["fra_crit_pct"]

    lines, err, ok = sql.run_sql(
        "select name, space_limit/1073741824, space_used/1073741824,"
        " space_reclaimable/1073741824,"
        " round((space_used-space_reclaimable)/nullif(space_limit,0)*100,1)"
        " from v$recovery_file_dest;", timeout=30)

    fra = {"status":"UNKNOWN","error": err[:300] if not ok else None}
    if ok and lines:
        for line in lines:
            p = line.split()
            if len(p) < 5: continue
            try:
                fra["path"]            = p[0]
                fra["limit_gb"]        = round(float(p[1]),2)
                fra["used_gb"]         = round(float(p[2]),2)
                fra["reclaimable_gb"]  = round(float(p[3]),2)
                fra["used_net_pct"]    = float(p[4])
                # Also compute gross pct
                if fra["limit_gb"] > 0:
                    fra["used_gross_pct"] = round(fra["used_gb"]/fra["limit_gb"]*100,1)
                else:
                    fra["used_gross_pct"] = 0
                fra["status"] = st_pct(fra["used_gross_pct"], w, c)
                if fra["status"] != "OK":
                    fra["issue"] = "FRA at {}% — {} GB used of {} GB. Reclaimable: {} GB".format(
                        fra["used_gross_pct"], fra["used_gb"],
                        fra["limit_gb"], fra["reclaimable_gb"])
            except: pass
    elif not ok:
        fra["status"] = "ERROR"

    # Archivelog generation rate (last hour)
    al_lines, al_err, al_ok = sql.run_sql(
        "select count(*), round(sum(blocks*block_size)/1073741824,2)"
        " from v$archived_log"
        " where first_time > sysdate - 1/24"
        " and dest_id = 1;", timeout=30)
    if al_ok and al_lines:
        p = al_lines[0].split()
        if len(p) >= 2:
            try:
                fra["archivelogs_last_hour"] = int(p[0])
                fra["archivelog_gb_last_hour"] = float(p[1])
                # Project to FRA full time
                if (fra.get("limit_gb",0) > 0 and fra.get("archivelog_gb_last_hour",0) > 0):
                    free_gb = fra["limit_gb"] - fra["used_gb"] + fra.get("reclaimable_gb",0)
                    hrs_to_full = free_gb / fra["archivelog_gb_last_hour"]
                    fra["estimated_hours_to_full"] = round(hrs_to_full, 1)
                    if hrs_to_full < 4 and fra.get("status") != "CRITICAL":
                        fra["status"] = "CRITICAL"
                        fra["issue"]  = (fra.get("issue","") +
                            " | Estimated full in {:.1f}h at current archivelog rate".format(hrs_to_full))
            except: pass

    # Retention
    rp_lines, rp_err, rp_ok = sql.run_sql(
        "select value from v$parameter where name='db_recovery_file_dest_size';", timeout=20)
    ret_lines, ret_err, ret_ok = sql.run_sql(
        "select value from v$parameter2 where name='db_flashback_retention_target'"
        " union select value from v$parameter where name='db_recovery_file_dest';", timeout=20)

    sec["checks"]["fra"] = fra
    sec["section_status"] = fra.get("status","UNKNOWN")
    return sec


def chk_invalid_objects(env, sql, log):
    sec = {"section":"invalid_objects","section_status":"UNKNOWN","checks":{}}

    lines, err, ok = sql.run_sql(
        "select owner, object_name, object_type, last_ddl_time"
        " from dba_objects"
        " where status = 'INVALID'"
        " and owner not in ('SYS','SYSTEM','OUTLN','XDB','CTXSYS','MDSYS',"
        "   'ORDSYS','DBSNMP','WMSYS','EXFSYS','SYSMAN')"
        " order by owner, object_type, object_name;", timeout=60)

    objects = []
    if ok:
        for line in lines:
            p = line.split()
            if len(p) < 3: continue
            owner = p[0]; name = p[1]; otype = p[2]
            dtime = " ".join(p[3:5]) if len(p) >= 5 else ""
            objects.append({"owner":owner,"name":name,"type":otype,"last_ddl":dtime})

    # Attempt recompile count (how many have compile errors)
    err_lines, ee, ek = sql.run_sql(
        "select count(*) from dba_errors where type in "
        "('PACKAGE','PACKAGE BODY','PROCEDURE','FUNCTION','TRIGGER','VIEW');",
        timeout=30)
    compile_errors = 0
    if ek and err_lines:
        try: compile_errors = int(err_lines[0].strip())
        except: pass

    total = len(objects)
    st    = "CRITICAL" if total >= 5 else \
            "WARNING"  if total >= THRESHOLDS["invalid_obj_warn"] else "OK"
    sec["section_status"] = st
    sec["checks"]["invalid_objects"] = {
        "status": st, "total": total,
        "compile_errors": compile_errors,
        "objects": objects[:50],
        "error": err[:300] if not ok else None
    }

    # SYS invalids (usually indicates patching issues)
    sys_lines, se, so = sql.run_sql(
        "select count(*) from dba_objects where status='INVALID'"
        " and owner in ('SYS','SYSTEM');", timeout=30)
    sys_inv = 0
    if so and sys_lines:
        try: sys_inv = int(sys_lines[0].strip())
        except: pass
    if sys_inv > 0:
        sec["checks"]["sys_invalid_objects"] = {
            "status":"WARNING","count":sys_inv,
            "note":"SYS/SYSTEM invalid objects may indicate incomplete patching"
        }
        if sec["section_status"] == "OK":
            sec["section_status"] = "WARNING"

    return sec


def chk_scheduled_jobs(env, sql, log):
    sec = {"section":"scheduled_jobs","section_status":"UNKNOWN","checks":{}}
    sts = []

    # Summary counts
    sum_lines, se, so = sql.run_sql(
        "select state, count(*)"
        " from dba_scheduler_jobs group by state"
        " union all"
        " select 'FAILED_24H', count(*) from dba_scheduler_job_run_details"
        " where status='FAILED' and log_date > sysdate-1"
        " group by 'FAILED_24H';", timeout=60)
    summary = {"RUNNING":0,"SCHEDULED":0,"DISABLED":0,"FAILED_24H":0,"SUCCEEDED":0}
    if so:
        for line in sum_lines:
            p = line.split()
            if len(p) >= 2:
                try: summary[p[0].upper()] = int(p[-1])
                except: pass

    # Failed jobs last 24h
    fail_lines, fe, fo = sql.run_sql(
        "select j.job_name, j.owner, d.log_date, d.error#, d.additional_info"
        " from dba_scheduler_job_run_details d"
        " join dba_scheduler_jobs j on j.job_name=d.job_name and j.owner=d.owner"
        " where d.status='FAILED' and d.log_date > sysdate-1"
        " order by d.log_date desc;"
        , timeout=60)
    failed = []
    if fo:
        for line in fail_lines:
            p = line.split(None, 4)
            if len(p) >= 3:
                failed.append({
                    "job": p[0], "owner": p[1],
                    "last_run": p[2] if len(p)>2 else "",
                    "error_num": p[3] if len(p)>3 else "",
                    "error_info": p[4][:200] if len(p)>4 else ""
                })

    # Long-running jobs
    long_lines, le, lo = sql.run_sql(
        "select j.job_name, j.owner, j.running_instance,"
        " to_char(j.last_start_date,'YYYY-MM-DD HH24:MI:SS'),"
        " round((sysdate - j.last_start_date)*24*60,0) elapsed_min"
        " from dba_scheduler_running_jobs j"
        " order by j.last_start_date;", timeout=60)
    long_running = []
    if lo:
        for line in long_lines:
            p = line.split()
            if len(p) >= 4:
                try:
                    elapsed = float(p[-1]) if p[-1].isdigit() or '.' in p[-1] else 0
                    long_running.append({
                        "job": p[0], "owner": p[1],
                        "node": p[2] if len(p)>2 else "",
                        "started": " ".join(p[3:5]) if len(p)>4 else p[3] if len(p)>3 else "",
                        "elapsed_min": int(elapsed)
                    })
                except: pass

    # DBMS_JOB (legacy jobs) failures
    leg_lines, lge, lgo = sql.run_sql(
        "select job, log_user, last_date, last_sec, failures, broken"
        " from dba_jobs where failures > 0 or broken='Y'"
        " order by failures desc;", timeout=30)
    legacy_failed = []
    if lgo:
        for line in leg_lines:
            p = line.split()
            if len(p)>=3:
                legacy_failed.append({
                    "job":p[0],"owner":p[1],"last_run": p[2] if len(p)>2 else "",
                    "failures": p[4] if len(p)>4 else "?",
                    "broken": p[5] if len(p)>5 else "?"
                })

    any_fail = len(failed) > 0 or len(legacy_failed) > 0
    st = "CRITICAL" if len(failed) >= 3 else \
         "WARNING"  if any_fail else "OK"
    sts.append(st)
    sec["checks"]["scheduler_jobs"] = {
        "status": st,
        "summary": summary,
        "failed_last_24h": failed[:20],
        "long_running": long_running[:10],
        "legacy_job_failures": legacy_failed[:10],
        "error": fe[:200] if not fo else None
    }

    sec["section_status"] = agg(sts)
    return sec


def chk_rman_backup(env, sql, log):
    sec = {"section":"rman_backup","section_status":"UNKNOWN","checks":{}}
    sts = []

    # Last full backup
    full_lines, fe, fo = sql.run_sql(
        "select bs.start_time, bs.completion_time,"
        " bs.elapsed_seconds/60, bs.status,"
        " bs.input_bytes/1073741824, bs.output_bytes/1073741824,"
        " bs.compression_ratio, bsr.keep"
        " from v$backup_set_details bs"
        " join v$backup_set bsr on bsr.set_stamp=bs.set_stamp and bsr.set_count=bs.set_count"
        " where bs.backup_type='D' and bs.incremental_level is null"
        " and bs.start_time = (select max(b2.start_time)"
        "   from v$backup_set_details b2 where b2.backup_type='D'"
        "   and b2.incremental_level is null)"
        " and rownum=1;", timeout=60)

    full = {"status":"UNKNOWN","error": fe[:300] if not fo else None}
    if fo and full_lines:
        p = full_lines[0].split()
        try:
            start  = " ".join(p[0:2]) if len(p)>=2 else p[0]
            end    = " ".join(p[2:4]) if len(p)>=4 else ""
            dur    = float(p[4]) if len(p)>4 else 0
            bst    = p[5]        if len(p)>5 else "UNKNOWN"
            inp    = float(p[6]) if len(p)>6 else 0
            outp   = float(p[7]) if len(p)>7 else 0
            ratio  = float(p[8]) if len(p)>8 else 0
            full   = {
                "status":     "OK" if bst.upper() in ("COMPLETED","COMPLETED WITH WARNINGS") else "CRITICAL",
                "backup_status": bst,
                "started":    start, "completed": end,
                "duration_min": round(dur,1),
                "input_gb":   round(inp,2), "output_gb": round(outp,2),
                "compression_ratio": round(ratio,2) if ratio else None,
                "issue": "Last full backup status: {}".format(bst) if bst.upper()!="COMPLETED" else None
            }
            # Check age
            age_lines, ae, ao = sql.run_sql(
                "select round((sysdate-max(start_time))*24,1) hours_ago"
                " from v$backup_set_details"
                " where backup_type='D' and incremental_level is null;", timeout=30)
            if ao and age_lines:
                try:
                    age_h = float(age_lines[0].strip())
                    full["age_hours"] = age_h
                    age_days = age_h / 24.0
                    if age_days >= THRESHOLDS["rman_full_warn_days"]:
                        full["status"] = "CRITICAL"
                        full["issue"] = "Full backup {} days old (threshold {} days)".format(
                            round(age_days,1), THRESHOLDS["rman_full_warn_days"])
                except: pass
        except Exception as ex:
            full["parse_error"] = str(ex)

    sts.append(full.get("status","UNKNOWN"))
    sec["checks"]["full_backup"] = full

    # Last incremental backup
    incr_lines, ie, io = sql.run_sql(
        "select bs.start_time, bs.completion_time, bs.elapsed_seconds/60,"
        " bs.status, bs.input_bytes/1073741824, bs.output_bytes/1073741824,"
        " bs.incremental_level"
        " from v$backup_set_details bs"
        " where bs.backup_type='D' and bs.incremental_level > 0"
        " and bs.start_time = (select max(b2.start_time)"
        "   from v$backup_set_details b2"
        "   where b2.backup_type='D' and b2.incremental_level > 0)"
        " and rownum=1;", timeout=60)

    incr = {"status":"UNKNOWN","error": ie[:300] if not io else None}
    if io and incr_lines:
        p = incr_lines[0].split()
        try:
            start  = " ".join(p[0:2]) if len(p)>=2 else p[0]
            end    = " ".join(p[2:4]) if len(p)>=4 else ""
            dur    = float(p[4]) if len(p)>4 else 0
            bst    = p[5]        if len(p)>5 else "UNKNOWN"
            inp    = float(p[6]) if len(p)>6 else 0
            lvl    = p[8]        if len(p)>8 else "1"
            incr   = {
                "status": "OK" if bst.upper() in ("COMPLETED","COMPLETED WITH WARNINGS") else "CRITICAL",
                "backup_status": bst, "level": lvl,
                "started": start, "completed": end,
                "duration_min": round(dur,1), "input_gb": round(inp,2),
                "issue": "Incremental backup status: {}".format(bst) if bst.upper()!="COMPLETED" else None
            }
            age2_l, a2e, a2o = sql.run_sql(
                "select round((sysdate-max(start_time))*24,1)"
                " from v$backup_set_details"
                " where backup_type='D' and incremental_level > 0;", timeout=30)
            if a2o and age2_l:
                try:
                    age_h = float(age2_l[0].strip())
                    incr["age_hours"] = age_h
                    if age_h > THRESHOLDS["rman_age_warn_hours"]:
                        incr["status"] = "WARNING"
                        incr["issue"]  = "No incremental backup for {:.0f}h".format(age_h)
                except: pass
        except Exception as ex:
            incr["parse_error"] = str(ex)

    sts.append(incr.get("status","UNKNOWN"))
    sec["checks"]["incremental_backup"] = incr

    # Archivelog backup
    arch_lines, ache, acho = sql.run_sql(
        "select count(*), round(sum(blocks*block_size)/1073741824,2)"
        " from v$backup_piece bp"
        " join v$backup_set bs on bs.set_stamp=bp.set_stamp"
        " where bs.backup_type='L' and bp.completion_time > sysdate-1"
        " and bp.status='A';", timeout=60)
    arch = {"status":"UNKNOWN"}
    if acho and arch_lines:
        p = arch_lines[0].split()
        if len(p)>=2:
            try:
                arch_cnt = int(p[0]); arch_gb = float(p[1])
                arch_ok  = arch_cnt > 0
                arch = {
                    "status": "OK" if arch_ok else "WARNING",
                    "pieces_last_24h": arch_cnt,
                    "size_gb": arch_gb,
                    "issue": "No archivelog backup in last 24h" if not arch_ok else None
                }
            except: arch["parse_error"] = arch_lines[0]
    sts.append(arch.get("status","UNKNOWN"))
    sec["checks"]["archivelog_backup"] = arch

    # Archive log gaps
    gap_lines, ge, go = sql.run_sql(
        "select count(*) from v$archive_gap;", timeout=20)
    gaps = 0
    if go and gap_lines:
        try: gaps = int(gap_lines[0].strip())
        except: pass
    sec["checks"]["archive_gaps"] = {
        "status":"CRITICAL" if gaps>0 else "OK",
        "gaps": gaps,
        "issue": "{} archive log gap(s) detected".format(gaps) if gaps>0 else None
    }
    sts.append(sec["checks"]["archive_gaps"]["status"])

    # Failed RMAN jobs
    rman_fail_lines, rfe, rfo = sql.run_sql(
        "select count(*) from v$rman_backup_job_details"
        " where status not in ('COMPLETED','COMPLETED WITH WARNINGS')"
        " and start_time > sysdate-7;", timeout=30)
    rman_fails = 0
    if rfo and rman_fail_lines:
        try: rman_fails = int(rman_fail_lines[0].strip())
        except: pass
    if rman_fails > 0 and agg(sts) == "OK":
        sts.append("WARNING")
    sec["checks"]["rman_failures_7d"] = {
        "status": "WARNING" if rman_fails>0 else "OK",
        "failed_jobs": rman_fails
    }

    sec["section_status"] = agg(sts)
    return sec


def chk_datapump(env, sql, log):
    sec = {"section":"datapump_exports","section_status":"UNKNOWN","checks":{}}

    lines, err, ok = sql.run_sql(
        "select j.owner_name, j.job_name, j.operation, j.job_mode,"
        " j.state, to_char(j.start_time,'YYYY-MM-DD HH24:MI:SS'),"
        " to_char(j.end_time,'YYYY-MM-DD HH24:MI:SS'),"
        " j.degree, j.error_count"
        " from dba_datapump_jobs j"
        " where j.start_time > sysdate-7"
        " order by j.start_time desc;", timeout=60)

    jobs = []
    if ok:
        for line in lines:
            p = line.split(None, 8)
            if len(p) >= 5:
                jobs.append({
                    "owner": p[0], "job_name": p[1],
                    "operation": p[2], "mode": p[3],
                    "state": p[4],
                    "start_time": p[5] if len(p)>5 else "",
                    "end_time": p[6] if len(p)>6 else "",
                    "degree": p[7] if len(p)>7 else "",
                    "errors": int(p[8]) if len(p)>8 and p[8].strip().isdigit() else 0
                })

    failed  = [j for j in jobs if j.get("errors",0)>0 or "FAILED" in j.get("state","").upper()]
    running = [j for j in jobs if j.get("state","").upper() == "EXECUTING"]
    st = "WARNING" if failed else ("OK" if ok else "WARNING")
    sec["section_status"] = st
    sec["checks"]["datapump_jobs"] = {
        "status": st,
        "total_7d": len(jobs),
        "running": len(running),
        "failed":  len(failed),
        "jobs": jobs[:20],
        "error": err[:300] if not ok else None
    }
    return sec


def chk_goldengate(env, sql, log):
    sec = {"section":"goldengate","section_status":"UNKNOWN","checks":{}}

    # Check if GoldenGate home is configured
    gg_home = os.environ.get("GG_HOME") or os.environ.get("OGG_HOME","")
    if not gg_home:
        for p in ["/u01/app/oracle/goldengate",
                  "/u01/app/goldengate/product/21c",
                  "/opt/goldengate"]:
            if os.path.isdir(p): gg_home = p; break

    if not gg_home:
        sec["section_status"] = "N/A"
        sec["note"] = "GoldenGate home not found. Set GG_HOME env or install GoldenGate."
        return sec

    ggsci = find_bin("ggsci", gg_home)
    if not ggsci:
        ggsci = os.path.join(gg_home, "ggsci")
        if not (os.path.isfile(ggsci) and os.access(ggsci, os.X_OK)):
            ggsci = None

    if not ggsci:
        sec["section_status"] = "WARNING"
        sec["checks"]["error"] = "ggsci not found in {}".format(gg_home)
        return sec

    sts = []

    # Manager status
    mg_out, mg_err, mg_rc = run(
        "echo 'info mgr' | {} 2>&1".format(ggsci), 20)
    mgr_running = "running" in mg_out.lower() or "started" in mg_out.lower()
    mgr_port = None
    mp = re.search(r"port\s+(\d+)", mg_out, re.I)
    if mp: mgr_port = int(mp.group(1))
    mgr_st = "OK" if mgr_running else "CRITICAL"
    sts.append(mgr_st)
    sec["checks"]["manager"] = {
        "status": mgr_st, "running": mgr_running,
        "port": mgr_port, "raw": mg_out[:300],
        "error": mg_err[:200] if not mgr_running else None
    }

    # All processes status
    proc_out, pe, pr = run(
        "echo 'info all' | {} 2>&1".format(ggsci), 30)
    processes = []
    for line in proc_out.splitlines():
        # GGSCI output: EXTRACT  EXT_FIN01  RUNNING  000:00:00  00:00:00  000-00-00
        m = re.match(
            r"\s*(EXTRACT|REPLICAT|DATAPUMP)\s+(\S+)\s+(RUNNING|STOPPED|ABENDED|STARTING|RECOVERING)\s*(.*)$",
            line, re.I)
        if m:
            ptype = m.group(1).upper()
            pname = m.group(2).upper()
            pst   = m.group(3).upper()
            rest  = m.group(4).strip()
            # Parse lag: format HH:MM:SS
            lag_sec = None
            lag_m = re.search(r"(\d+):(\d+):(\d+)", rest)
            if lag_m:
                lag_sec = int(lag_m.group(1))*3600 + int(lag_m.group(2))*60 + int(lag_m.group(3))

            proc_status = "OK" if pst=="RUNNING" else \
                          "CRITICAL" if pst in ("ABENDED","STOPPED") else "WARNING"

            w_lag = THRESHOLDS["gg_lag_warn_sec"]
            c_lag = THRESHOLDS["gg_lag_crit_sec"]
            if lag_sec is not None and pst=="RUNNING":
                if lag_sec >= c_lag:
                    proc_status = "CRITICAL"
                elif lag_sec >= w_lag and proc_status == "OK":
                    proc_status = "WARNING"

            issue = None
            if pst == "ABENDED":
                issue = "{} ABENDED — check ggserr.log".format(pname)
            elif pst == "STOPPED":
                issue = "{} is STOPPED".format(pname)
            elif lag_sec and lag_sec >= w_lag:
                issue = "{} lag {}s exceeds threshold {}s".format(pname, lag_sec, w_lag)

            processes.append({
                "name": pname, "type": ptype, "status": pst,
                "health": proc_status,
                "lag_sec": lag_sec, "issue": issue
            })

    proc_sts = [p["health"] for p in processes]
    proc_agg = agg(proc_sts) if proc_sts else "OK"
    sts.append(proc_agg)
    sec["checks"]["processes"] = {
        "status": proc_agg,
        "total": len(processes),
        "running": len([p for p in processes if p["status"]=="RUNNING"]),
        "abended": len([p for p in processes if p["status"]=="ABENDED"]),
        "stopped": len([p for p in processes if p["status"]=="STOPPED"]),
        "processes": processes
    }

    # Lag summary via SQL (if GG tables exist)
    lag_lines, le, lo = sql.run_sql(
        "select count(*) from dba_objects where object_name like 'GG%'"
        " and object_type='TABLE' and rownum=1;", timeout=10)

    sec["section_status"] = agg(sts)
    return sec


def chk_alert_log(env, sql, log):
    sec = {"section":"alert_log","section_status":"UNKNOWN","checks":{}}
    sts = []
    hours = THRESHOLDS["alert_log_hours"]

    # Get alert log path from DB
    adr_lines, ae, ao = sql.run_sql(
        "select value from v$parameter where name='background_dump_dest'"
        " union select value from v$diag_info where name='Diag Trace'"
        " and rownum=1;", timeout=30)
    adr_path = ""
    if ao and adr_lines:
        adr_path = adr_lines[0].strip()

    # Find alert log file
    alert_log = ""
    if adr_path:
        for fname in ["alert_{}.log".format(env.sid),
                      "alert_{}.log".format(env.sid.lower()),
                      "alert.log"]:
            candidate = os.path.join(adr_path, fname)
            if os.path.isfile(candidate):
                alert_log = candidate
                break

    if not alert_log and env.oracle_base:
        # Try standard ADR path
        diag_base = os.path.join(env.oracle_base, "diag", "rdbms")
        if os.path.isdir(diag_base):
            try:
                for dbdir in os.listdir(diag_base):
                    idir = os.path.join(diag_base, dbdir, env.sid.lower(), "trace")
                    candidate = os.path.join(idir, "alert_{}.log".format(env.sid.lower()))
                    if os.path.isfile(candidate):
                        alert_log = candidate
                        break
            except: pass

    if not alert_log:
        sec["section_status"] = "WARNING"
        sec["checks"]["error"] = {
            "status": "WARNING",
            "note": "Alert log not found. Checked: adr_path={}, oracle_base={}".format(
                adr_path, env.oracle_base)
        }
        # Fallback: use v$diag_alert_ext if available
        return _chk_alert_log_via_sql(env, sql, log, sec, sts, hours)

    # Parse alert log for last N hours
    return _parse_alert_log_file(alert_log, env, sec, sts, hours, log)


def _parse_alert_log_file(alert_log, env, sec, sts, hours, log):
    """Parse alert log from file."""
    cutoff = datetime.datetime.now() - datetime.timedelta(hours=hours)
    errors   = {"ORA-600":[],"ORA-7445":[],"ORA-1578":[],"ORA-4031":[],"ORA-1650":[],"OTHER":[]}
    warnings = []
    infos    = []
    log_switches   = 0
    chkpt_not_complete = False

    err_counts = {k:0 for k in errors}
    total_errors = 0

    try:
        # Read last 50000 lines of alert log to avoid huge reads
        # Use tail equivalent
        out, _, _ = run("tail -50000 {} 2>/dev/null".format(alert_log), 30)
        lines = out.splitlines()

        current_ts = None
        ts_pattern = re.compile(
            r"^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+\w+\s+\d+\s+\d+:\d+:\d+\s+\d{4}|"
            r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}"
        )

        for line in lines:
            # Track timestamp
            if ts_pattern.match(line):
                try:
                    # Try ISO format first
                    m = re.match(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})", line)
                    if m:
                        current_ts = datetime.datetime.strptime(m.group(1),"%Y-%m-%dT%H:%M:%S")
                    else:
                        # Classic Oracle format: Wed Mar 11 06:00:00 2026
                        current_ts = datetime.datetime.strptime(
                            re.sub(r"\s+"," ",line.strip()), "%a %b %d %H:%M:%S %Y")
                except: pass
                continue

            if current_ts and current_ts < cutoff:
                continue

            # Check for errors
            if "ORA-" in line:
                total_errors += 1
                found_key = None
                for key in ["ORA-00600","ORA-07445","ORA-01578","ORA-04031","ORA-01650"]:
                    if key.replace("ORA-0","ORA-").replace("-0","-") in line or key in line:
                        short = key.replace("-0","-").replace("ORA-00","ORA-").replace("ORA-0","ORA-")
                        # normalize
                        for k in list(errors.keys()):
                            if k in line.replace("ORA-0","ORA-"):
                                err_counts[k] = err_counts.get(k,0)+1
                                if len(errors[k]) < 5:
                                    errors[k].append({
                                        "timestamp": str(current_ts) if current_ts else "unknown",
                                        "message": line.strip()[:300]
                                    })
                                found_key = k
                                break
                        break
                if not found_key and len(errors["OTHER"]) < 10:
                    errors["OTHER"].append({
                        "timestamp": str(current_ts) if current_ts else "unknown",
                        "message": line.strip()[:200]
                    })
                    err_counts["OTHER"] = err_counts.get("OTHER",0)+1

            if "checkpoint not complete" in line.lower():
                chkpt_not_complete = True
                warnings.append({"timestamp": str(current_ts),"message": line.strip()})

            if re.search(r"log file switch|thread \d+ advanced", line, re.I):
                log_switches += 1

            if "WARNING" in line.upper() or "ERROR" in line.upper():
                if len(warnings) < 20 and "ORA-" not in line:
                    warnings.append({"timestamp": str(current_ts),"message": line.strip()[:200]})

    except Exception as ex:
        sec["checks"]["parse_error"] = str(ex)
        sec["section_status"] = "WARNING"
        return sec

    # Determine log switch rate
    ls_rate = round(log_switches / max(hours, 1), 1)
    ls_warn = 12; ls_crit = 20

    # Determine section status
    has_600   = err_counts.get("ORA-600",0) > 0
    has_7445  = err_counts.get("ORA-7445",0) > 0
    has_1578  = err_counts.get("ORA-1578",0) > 0
    ls_high   = ls_rate >= ls_crit
    ls_warn_f = ls_rate >= ls_warn

    if has_600 or has_7445 or has_1578 or chkpt_not_complete:
        al_st = "CRITICAL"
    elif err_counts.get("ORA-4031",0) > 0 or err_counts.get("ORA-1650",0) > 0 or ls_high:
        al_st = "CRITICAL"
    elif total_errors > 0 or ls_warn_f:
        al_st = "WARNING"
    else:
        al_st = "OK"

    sts.append(al_st)
    sec["checks"]["alert_log"] = {
        "status": al_st,
        "log_path": alert_log,
        "hours_scanned": hours,
        "total_ora_errors": total_errors,
        "error_counts": err_counts,
        "critical_errors": errors["ORA-600"] + errors["ORA-7445"] + errors["ORA-1578"],
        "warning_errors":  errors["ORA-4031"] + errors["ORA-1650"],
        "other_errors":    errors["OTHER"][:10],
        "warnings":        warnings[:10],
        "log_switches":    log_switches,
        "log_switch_rate_per_hour": ls_rate,
        "log_switch_threshold": ls_warn,
        "checkpoint_not_complete": chkpt_not_complete,
        "issue": _alert_log_issue_msg(has_600, has_7445, has_1578,
                                       err_counts, chkpt_not_complete, ls_rate, ls_warn)
    }
    sec["section_status"] = agg(sts)
    return sec


def _alert_log_issue_msg(c600, c7445, c1578, cnts, chkpt, ls_rate, ls_warn):
    msgs = []
    if c600:   msgs.append("ORA-600 detected!")
    if c7445:  msgs.append("ORA-7445 detected!")
    if c1578:  msgs.append("ORA-1578 (block corruption) detected!")
    if chkpt:  msgs.append("Checkpoint not complete!")
    if cnts.get("ORA-4031",0)>0: msgs.append("{} ORA-4031 (shared pool)".format(cnts["ORA-4031"]))
    if cnts.get("ORA-1650",0)>0: msgs.append("{} ORA-1650 (undo ext)".format(cnts["ORA-1650"]))
    if ls_rate >= ls_warn: msgs.append("Log switch rate {}/hr > threshold {}/hr".format(ls_rate, ls_warn))
    return " | ".join(msgs) if msgs else None


def _chk_alert_log_via_sql(env, sql, log, sec, sts, hours):
    """Fallback: query alert log via v$diag_alert_ext (12c+)."""
    lines, err, ok = sql.run_sql(
        "select count(*), originating_timestamp, problem_key, message_text"
        " from v$diag_alert_ext"
        " where originating_timestamp > systimestamp - interval '{}' hour".format(hours)+
        " and message_level <= 2"
        " group by originating_timestamp, problem_key, message_text"
        " order by originating_timestamp desc;"
        , timeout=60)
    if ok and lines:
        errors = [l for l in lines if "ORA-" in l or "CRITICAL" in l.upper()]
        st = "CRITICAL" if any("ORA-600" in l or "ORA-7445" in l for l in errors) else \
             "WARNING"  if errors else "OK"
        sts.append(st)
        sec["checks"]["alert_log_sql"] = {
            "status": st, "source": "v$diag_alert_ext",
            "critical_errors": [l[:200] for l in errors[:10]]
        }
    else:
        sec["checks"]["alert_log_sql"] = {
            "status":"WARNING","source":"v$diag_alert_ext",
            "note":"Could not query alert log via SQL (may be 11g or view unavailable)"
        }
        sts.append("WARNING")

    sec["section_status"] = agg(sts)
    return sec


def chk_sessions_locks(env, sql, log):
    sec = {"section":"sessions_locks","section_status":"UNKNOWN","checks":{}}
    sts = []

    # Session counts vs limit
    sess_lines, se, so = sql.run_sql(
        "select current_utilization, max_utilization, limit_value"
        " from v$resource_limit where resource_name='sessions';", timeout=20)
    if so and sess_lines:
        p = sess_lines[0].split()
        if len(p) >= 3:
            try:
                cur = int(p[0]); maxu = int(p[1]); lim = int(p[2])
                pct = round(cur*100.0/lim,1) if lim > 0 else 0
                st  = st_pct(pct, THRESHOLDS["session_warn_pct"], THRESHOLDS["session_crit_pct"])
                sts.append(st)
                sec["checks"]["sessions"] = {
                    "status":st,"current":cur,"max_ever":maxu,"limit":lim,"used_pct":pct,
                    "issue":"Session count at {}% of limit".format(pct) if st!="OK" else None
                }
            except: pass

    # Blocking locks
    lock_lines, le, lo = sql.run_sql(
        "select waiter.sid, waiter.serial#, waiter.username,"
        " blocker.sid, blocker.username,"
        " round(waiter.seconds_in_wait/60,1) wait_min"
        " from v$session waiter, v$session blocker"
        " where waiter.blocking_session = blocker.sid"
        " and waiter.blocking_session_status = 'VALID'"
        " order by wait_min desc;", timeout=30)
    locks = []
    if lo:
        for line in lock_lines:
            p = line.split()
            if len(p)>=6:
                try:
                    wait_m = float(p[-1])
                    locks.append({
                        "waiter_sid":p[0],"waiter_user":p[2],
                        "blocker_sid":p[3],"blocker_user":p[4],
                        "wait_minutes": wait_m
                    })
                except: pass
    long_locks = [l for l in locks if l.get("wait_minutes",0) > 5]
    lock_st = "CRITICAL" if long_locks else ("WARNING" if locks else "OK")
    sts.append(lock_st)
    sec["checks"]["blocking_locks"] = {
        "status":lock_st,"total_blockers":len(locks),
        "long_waits_5min":len(long_locks),"details":locks[:10]
    }

    # Long-running queries (> 30 min)
    lq_lines, lqe, lqo = sql.run_sql(
        "select sid, username, round(elapsed_time/1000000/60,1) elapsed_min,"
        " round(cpu_time/1000000/60,1) cpu_min,"
        " substr(sql_text,1,80) sql_snippet"
        " from v$session s join v$sqlarea q on q.sql_id=s.sql_id"
        " where s.status='ACTIVE' and s.type='USER'"
        " and s.elapsed_time/1000000/60 > 30"
        " order by elapsed_min desc;", timeout=30)
    lq = []
    if lqo:
        for line in lq_lines:
            p = line.split(None, 4)
            if len(p)>=4:
                lq.append({"sid":p[0],"user":p[1],
                           "elapsed_min":p[2],"cpu_min":p[3],
                           "sql":p[4][:80] if len(p)>4 else ""})
    lq_st = "WARNING" if len(lq) >= 3 else "OK"
    sts.append(lq_st)
    sec["checks"]["long_running_queries"] = {
        "status":lq_st,"count":len(lq),"queries":lq[:10]
    }

    sec["section_status"] = agg(sts)
    return sec


def chk_redo_logs(env, sql, log):
    sec = {"section":"redo_logs","section_status":"UNKNOWN","checks":{}}
    sts = []

    # Redo log status
    rl_lines, re2, ro = sql.run_sql(
        "select group#, thread#, members, status, round(bytes/1048576,0) mb"
        " from v$log order by thread#, group#;", timeout=30)
    redo_groups = []
    if ro:
        for line in rl_lines:
            p = line.split()
            if len(p)>=5:
                redo_groups.append({
                    "group":p[0],"thread":p[1],"members":p[2],
                    "status":p[3],"size_mb":p[4]
                })
    inactive = [r for r in redo_groups if r.get("status") in ("INVALID","UNUSED")]
    rl_st = "WARNING" if inactive else ("OK" if redo_groups else "WARNING")
    sts.append(rl_st)
    sec["checks"]["redo_groups"] = {
        "status":rl_st,"groups":len(redo_groups),
        "details":redo_groups,"issues":inactive
    }

    # Redo log members (multiplexing)
    min_members = min([int(r.get("members",1)) for r in redo_groups]) if redo_groups else 0
    if min_members < 2:
        sec["checks"]["multiplexing"] = {
            "status":"WARNING",
            "note":"Some redo log groups have less than 2 members — add multiplexing"
        }
        sts.append("WARNING")
    else:
        sec["checks"]["multiplexing"] = {
            "status":"OK","min_members":min_members
        }

    sec["section_status"] = agg(sts)
    return sec


def chk_performance(env, sql, log):
    """Collect basic performance metrics: wait events, SGA usage, PGA."""
    sec = {"section":"performance","section_status":"UNKNOWN","checks":{}}
    sts = []

    # Top wait events (last snapshot - dynamic)
    wait_lines, we, wo = sql.run_sql(
        "select event, total_waits, round(time_waited/100,1) secs"
        " from v$system_event"
        " where event not like 'SQL*Net%' and event not like '%idle%'"
        " and event not like 'Streams AQ%' and event not in ('pipe get','pmon timer','rdbms ipc message')"
        " order by time_waited desc fetch first 10 rows only;", timeout=30)
    if not wo:  # fallback for older Oracle
        wait_lines, we, wo = sql.run_sql(
            "select event, total_waits, round(time_waited/100,1) secs"
            " from v$system_event"
            " where event not like 'SQL*Net%' and event not like '%idle%'"
            " order by time_waited desc;"
            , timeout=30)

    waits = []
    if wo:
        for line in wait_lines[:10]:
            p = line.rsplit(None, 2)
            if len(p)>=3:
                waits.append({"event":p[0],"waits":p[1],"seconds":p[2]})
    sec["checks"]["top_wait_events"] = {"status":"OK","events":waits}

    # SGA usage
    sga_lines, sge, sgo = sql.run_sql(
        "select pool, round(sum(bytes)/1073741824,2) gb"
        " from v$sgastat group by pool;", timeout=20)
    sga = {}
    if sgo:
        for line in sga_lines:
            p = line.split()
            if len(p)>=2:
                try: sga[p[0]] = float(p[-1])
                except: pass
    sec["checks"]["sga"] = {"status":"OK","pools_gb":sga}

    # PGA
    pga_lines, pge, pgo = sql.run_sql(
        "select name, round(value/1073741824,2)"
        " from v$pgastat"
        " where name in ('total PGA inuse','total PGA allocated','cache hit percentage');",
        timeout=20)
    pga = {}
    if pgo:
        for line in pga_lines:
            p = line.rsplit(None, 1)
            if len(p)==2:
                try: pga[p[0].strip()] = float(p[1])
                except: pass
    pga_hit = pga.get("cache hit percentage",100)
    pga_st  = "WARNING" if pga_hit < 80 else "OK"
    sts.append(pga_st)
    sec["checks"]["pga"] = {
        "status":pga_st,"stats":pga,
        "issue":"PGA cache hit {}% < 80%".format(pga_hit) if pga_hit < 80 else None
    }

    # AWR/statspack availability
    awr_lines, ae, ao = sql.run_sql(
        "select count(*) from dba_hist_snapshot where snap_id = (select max(snap_id) from dba_hist_snapshot);",
        timeout=20)
    if ao and awr_lines:
        try:
            cnt = int(awr_lines[0].strip())
            sec["checks"]["awr"] = {"status":"OK","latest_snapshots_rows":cnt}
        except: pass

    sec["section_status"] = agg(sts) if sts else "OK"
    return sec


def chk_rac_specific(env, sql, log):
    """RAC-specific checks: instance status, GCS/GES activity."""
    sec = {"section":"rac_checks","section_status":"UNKNOWN","checks":{}}
    if env.standalone:
        sec["section_status"] = "N/A"
        sec["note"] = "Standalone mode"
        return sec
    sts = []

    # All instance status from gv$instance
    inst_lines, ie, io = sql.run_sql(
        "select inst_id, instance_name, status, database_status,"
        " active_state, archiver, thread#"
        " from gv$instance order by inst_id;", timeout=30)
    instances = []
    if io:
        for line in inst_lines:
            p = line.split()
            if len(p)>=5:
                st = "OK" if p[2]=="OPEN" and p[3]=="ACTIVE" else "CRITICAL"
                instances.append({
                    "inst_id":p[0],"name":p[1],"status":p[2],
                    "db_status":p[3],"active_state":p[4] if len(p)>4 else "",
                    "archiver":p[5] if len(p)>5 else "","thread":p[6] if len(p)>6 else "",
                    "health": st
                })
    inst_sts = [i["health"] for i in instances]
    inst_agg = agg(inst_sts) if inst_sts else "WARNING"
    sts.append(inst_agg)
    sec["checks"]["instances"] = {
        "status":inst_agg,"count":len(instances),"instances":instances,
        "error": ie[:200] if not io else None
    }

    # GCS (Global Cache Service) stats
    gcs_lines, ge, go = sql.run_sql(
        "select name, round(value/1000,0) k_val"
        " from v$sysstat"
        " where name in ('gc cr blocks received','gc current blocks received',"
        "  'gc cr block build time','gc current block pin time')"
        " order by name;", timeout=20)
    gcs = {}
    if go:
        for line in gcs_lines:
            p = line.rsplit(None,1)
            if len(p)==2:
                try: gcs[p[0].strip()] = int(p[1])
                except: pass
    sec["checks"]["global_cache"] = {"status":"OK","stats":gcs}

    # Archive log dest status
    arch_lines, arde, ardo = sql.run_sql(
        "select dest_id, status, target, archiver, schedule, destination"
        " from v$archive_dest where status!='INACTIVE' and target='PRIMARY'"
        " order by dest_id;", timeout=20)
    arch_dests = []
    if ardo:
        for line in arch_lines:
            p = line.split(None, 5)
            if len(p)>=3:
                arch_dests.append({
                    "dest_id":p[0],"status":p[1],"target":p[2],
                    "destination":p[5] if len(p)>5 else ""
                })
    failed_dests = [a for a in arch_dests if a.get("status")!="VALID"]
    arch_st = "CRITICAL" if failed_dests else ("OK" if arch_dests else "WARNING")
    sts.append(arch_st)
    sec["checks"]["archive_destinations"] = {
        "status":arch_st,"destinations":arch_dests,"failed":failed_dests
    }

    sec["section_status"] = agg(sts)
    return sec


# ── main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Oracle RAC DB Health Check (oracle user)")
    ap.add_argument("--output",     default="/tmp",     help="Output directory")
    ap.add_argument("--sid",        default="",         help="ORACLE_SID")
    ap.add_argument("--db-name",    default="",         help="DB unique name")
    ap.add_argument("--standalone", action="store_true",help="Standalone DB mode")
    ap.add_argument("--debug",      action="store_true",help="Verbose debug")
    ap.add_argument("--skip-gg",    action="store_true",help="Skip GoldenGate checks")
    ap.add_argument("--skip-perf",  action="store_true",help="Skip performance checks")
    args = ap.parse_args()

    log = Log(debug=args.debug)
    env = Env(sid=args.sid, standalone=args.standalone, log=log)

    if args.db_name:
        env.db_name = args.db_name
        for k in ("ORACLE_UNQNAME","DB_UNIQUE_NAME"):
            os.environ[k] = args.db_name

    log.info("=== ORACLE DB health check START | {} | SID={} | user={} ===".format(
        env.hostname, env.sid, env.user))

    if not env.oracle_home:
        log.error("ORACLE_HOME not found. Set ORACLE_HOME env var or check /etc/oratab.")
        sys.exit(2)

    sql = SQLPlus(env.oracle_home, env.sid, log)

    # First check DB connectivity
    conn_sec, db_ok = chk_db_connectivity(env, sql, log)

    sections_to_run = []
    if db_ok:
        db_info = chk_database_info(env, sql, log)
        sections_to_run = [
            ("tablespaces",       lambda: chk_tablespaces(env, sql, log)),
            ("recovery_area",     lambda: chk_recovery_area(env, sql, log)),
            ("invalid_objects",   lambda: chk_invalid_objects(env, sql, log)),
            ("scheduled_jobs",    lambda: chk_scheduled_jobs(env, sql, log)),
            ("rman_backup",       lambda: chk_rman_backup(env, sql, log)),
            ("datapump_exports",  lambda: chk_datapump(env, sql, log)),
            ("sessions_locks",    lambda: chk_sessions_locks(env, sql, log)),
            ("redo_logs",         lambda: chk_redo_logs(env, sql, log)),
            ("alert_log",         lambda: chk_alert_log(env, sql, log)),
            ("rac_checks",        lambda: chk_rac_specific(env, sql, log)),
        ]
        if not args.skip_gg:
            sections_to_run.append(("goldengate", lambda: chk_goldengate(env, sql, log)))
        if not args.skip_perf:
            sections_to_run.append(("performance", lambda: chk_performance(env, sql, log)))
    else:
        log.warn("DB connection failed — skipping all SQL checks")
        db_info = {}

    result    = {}
    all_sts   = [conn_sec.get("section_status","UNKNOWN")]
    errs      = []
    cnts      = {"CRITICAL":0,"WARNING":0,"OK":0,"ERROR":0,"N/A":0}

    result["db_connectivity"] = conn_sec
    for k, v in cnts.items():
        cnts[conn_sec.get("section_status","UNKNOWN")] = cnts.get(conn_sec.get("section_status","UNKNOWN"),0)+1

    for key, fn in sections_to_run:
        try:
            log.info("Checking: {}".format(key))
            data = fn()
            result[key] = data
            st = data.get("section_status","UNKNOWN")
            all_sts.append(st)
            cnts[st] = cnts.get(st,0)+1
        except Exception as ex:
            tb = traceback.format_exc()
            log.error("Section '{}' failed: {}".format(key, ex))
            result[key] = {"section":key,"section_status":"ERROR",
                           "error":str(ex),"traceback":tb[-600:]}
            all_sts.append("ERROR")
            cnts["ERROR"] = cnts.get("ERROR",0)+1
            errs.append({"section":key,"error":str(ex)})

    overall = agg(all_sts)

    # System info
    try:
        ip = socket.gethostbyname(env.hostname)
    except: ip = "unknown"
    try: kern = platform.release()
    except: kern = ""

    result["meta"] = {
        "report_type":   "DB",
        "script":        "oracle_healthcheck.py",
        "script_version":SCRIPT_VERSION,
        "server_name":   env.short,
        "hostname":      env.hostname,
        "ip_address":    ip,
        "os":            env.os_ver,
        "oracle_home":   env.oracle_home or "NOT_FOUND",
        "oracle_base":   env.oracle_base,
        "oracle_version":env.oracle_ver,
        "oracle_sid":    env.sid,
        "db_name":       db_info.get("db_name","") or env.db_name,
        "db_unique":     db_info.get("db_unique",""),
        "db_role":       db_info.get("db_role",""),
        "open_mode":     db_info.get("open_mode",""),
        "log_mode":      db_info.get("log_mode",""),
        "is_rac":        db_info.get("is_rac"),
        "standalone":    env.standalone,
        "db_connectable":db_ok,
        "check_date":    now_date(),
        "check_time":    now_time(),
        "check_user":    env.user,
        "overall_status":overall,
        "summary": {
            "total_sections": len(sections_to_run)+1,
            "critical": cnts.get("CRITICAL",0),
            "warning":  cnts.get("WARNING",0),
            "ok":       cnts.get("OK",0),
            "errors":   cnts.get("ERROR",0),
            "na":       cnts.get("N/A",0),
            "section_errors": errs
        },
        "completed_at": now_ts()
    }

    # Reorder: meta first
    ordered = {"meta": result.pop("meta")}
    ordered.update(result)

    # Write output
    out_dir = args.output
    if not os.path.isdir(out_dir):
        try: os.makedirs(out_dir)
        except Exception as ex:
            log.warn("Cannot create {}: {} — using /tmp".format(out_dir, ex))
            out_dir = "/tmp"

    fname = "{}_DB_{}.json".format(env.short, datetime.datetime.now().strftime("%Y%m%d"))
    if env.sid:
        fname = "{}_{}_DB_{}.json".format(env.short, env.sid,
                                          datetime.datetime.now().strftime("%Y%m%d"))
    fpath = os.path.join(out_dir, fname)

    written = False
    for path in [fpath, os.path.join("/tmp", fname)]:
        try:
            with open(path,"w") as fh:
                json.dump(ordered, fh, indent=2, default=str)
            log.info("Written: {}".format(path))
            print(path)
            written = True
            break
        except Exception as ex:
            log.warn("Cannot write {}: {}".format(path, ex))

    if not written:
        log.error("All write attempts failed!")
        sys.exit(2)

    log.info("=== ORACLE DB health check DONE | overall={} ===".format(overall))
    sys.exit(0 if overall in ("OK","N/A") else 1 if overall=="WARNING" else 2)

if __name__ == "__main__":
    main()
